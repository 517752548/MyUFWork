package com.imop.platform.local.test;

import java.io.File;
import java.math.BigDecimal;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.security.auth.callback.Callback;

import net.sf.json.JSONObject;

import org.apache.log4j.PropertyConfigurator;

import com.imop.platform.local.HandlerFactory;
import com.imop.platform.local.callback.ICallback;
import com.imop.platform.local.config.IConfig;
import com.imop.platform.local.config.LocalConfig;
import com.imop.platform.local.exception.LocalException;
import com.imop.platform.local.handler.IHandler;
import com.imop.platform.local.request.CreateIOSPaymentRequest;
import com.imop.platform.local.request.TransferReportParam;
import com.imop.platform.local.request.TransferReportRequest;
import com.imop.platform.local.request.TransferReportRequest.enum_chargetype;
import com.imop.platform.local.request.TransferReportRequest.enum_currency;
import com.imop.platform.local.response.AddWallowInfoResponse;
import com.imop.platform.local.response.CreateIOSPaymentResponse;
import com.imop.platform.local.response.ExpendGamePointsResponse;
import com.imop.platform.local.response.ExpendIOSPaymentResponse;
import com.imop.platform.local.response.GenerateOrderResponse;
import com.imop.platform.local.response.GetFCMTimeResponse;
import com.imop.platform.local.response.GetFriendsListResponse;
import com.imop.platform.local.response.GetGameUserInfoResponse;
import com.imop.platform.local.response.GetGoodsResponse;
import com.imop.platform.local.response.GetNGWordResponse;
import com.imop.platform.local.response.GetNickNameResponse;
import com.imop.platform.local.response.GetUserIdByNameResponse;
import com.imop.platform.local.response.GetUserIdByNickNameResponse;
import com.imop.platform.local.response.GetUserIsLegalResponse;
import com.imop.platform.local.response.GetUserNameByIdResponse;
import com.imop.platform.local.response.GoodsInfo;
import com.imop.platform.local.response.IResponse;
import com.imop.platform.local.response.IsBlackListUserResqponse;
import com.imop.platform.local.response.LoginResponse;
import com.imop.platform.local.response.LogoutResponse;
import com.imop.platform.local.response.QueryBalanceResponse;
import com.imop.platform.local.response.QueryGoodsResponse;
import com.imop.platform.local.response.QueryOnlineTimeResponse;
import com.imop.platform.local.response.TransferResponse;
import com.imop.platform.local.type.LoginType;

public class Test {

	public static void main(String [] args) {
		try {
			URL logFile = Thread.currentThread().getContextClassLoader().getResource("local.properties");
			PropertyConfigurator.configure(logFile);
			
			String userName = "sunruibox100@126.com";
			//String userName = "yygx123@yahoo.com.cn";
			String ip = "10.2.29.147";
			String password = "";
			//String password = "";
			long userId = 314251297;
			String roleId = String.valueOf(123456);
			int money = 1;
			int id = 1;
			int largessId = 1001;
			String nickName = "ziyexinghun";
			String ticket = "";
			
//			IHandler h = HandlerFactory.createHandler(
//					new LocalConfig("target/classes/local_cfg.xml", 
//					1, 1001, "s1.d.renren.com", "d", "renren.com"));
			
			LocalConfig config = new LocalConfig();
			config.setAreaId(1);
			config.setServerId(1002);
			config.setDomain("x2.dance.renren.com");
			config.setGamecode("dance");
			config.setGameKey("A17D9CC240CA72E485EB156DD1884B9A");
			config.setPlatformid("renren.com");
			config.setReportDomain("http://local.rrgdev.org/");
			config.setRequestDomain("http://local.rrgdev.org/");

			IHandler handler = HandlerFactory.createHandler(config);
			
			IHandler h = handler;
			
			GenerateOrderResponse generateOrderResponse = handler.generateOrder(572215473, "rrid_20339122049", "288969247965827116", "咖NEX", "padmini1", "6.1.2", "123.125.40.249", "9c2d289de6f55428e586185a1784b197", "9c2d289de6f55428e586185a1784b197", "iPad");
			if ( generateOrderResponse.isSuccess() ) {
			    System.out.println(generateOrderResponse.getGameOrderId());
			} else {
			    System.out.println("errorCode:"+generateOrderResponse.getErrorCode()+"|errorMsg"+generateOrderResponse.getErrorMsg());
			}
			//echo("channelUserLogin",h.channelUserLogin("202.104.1.1", "2024", "uid_123456", null));
			
//			
//			TransferReportParam param = new TransferReportParam();
//			
//			param.setUserId(userId);
//			//param.setRoleid("123456");
//			param.setIp(ip);
//			param.setOrderid("1599906135785409");
//			param.setGamebean(new BigDecimal(500));
//			param.setChargetype(enum_chargetype.expend);
//			param.setCurrency(enum_currency.RRDOU);
//			param.setMount(new BigDecimal(50));
//			param.setCurrenttime(getCurrentTime());
//			param.setAddtioninfo("aaadtioninfo");
//			param.setItemid("theitemid");
//			param.setItemname("theItemName");
//			param.setUsername("theusername");
//			param.setRolename("theRoleName");
//			param.setDevice("pc");
//			param.setDevicetype("ios");
//			
//			
//			echo("transferReport",handler.transferReport(param));
			
			//echo("addrolereport",handler.addRoleReport(111, "222", "牧师", "10.30.2.25"));
			//echo("queryAllRecharge",handler.queryAllRecharge());
			
//			Map<String, String> optinalParams = new HashMap<String, String>();
//			optinalParams.put("itemname", "你好中华");
//			echo("transferReport",handler.transferReport(314251297, "123456", ip, 
//					"1599906135785409", new BigDecimal(500), 
//					TransferReportRequest.enum_chargetype.expend, 
//					TransferReportRequest.enum_currency.RRDOU, 
//					new BigDecimal(3.45),getCurrentTime(),optinalParams));
//			echo("transfer",h.transfer(userId, roleId, money, ip, 1,1));
//			echo("exchangerecharge",h.exchangerecharge(314251297, "1", ip, getCurrentTime()));
//			echo("login",h.login(userName, password, ip, LoginType.UserPasswordLogin));
//			echo("login2",h.login(userName, password, ip, LoginType.UserPasswordLogin, 2));
//			echo("logout",h.logout(userId, ip));
//			echo("getusernamebyid",h.getUserNameById(userId, ip));
//			echo("getuseridbyname",h.getUserIdByName(userName, ip));
//			echo("getuserislegal",h.getUserIsLegal(userName, password, ip));
//			echo("getgameuserinfo",h.getGameUserInfo(userId, ip));
//			echo("getuseridbychannelname",h.getUserIdByChannelName(userName, "1001", ip));
//			echo("gmlogin",h.gmLogin(userName, ip, password, LoginType.UserPasswordLogin));
//			echo("queryonlinetime",h.queryOnlineTime(userId));
//			echo("getuserbirthday",h.getUserBirthday(userId, ip));
//			echo("addwallowinfo",h.addWallowInfo(userId, "李明", "522324197508045617", ip));
//			echo("addwallowinfo2",h.addWallowInfo(userId, "李明", "522324197508045617", ip, "aaa"));
//			echo("querybalance",h.queryBalance(userId, ip));
//			echo("getversion",h.getVersion());
//			echo("quicklogin",h.quickLogin("10.2.29.147", getCurrentTime(), "12345678901234567890123456789012","1000007"));
//			echo("queryrecharge",h.queryRecharge(314251297, ip, getCurrentTime()));
//			h.onlineReport(1000);
//			h.onlineReport(1000, new ICallback() {
//				
//				@Override
//				public void onSuccess(IResponse response) {
//					echo("online",response);
//				}
//				
//				@Override
//				public void onFail(IResponse response) {
//					echo("online",response);
//					
//				}
//			});
//			echo("activeusecode",h.activeUseCode(314251297, "f2ebf2994b4199af37ac", ip));
//			echo("getfriendslist",h.getFriendsList("2d589789c9c2d752e321f5aa739fce237"));
//			echo("createlink",h.createlink("2d589789c9c2d752e321f5aa739fce237"));
//			echo("thirdactivitescode",h.thirdActivitiesCode(314251297, "1321340840", ip, getCurrentTime()));
//			echo("querygoods",h.queryGoods(314251297, "123456", ip));
//			echo("getgoods",h.getGoods(314251297, "123456", ip, 8, 1001));
//			echo("exchangerrecharge",h.exchangerecharge(314251297, "2", ip, getCurrentTime()));
//			echo("getuserinfo",h.getUserInfo(userId));
//			echo("isblacklistuser",h.isBlackListUser(314251297, ip, "12345678901234567890123456789012", "09876543210987654321098765432121"));
//			echo("transfer",h.transfer(userId, roleId, money, ip, 1,1));
//			echo("addattention",h.addattention(ticket));
//			
//			h.statusReport("1001", "RUN", "测试测试",new ICallback() {
//				
//				@Override
//				public void onSuccess(IResponse response) {
//					echo("status:ok",response);
//				}
//				
//				@Override
//				public void onFail(IResponse response) {
//					echo("status:fail",response);
//				}
//			});
//			h.transRecordReport("1599859227672744", 314251297, "123456", 50, "23456", ip,new ICallback() {
//				
//				@Override
//				public void onSuccess(IResponse response) {
//					echo("transrecord:ok",response);
//				}
//				
//				@Override
//				public void onFail(IResponse response) {
//					echo("transrecord:fail",response);
//				}
//			});
//			
//			h.reportPlayerReport(ip, "yygx123@yahoo.com.cn", 314251297,123456, 
//					"角色名称", 15, 1347438617, 
//					"xxxx", 12346, 23456, "角色名", 25, "world", "2012-09-12 16:34:17", 
//					"1599875608135430", "举报信息", new ICallback() {
//						
//						@Override
//						public void onSuccess(IResponse response) {
//							echo("reportPlayerReport:ok",response);
//						}
//						
//						@Override
//						public void onFail(IResponse response) {
//							echo("reportPlayerReport:fail",response);
//						}
//					});
//			h.transferReport(314251297, "123456", ip, "1599906135785409", new BigDecimal(500), 
//					TransferReportRequest.enum_chargetype.expend, 
//					TransferReportRequest.enum_currency.RRDOU, new BigDecimal(3.45), "", "34", "套餐名称",getCurrentTime());
//			
			
			//------------------测试失败的---------------------------------
			
			
			//-------------------未测试的--------------------------------
			
//			//
			
//			String item_table = "afdas";
//			String amount = "";
//			String itemId = "";
//			String itemName = "";
//			long coin = 0;
//			String macInfo = "aaaabbbb";
//			String token = "eeewrwerwrwerew";
//			String udid = "aaaabbbb";
//			String charName = "worker";
//			String deviceType = "ipad";
//			String deviceVersion = "4.0.1";
//			
//			echo("iosrecharge",handler.iosRecharge(userId, roleId, item_table, amount, itemId, itemName, coin, 
//					macInfo, token, ip, getCurrentTime(), udid, userName, charName, deviceType, deviceVersion));
//			//
//			//
//			
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static long getCurrentTime() {
		String s = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
		return Long.parseLong(s);
	}
	
	public static void echo(String funcName,IResponse response) {
		System.out.print(funcName+":");
		if(response.isSuccess()) {
			JSONObject o = JSONObject.fromObject(response);
			o.remove("errorCode");
			o.remove("success");
			o.remove("useTime");
			System.out.println("成功 返回值:"+o.toString()+"");
		} else {
			System.out.println("失败 错误代码:"+response.getErrorCode()+"");
			JSONObject o = JSONObject.fromObject(response);
			o.remove("errorCode");
			o.remove("success");
			o.remove("useTime");
			System.out.println("失败返回值:"+o.toString()+"");
		}
	}
	
	//@SuppressWarnings("deprecation")
	public static void main2(String[] args) throws LocalException {
		
		String action;
		
		String fileName = "local.properties";
		URL url = Thread.currentThread().getContextClassLoader().getResource(fileName);
		if(null != url){
			fileName = url.getFile();
		} else {
			fileName = System.getProperty("user.dir") + File.separator + fileName;
		}		
		//设定配置文件路径
		PropertyConfigurator.configure(fileName);
		
		String userName = "local001@124.com";
		String ip = "192.168.0.153";
		String passWord = "";
		long userId = 123456;
		String roleId = String.valueOf(1000000);
		int money = 10;
		int id = 1;
		int largessId = 1001;
		String nickName = "ziyexinghun";
//		String ok = "ok:::d";
//		String[] df = ok.split(":");
		//IHandler handler = HandlerFactory.createHandler("target/classes/local_cfg.xml", 1, 1001, "test2.ls.kx1d.com");
		IHandler handler = HandlerFactory.createHandler(new LocalConfig("target/classes/local_cfg.xml", 1, 1001, "s1.sg3.renren.com", "sg3", "renren.com"));
		action = "直充";
		//handler = HandlerFactory.createHandler("bin/local_cfg.xml", 1, 1001, "test2.ls.kx1d.com");
	
//		//CreateIOSPaymentResponse createIOSPaymentResponse = handler.createIOSPayment(314251297l, "123456787", "10.2.29.147", 
//				"[{\"id\":\"1\",\"name\":\"100金币\",\"coins\":\"100\",\"amount\":\"10.99\"},{\"id\":\"2\",\"name\":\"200金币\",\"coins\":\"200\",\"amount\":\"20.99\"},{\"id\":\"3\",\"name\":\"300金币\",\"coins\":\"300\",\"amount\":\"30.99\"}]", "124fdf43fe", "udid123456789");
//		System.out.println(action+":money"+createIOSPaymentResponse.getState()+":"+createIOSPaymentResponse.getTransaction_id()+":"+createIOSPaymentResponse.getProduct_id());
//		
		handler.generateOrder(572215473, "rrid_20339122049", "288969247965827116", "咖NEX*", "padmini1", "6.1.2", "123.125.40.249", "9c2d289de6f55428e586185a1784b197", "9c2d289de6f55428e586185a1784b197", "iPad");
		
		ExpendIOSPaymentResponse expendIOSPaymentResponse = handler.expendIOSPayment(314251297l, "123456787", "10.2.29.147", "udid123456789");
		System.out.println(action+":money"+expendIOSPaymentResponse.getMoney()+":type="+expendIOSPaymentResponse.getUserId()+":"+expendIOSPaymentResponse.getOrderId()+":"+expendIOSPaymentResponse.getUseTime());
		
		
		action = "获取好友列表";
		GetFriendsListResponse getFriendsListResponse = handler.getFriendsList("1213123132213");
		System.out.println(getFriendsListResponse.getFriendsListJson());
		
		action = "信息补全";
		AddWallowInfoResponse addWallowInfoResponse = handler.addWallowInfo(3, "刘璐", "211403198403148411", ip);
		System.out.println(addWallowInfoResponse.isSuccess());
		
		GetGameUserInfoResponse getGameUserInfoResponse = handler.getGameUserInfo(3, "127.0.0.1");
		System.out.println(getGameUserInfoResponse.isWallowFill());

		action = "登录";
		LoginResponse loginResponse = handler.login(userName, passWord, ip, LoginType.ReturnCookie);
		
		if(loginResponse.isSuccess()){
			System.out.println(action + "\tUserId:" + loginResponse.getUserId()+"\tUserName:"+loginResponse.getUserName()+"\tcookie"+loginResponse.getCookie());
		}else{
			System.err.println(action + "\tErrorCode:" + loginResponse.getErrorCode());
		}
		
		action = "NG";
		GetNGWordResponse getNGWordResponse = handler.getNGWord(userId, ip, "adsfas", new Date().getTime());
		if(getNGWordResponse.isSuccess()){
			System.out.println(action + "\tUserId:" + loginResponse.getUserId()+"\tUserName:"+loginResponse.getUserName());
		}else{
			System.err.println(action + "\tErrorCode:" + loginResponse.getErrorCode());
		}
		
		action = "退出";
		LogoutResponse logoutResponse = handler.logout(userId, ip);
		if(logoutResponse.isSuccess()){
			System.out.println(action + "\tUserId:" + logoutResponse.getUserId());
		}else{
			System.err.println(action + "\tErrorCode:" + logoutResponse.getErrorCode());
		}
		
		action = "兑换MM";
		TransferResponse transferResponse = handler.transfer(userId, roleId, money, ip);
		if(transferResponse.isSuccess()){
			System.out.println(action + "\tUserId:" + transferResponse.getUserId() + "\tBalance:" + transferResponse.getBalance());
		}else{
			System.err.println(action + "\tErrorCode:" + transferResponse.getErrorCode());
		}
		
		action = "查询余额";
		QueryBalanceResponse queryBalanceResponse = handler.queryBalance(userId, ip);
		if(queryBalanceResponse.isSuccess()){
			System.out.println(action + "\tBalance:" + queryBalanceResponse.getBalance());
		}else{
			System.err.println(action + "\tErrorCode:" + queryBalanceResponse.getErrorCode());
		}
		
		action = "查询奖励";
		QueryGoodsResponse queryGoodsResponse = handler.queryGoods(userId, roleId, ip);
		List<GoodsInfo> goodsList = queryGoodsResponse.getGoodsInfoList();
		GoodsInfo info = null;
		if(queryGoodsResponse.isSuccess()){
			if(null != goodsList && goodsList.size() > 0){
				info = goodsList.get(0);
				System.out.println(action + "\tId:" + info.getId() + "\tLargessId:" + info.getGoodsId());
			}
		}else{
			System.err.println(action + "\tErrorCode:" + queryGoodsResponse.getErrorCode());
		}

		action = "领取奖励";
		if(null != info){
			id = info.getId();
			largessId = info.getGoodsId();
		}
		GetGoodsResponse getGoodsResponse = handler.getGoods(userId, roleId, ip, id, largessId);
		if(getGoodsResponse.isSuccess()){
			System.out.println(action + "\ttLargessId:" + getGoodsResponse.getPrizeId());
		}else{
			System.err.println(action + "\tErrorCode:" + getGoodsResponse.getErrorCode());
		}
		
		action = "GM登录";
		loginResponse = handler.gmLogin(userName, ip, passWord, LoginType.UserPasswordLogin);
		if(loginResponse.isSuccess()){
			System.out.println(action + "\tUserId:" + loginResponse.getUserId()+"\tUserName:"+loginResponse.getUserName());
		}else{
			System.err.println(action + "\tErrorCode:" + loginResponse.getErrorCode());
		}
		
		action = "通过ID获取用户名";
		GetUserNameByIdResponse getUserNameByIdResponse = handler.getUserNameById(userId, ip);
		if(getUserNameByIdResponse.isSuccess()){
			System.out.println(action + "\tUserName:" + getUserNameByIdResponse.getUserName());
		}else{
			System.err.println(action + "\tErrorCode:" + getUserNameByIdResponse.getErrorCode());
		}
		
		action = "通过NAME获取ID";
		GetUserIdByNameResponse getUserIdByNameResponse = handler.getUserIdByName(userName, ip);
		if(getUserIdByNameResponse.isSuccess()){
			System.out.println(action + "\tUserId:" + getUserIdByNameResponse.getUserId());
		}else{
			System.err.println(action + "\tErrorCode:" + getUserIdByNameResponse.getErrorCode());
		}
		
		action = "检测用户合法";
		GetUserIsLegalResponse getUserIsLegalResponse = handler.getUserIsLegal(userName, passWord, ip);
		if(getUserIsLegalResponse.isSuccess()){
			System.out.println(action + "\tUserId:" + getUserIsLegalResponse.getUserId() + "\tUserName:" + getUserIsLegalResponse.getUserName());
		}else{
			System.err.println(action + "\tErrorCode:" + getUserIsLegalResponse.getErrorCode());
		}
		
		action = "查询在线时间";
		QueryOnlineTimeResponse queryOnlineTimeResponse = handler.queryOnlineTime(userId);
		if(queryOnlineTimeResponse.isSuccess()){
			System.out.println(action + "\tUserId:" + queryOnlineTimeResponse.getUserId() + "\tTime:" + queryOnlineTimeResponse.getOnlineTime());
		}else{
			System.err.println(action + "\tErrorCode:" + queryOnlineTimeResponse.getErrorCode());
		}
		
		action = "通过昵称获取ID";
		GetUserIdByNickNameResponse getUserIdByNickNameResponse = handler.getUserIdByNickName(nickName);
		if(getUserIdByNickNameResponse.isSuccess()){
			System.out.println(action + "\tUserId:" + getUserIdByNickNameResponse.getUserId());
		}else{
			System.err.println(action + "\tErrorCode:" + getUserIdByNickNameResponse.getErrorCode());
		}
		
		action = "获取昵称";
		GetNickNameResponse getNickNameResponse = handler.getNickName(userId);
		if(getNickNameResponse.isSuccess()){
			System.out.println(action + "\tUserName:" + getNickNameResponse.getNickName());
		}else{
			System.err.println(action + "\tErrorCode:" + getNickNameResponse.getErrorCode());
		}
		
		action = "状态汇报";
		handler.statusReport("1001", "run", "extra");
		
	}
	
}
