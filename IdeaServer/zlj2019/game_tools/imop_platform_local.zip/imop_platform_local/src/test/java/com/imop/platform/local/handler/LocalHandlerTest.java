package com.imop.platform.local.handler;

import static org.junit.Assert.*;

import java.math.BigDecimal;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import net.sf.json.JSONObject;

import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.PropertyConfigurator;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import com.imop.platform.local.HandlerFactory;
import com.imop.platform.local.callback.ICallback;
import com.imop.platform.local.config.IConfig;
import com.imop.platform.local.config.LocalConfig;
import com.imop.platform.local.request.TransferReportParam;
import com.imop.platform.local.request.TransferReportRequest.enum_chargetype;
import com.imop.platform.local.request.TransferReportRequest.enum_currency;
import com.imop.platform.local.response.ActiveUseCodeResponse;
import com.imop.platform.local.response.AddAttentionResponse;
import com.imop.platform.local.response.AddRoleReportResponse;
import com.imop.platform.local.response.AddWallowInfoResponse;
import com.imop.platform.local.response.CaptchaCheckResponse;
import com.imop.platform.local.response.CaptchaSendResponse;
import com.imop.platform.local.response.ChannelUserLoginResponse;
import com.imop.platform.local.response.ExchangeRechargeResponse;
import com.imop.platform.local.response.GenerateOrderResponse;
import com.imop.platform.local.response.GetGameUserInfoResponse;
import com.imop.platform.local.response.GetGoodsResponse;
import com.imop.platform.local.response.GetUserBirthdayResponse;
import com.imop.platform.local.response.GetUserIdByChannelNameResponse;
import com.imop.platform.local.response.GetUserIdByNameResponse;
import com.imop.platform.local.response.GetUserIsLegalResponse;
import com.imop.platform.local.response.GetUserNameByIdResponse;
import com.imop.platform.local.response.IOSRechargeResponse;
import com.imop.platform.local.response.IResponse;
import com.imop.platform.local.response.IsBlackListUserResqponse;
import com.imop.platform.local.response.LoginResponse;
import com.imop.platform.local.response.LogoutResponse;
import com.imop.platform.local.response.PayChannelMobileCardResponse;
import com.imop.platform.local.response.PayChannelMycardResponse;
import com.imop.platform.local.response.PayChannelQueryStatusResponse;
import com.imop.platform.local.response.PayChannelRRCardRespose;
import com.imop.platform.local.response.QueryAllRechargeResponse;
import com.imop.platform.local.response.QueryBalanceResponse;
import com.imop.platform.local.response.QueryGoodsResponse;
import com.imop.platform.local.response.QueryOnlineTimeResponse;
import com.imop.platform.local.response.QueryRechargeResponse;
import com.imop.platform.local.response.QuickLoginResponse;
import com.imop.platform.local.response.SurveyResponse;
import com.imop.platform.local.response.ThirdActivitiesCodeResponse;
import com.imop.platform.local.response.TransferReportResponse;
import com.imop.platform.local.response.TransferResponse;
import com.imop.platform.local.type.LoginType;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class LocalHandlerTest {

	protected String userName = "sunruibox100@126.com";
	protected String ip = "10.2.29.147";
	protected String password = "sun456123";
	protected long userId = 314251297;
	protected String roleId = String.valueOf(123456);
	protected int money = 1;
	protected int id = 1;
	protected int largessId = 1001;
	protected String nickName = "ziyexinghun";
	protected String ticket = "";
	protected static IConfig config;
	protected static IHandler handler;
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		URL logFile = Thread.currentThread().getContextClassLoader().getResource("local.properties");
		PropertyConfigurator.configure(logFile);
		
		LocalConfig _config = new LocalConfig();
		_config.setAreaId(1);
		_config.setServerId(1001);
		_config.setDomain("x4.csj.renren.com");
		//_config.setDomain("s1.pnfs.imop.tw");
		_config.setGamecode("csj");
		//_config.setGameKey("c762000b3eb6955de0862f435b28a8eb");
		_config.setGameKey("2D940190C62CD4EE64D206E8A4B1148A");  //csj
		//_config.setGameKey("06FD2329C3ACB8D0A60AAC7BC28AC0D6");  //lstx
		_config.setPlatformid("renren.com");
		//_config.setPlatformid("mop.com");
		_config.setReportDomain("http://test.local.rrgdev.org/");
		_config.setRequestDomain("http://test.local.rrgdev.org/");
		
		//_config.setReportDomain("http://local.pnfs.mop.com/");
		//_config.setRequestDomain("http://local.pnfs.mop.com/");
		
//		_config.setReportDomain("http://jp.local.mop.com/");
//		_config.setRequestDomain("http://jp.local.mop.com/");
		
		config = _config;
		
		handler = HandlerFactory.createHandler(_config);
		
		
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		
	}

	@Before
	public void setUp() throws Exception {
		
	}

	@After
	public void tearDown() throws Exception {
		
	}
	
	public static void echo(String method,Object result) {
		JSONObject ooo = JSONObject.fromObject(result);
		if(ooo.getBoolean("success")) {
			System.out.println(method+" - "+JSONObject.fromObject(result));
		} else {
			System.err.println(method+" - "+JSONObject.fromObject(result));
		}
	}
	
	private static long getCurrentTime() {
		String s = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
		return Long.parseLong(s);
	}

	@Test
	public void testActiveUseCode() {
		ActiveUseCodeResponse response = handler.activeUseCode(314251297, "f2ebf2994b4199af37ac", ip);
		echo("ActiveUseCode",response);
		assertTrue(response.getErrorCode()==12);
	}

	@Test
	public void testAddattention() {
		
		LoginResponse loginResponse = handler.login("sunruibox100@126.com", "sun456123", ip, LoginType.UserPasswordLogin);
		
		AddAttentionResponse response = handler.addattention(loginResponse.getCookie());
		echo("AddAttention",response);
		
		assertTrue(response.getErrorCode()==3);
	}

	@Test
	public void testAddRoleReport() {
		AddRoleReportResponse response = handler.addRoleReport(111, "222", "牧师", "10.30.2.25");
		echo("AddRoleReport",response);
		assertTrue(response.isSuccess());
	}

	@Test
	public void testAddWallowInfo() {
		AddWallowInfoResponse response1 = handler.addWallowInfo(userId, "李明", "522324197508045617", ip);
		echo("AddWallowInfo[1]",response1);
		
		AddWallowInfoResponse response2 = handler.addWallowInfo(userId, "李明", "522324197508045617", ip, "aaa");
		echo("AddWallowInfo[2]",response2);
		
		assertTrue(response1.isSuccess() && response2.isSuccess());
	}

	@Test
	public void testChannelUserLogin() {
		ChannelUserLoginResponse response =handler.channelUserLogin("127.0.0.1", "2033", "CC00001", null);
		echo("ChannelUserLogin",response);
		assertTrue(response.isSuccess());
	}

	@Test
	public void testCreateIOSPayment() {
		assertTrue(true);
	}

	@Test
	public void testCreatelink() {
		assertTrue(true);
	}

	@Test
	public void testDelRoleReport() {
		assertTrue(true);
	}

	@Test
	public void testExchangerecharge() {
		ExchangeRechargeResponse response = handler.exchangerecharge(314251297, "1", ip, getCurrentTime());
		echo("ExchangeRecharge",response);
		
		assertTrue(true);
	}

	@Test
	public void testExpendGamePoints() {
		assertTrue(true);
	}

	@Test
	public void testExpendIOSPayment() {
		assertTrue(true);
	}

	@Test
	public void testGetConfig() {
		assertTrue(true);
	}

	@Test
	public void testGetFCMTime() {
		assertTrue(true);
	}

	@Test
	public void testGetFriendsList() {
		assertTrue(true);
	}

	@Test
	public void testGetGameUserInfo() {
		GetGameUserInfoResponse response = handler.getGameUserInfo(userId, ip);
		echo("GetGameUserInfo",response);
		assertTrue(response.isSuccess() && response.isWallowFill());
	}

	@Test
	public void testGetGoods() {
		GetGoodsResponse response = handler.getGoods(userId, roleId, ip, id, largessId);
		echo("GetGoods",response);
		assertTrue(response.getErrorCode()==4);
	}

	@Test
	public void testGetNGWord() {
		assertTrue(true);
	}

	@Test
	public void testGetNickName() {
		assertTrue(true);
	}

	@Test
	public void testGetUserBirthday() {
		GetUserBirthdayResponse response = handler.getUserBirthday(userId, ip);
		echo("GetUserBirthday",response);
		assertTrue(response.isSuccess() && response.getBirthday().equals("1975-08-04"));
	}

	@Test
	public void testGetUserIdByChannelName() {
		GetUserIdByChannelNameResponse response = handler.getUserIdByChannelName(userName, "1001", ip);
		echo("GetUserIdByChannelName",response);
		assertTrue(response.isSuccess() && response.getUserId()==468379886L);
	}

	@Test
	public void testGetUserIdByName() {
		GetUserIdByNameResponse response = handler.getUserIdByName(userName, ip);
		echo("GetUserIdByName",response);
		assertTrue(response.getUserId()==468379886L);
	}

	@Test
	public void testGetUserIdByNickName() {
		assertTrue(true);
	}

	@Test
	public void testGetUserInfo() {
		assertTrue(true);
	}

	@Test
	public void testGetUserIsLegal() {
		GetUserIsLegalResponse response = handler.getUserIsLegal(userName, password, ip);
		echo("GetUserIsLegal",response);
		assertTrue(response.isSuccess() && response.getUserId()==468379886L && response.getUserName().equals("sunruibox100@126.com"));
	}

	@Test
	public void testGetUserNameById() {
		GetUserNameByIdResponse response = handler.getUserNameById(userId, ip);
		echo("GetUserNameById",response);
		assertTrue(response.getUserName().equals("yygx123@yahoo.com.cn"));
	}

	@Test
	public void testGetVersion() {
		assertTrue(true);
	}

	@Test
	public void testGmLogin() {
		LoginResponse response = handler.gmLogin(userName, ip, password, LoginType.UserPasswordLogin);
		echo("GmLogin",response);
		assertTrue(response.isSuccess() && response.getUserId()==468379886L);
	}

	@Test
	public void testIosRecharge() {
		
		String item_table = "afdas";
		String amount = "";
		String itemId = "";
		String itemName = "";
		long coin = 0;
		String macInfo = "aaaabbbb";
		String token = "eeewrwerwrwerew";
		String udid = "aaaabbbb";
		String charName = "worker?";
		String deviceType = "ipad";
		String deviceVersion = "4.0.1";
		
		IOSRechargeResponse response = handler.iosRecharge(userId, roleId, item_table, amount, itemId, itemName, coin, 
				macInfo, token, ip, getCurrentTime(), udid, userName, charName, deviceType, deviceVersion);
		echo("IOSRecharge",response);
		assertTrue(true);
	}

	@Test
	public void testIsBlackListUser() {
		IsBlackListUserResqponse response = handler.isBlackListUser(314251297, ip, "12345678901234567890123456789012", "09876543210987654321098765432121");
		echo("IsBlackListUser",response);
		assertTrue(response.isSuccess());
	}

	@Test
	public void testLocalHandler() {
		assertTrue(true);
	}

	@Test
	public void testLogin() {
		LoginResponse response = handler.login(userName, password, ip, LoginType.UserPasswordLogin);
		echo("Login",response);
		assertEquals("用户ID不正确", 468379886, response.getUserId());
	}


	@Test
	public void testLogout() {
		LogoutResponse response = handler.logout(userId, ip);
		echo("Logout",response);
		assertTrue(response.isSuccess());
	}

	@Test
	public void testOauthLogin() {
		assertTrue(true);
	}

	@Test
	public void testOnlineReport() {
		
		handler.onlineReport(1000);
		
		handler.onlineReport(1000, new ICallback() {
			
			@Override
			public void onSuccess(IResponse response) {
				echo("OnlineReport[success]",response);
			}
			
			@Override
			public void onFail(IResponse response) {
				echo("OnlineReport[failed]",response);
				
			}
		});
		
		assertTrue(true);
	}

	@Test
	public void testPropsStatusReport() {
		handler.statusReport("1001", "RUN", "测试测试");
		handler.statusReport("1001", "RUN", "测试测试",new ICallback() {
			@Override
			public void onSuccess(IResponse response) {
				echo("StatusReport[success]",response);
			}
			@Override
			public void onFail(IResponse response) {
				echo("StatusReport[fail]",response);
			}
		});
		
		assertTrue(true);
	}

	@Test
	public void testQueryAllRecharge() {
		QueryAllRechargeResponse response = handler.queryAllRecharge();
		echo("QueryAllRecharge",response);
		assertTrue(response.isSuccess());
	}

	@Test
	public void testQueryBalance() {
		QueryBalanceResponse response = handler.queryBalance(userId, ip);
		echo("QueryBalance",response);
		assertTrue(response.isSuccess());
	}

	@Test
	public void testQueryGoods() {
		QueryGoodsResponse response = handler.queryGoods(userId, roleId, ip);
		echo("QueryGoods",response);
		assertTrue(response.getErrorCode()==4||response.isSuccess());
	}

	@Test
	public void testQueryOnlineTime() {
		QueryOnlineTimeResponse response = handler.queryOnlineTime(userId);
		echo("QueryOnlineTime",response);
		assertTrue(response.isSuccess());
	}

	@Test
	public void testQueryRecharge() {
		QueryRechargeResponse response = handler.queryRecharge(223788038, ip, getCurrentTime());
		echo("QueryRecharge",response);
		assertTrue(response.isSuccess());
	}

	@Test
	public void testQuickLogin() {
		QuickLoginResponse response = handler.quickLogin("10.2.29.147", getCurrentTime(), "12345678901234567890123456789012","1000007");
		echo("QuickLogin",response);
		assertTrue(true);
	}

	@Test
	public void testReportGmLargessReport() {
		assertTrue(true);
	}

	@Test
	public void testReportPlayerReport() {
		
		handler.reportPlayerReport(ip, "yygx123@yahoo.com.cn", 314251297,123456, 
			"角色名称", 15, 1347438617, 
			"xxxx", 12346, 23456, "角色名", 25, "world", "2012-09-12 16:34:17", 
			"1599875608135430", "举报信息", new ICallback() {
				
				@Override
				public void onSuccess(IResponse response) {
					echo("ReportPlayerReport[success]",response);
				}
				
				@Override
				public void onFail(IResponse response) {
					echo("ReportPlayerReport[failed]",response);
				}
		});
		
		assertTrue(true);
	}

	@Test
	public void testSetReportService() {
		assertTrue(true);
	}

	@Test
	public void testStatusReport() {
		handler.statusReport("12", "RUN", "");
		assertTrue(true);
	}

	@Test
	public void testThirdActivitiesCode() {
		ThirdActivitiesCodeResponse response = handler.thirdActivitiesCode(314251297, "1321340840", ip, getCurrentTime());
		echo("ThirdActivitiesCode",response);
		assertTrue(true);
	}

	@Test
	public void testTransfer() {
		TransferResponse response = handler.transfer(userId, roleId, money, ip, 1,1);
		echo("Transfer",response);
		assertTrue(true);
	}

	@Test
	public void testTransferReport() {
		
		TransferReportResponse response1 = handler.transferReport(460649631L, "857658652083923916", 
				"180.170.130.2:54135", 
				"1356092842556001176", new BigDecimal(1000), 
				enum_chargetype.transfer, enum_currency.CNY, new BigDecimal(1000), "", 
				"", "",20121226154605L);
		
		echo("TransferReport[1]",response1);
		
		TransferReportResponse response2 = 
		handler.transferReport(460649631L, "857658652083923916", 
				"180.170.130.2:54135", 
				"1356092842556001176", new BigDecimal(1000), 
				enum_chargetype.transfer, enum_currency.CNY, new BigDecimal(1000), 20121226154605L,new HashMap<String, String>() );
		
		echo("TransferReport[2]",response2);
		
		assertTrue(response1.isSuccess() && response2.isSuccess());
		
	}

	@Test
	public void testTransRecordReport() {
		handler.transRecordReport("1599859227672744", 314251297, "123456", 50, "23456", ip);
		handler.transRecordReport("1599859227672744", 314251297, "123456", 50, "23456", ip,new ICallback() {
			@Override
			public void onSuccess(IResponse response) {
				echo("TransrecordReport[success]",response);
			}
			@Override
			public void onFail(IResponse response) {
				echo("TransrecordReport[fail]",response);
			}
		});
		
		assertTrue(true);
	}
	
	@Test
	public void testPayChannelRRCard() {
		Random r = new Random();
		String cardId = "03112345678999998";
		String cardPwd = "031123456789999998";
		String gameOrderId = System.currentTimeMillis()+String.format("%06d", r.nextInt(999999));
		
		
		PayChannelRRCardRespose response = handler.payChannelRRCard(userId, cardId, cardPwd, 
				gameOrderId, userName, roleId, "武士", 
				"ipad", "4.0.1", ip, DigestUtils.md5Hex("xxxx"), 
				DigestUtils.md5Hex("xxxx"),"ios");
		echo("PayChannelRRCard",JSONObject.fromObject(response).toString());
		assertTrue(true);
		
		
	}
	
	@Test
	public void testPayChannelMobileCard() {
		Random r = new Random();
		String cardId = "031"+String.format("%05d%05d%04d", r.nextInt(99999),r.nextInt(99999),r.nextInt(9999));
		String cardPwd = "031"+String.format("%05d%05d%05d", r.nextInt(99999),r.nextInt(99999),r.nextInt(99999));
		String gameOrderId = System.currentTimeMillis()+String.format("%06d", r.nextInt(999999));
		
		PayChannelMobileCardResponse response = handler.payChannelMobileCard(userId, cardId, cardPwd, 
				"0", 10, gameOrderId, userName, roleId, "战士", 
				"ipad", "4.0.1",  ip, DigestUtils.md5Hex("xxxx"), 
				DigestUtils.md5Hex("xxxx"),"ios");
		echo("PayChannelMobileCard",response);
		assertTrue(true);
		
	}
	
	@Test
	public void testPayChannelQueryStatus() {
		Random r = new Random();
		
		String cardId = "031"+String.format("%05d%05d%04d", r.nextInt(99999),r.nextInt(99999),r.nextInt(9999));
		String cardPwd = "031"+String.format("%05d%05d%05d", r.nextInt(99999),r.nextInt(99999),r.nextInt(99999));
		String gameOrderId = System.currentTimeMillis()+String.format("%06d", r.nextInt(999999));
		
		PayChannelMobileCardResponse response = handler.payChannelMobileCard(userId, cardId, cardPwd, 
				"0", 10, gameOrderId, userName, roleId, "战士", 
				"ipad", "4.0.1",  ip, DigestUtils.md5Hex("xxxx"), 
				DigestUtils.md5Hex("xxxx"),"ios");
		echo("PayChannelQueryStatus[0]",response);
		PayChannelQueryStatusResponse response1 = handler.payChannelQueryStatus(userId, ip, gameOrderId);
		echo("PayChannelQueryStatus[1]",response1);
		assertTrue(true);
	}
	
	@Test
	public void testPayChannelMycard() {
		Random r = new Random();
		String cardId = "031"+String.format("%05d%05d%04d", r.nextInt(99999),r.nextInt(99999),r.nextInt(9999));
		String cardPwd = "031"+String.format("%05d%05d%05d", r.nextInt(99999),r.nextInt(99999),r.nextInt(99999));
		String gameOrderId = System.currentTimeMillis()+String.format("%06d", r.nextInt(999999));
		
		PayChannelMycardResponse response = handler.payChannelMyCard(userId, cardId, cardPwd, 
				gameOrderId, userName, roleId, "战士", 
				"ipad", "4.0.1",  ip, DigestUtils.md5Hex("xxxx"), 
				DigestUtils.md5Hex("xxxx"),"ios");
		echo("PayChannelMycard",response);
		assertTrue(true);
	}
	
	@Test
	public void testGenerateOrder() {
		GenerateOrderResponse response = handler.generateOrder(
				userId, userName, "123", 
				"武士", "ipad", "4.0.1", 
				ip, DigestUtils.md5Hex("xxxx"), 
				DigestUtils.md5Hex("xxxx"),"android");
		
		echo("GenerateOrder",response);
		
		assertTrue(response.isSuccess() && StringUtils.isNotBlank(response.getGameOrderId()));
	}
	
	@Test
	public void testCaptchaSend() {
		CaptchaSendResponse response = handler.captchaSend(384723, "xxx", "11111", "127.0.0.9");
		echo("CaptchaSend",response);
		assertTrue(response.getErrorCode()==3);
	}
	
	@Test
	public void testCaptchaCheck() {
		CaptchaCheckResponse response = handler.captchaCheck(02033, "xxxx", "11111", "730877", "127.0.0.9");
		echo("CaptchaCheck",response);
		assertTrue(response.getErrorCode()==3);
	}
	
	@Test
	public void testGetSurvey() {
		
		Map<String,String> p = new HashMap<String,String>();
		
		p.put("userlevel", "1");
		
		handler.getSurvey(userId, p, new ICallback() {
			
			@Override
			public void onSuccess(IResponse response) {
				System.out.println("success");
				SurveyResponse sr = (SurveyResponse)response;
				System.out.println(JSONObject.fromObject(sr).toString());
			}
			
			@Override
			public void onFail(IResponse response) {
				System.out.println("fail");
				SurveyResponse sr = (SurveyResponse)response;
				System.out.println(JSONObject.fromObject(sr).toString());
			}
		});
		
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

}
