package com.imop.platform.local.response;

import net.sf.json.JSONObject;

public class ThirdActivitiesCodeResponse extends AbstractResponse {

	/**
	 * 激活码或者兑奖码 ,默认值为null;
	 */
	private String code = null;
	
	public ThirdActivitiesCodeResponse(String[] args) {
		super(args, 2);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void onSuccess(String[] args) {
		String json_str = args[1].toString();
		JSONObject json_temp = JSONObject.fromObject(json_str);		
		this.code = getJsonValue(json_temp, "code");
	}

	public String getCode(){
		return code;
	}
}
