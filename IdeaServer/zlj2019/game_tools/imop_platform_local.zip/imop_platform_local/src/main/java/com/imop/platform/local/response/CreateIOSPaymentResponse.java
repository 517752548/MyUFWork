package com.imop.platform.local.response;

public class CreateIOSPaymentResponse extends AbstractResponse {

	/**
	 *  充值状态码 ：1 正常情况，5999充值成功，但是受到封禁，N小时自动解封
	 *  默认值：-1
	 */
	private int state = -1;
	
	/**
	 * appstore的订单号
	 */
	private String transaction_id= "";
	/**
	 * 产品ID
	 */
	private String product_id = "";
	public CreateIOSPaymentResponse(String[] args) {
		super(args, 4);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void onSuccess(String[] args) {
		this.state = Integer.valueOf(args[1]);
		if(args.length>=3)this.transaction_id=args[2];
		if(args.length>=4)this.product_id = args[3];

	}

	public int getState() {
		return state;
	}

	public void setState(int state) {
		this.state = state;
	}

	public String getTransaction_id() {
		return transaction_id;
	}

	public void setTransaction_id(String transactionId) {
		transaction_id = transactionId;
	}

	public String getProduct_id() {
		return product_id;
	}

	public void setProduct_id(String productId) {
		product_id = productId;
	}


}
