package com.imop.platform.local.response;

public class PayChannelRRCardRespose extends AbstractResponse {

	public PayChannelRRCardRespose(String[] args) {
		super(args, 2);
	}

	@Override
	public void onSuccess(String[] args) {

	}

}
