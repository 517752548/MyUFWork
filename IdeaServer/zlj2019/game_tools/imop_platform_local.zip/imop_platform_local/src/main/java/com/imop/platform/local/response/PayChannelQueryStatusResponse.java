package com.imop.platform.local.response;

public class PayChannelQueryStatusResponse extends AbstractResponse {

	public PayChannelQueryStatusResponse(String[] args) {
		super(args, 2);
	}

	@Override
	public void onSuccess(String[] args) {

	}

}
