package com.imop.platform.local.request;

import java.text.SimpleDateFormat;
import java.util.Date;

import net.sf.json.JSONObject;

import com.imop.platform.local.bean.ReportForDGBean;
import com.imop.platform.local.config.IConfig;
import com.imop.platform.local.response.IResponse;
import com.imop.platform.local.response.LoginResponse;

/**
 * 用户登录验证接口<br>
 * 接口功能：<br>
 * 提供用户登录信息验证功能，游戏验证玩家登录需要调用此接口。<br><br>
 * 该接口支持3种登录方式：<br><br>
 * 1.	账户和密码登录<br>
 * a)	游戏出现登录框，玩家输入账户和密码，点击登录；<br>
 * b)	游戏调用此接口验证该用户账户密码是否正确。<br><br>
 * 2.	Cookie登录<br>
 * a)	用户登录官网，官网会种入cookie，此cookie可作为玩家是否登录的凭证，cookie名称为t和societyguester，值为md5加密串，默认Cookie值为官网登录后设置的societyguester值，如没有则取t的值，该值由GAME服务器获取；<br>
 * b)	游戏获取此cookie，调用此接口验证该用户是否已经登录。<br><br>
 * 3.	Token签名验证登录<br>
 * a)	用户登录官网，在用户进入游戏时，官网产生一个会过期的验证串，在页面跳转到游戏时，通过get方式传递给游戏。例如：<br>
 * http://s1.t.mop.com/?token=qwl2j341o79714tho1o374923749lj1o282;<br>
 * b)	游戏获取此token，调用此接口验证该用户是否已经登录。<br>
 * 这三种方式，优先顺序为：1，账户和密码登录，2，Cookie登录，3，token签名验证登录。
 * @author lu.liu
 *
 */
public class LoginRequest extends AbstractRequest {
	
	public LoginRequest(IConfig config){
		super(config);
		this.page = "u.login.php" +
				"?timestamp=%s" +
				"&username=%s" +
				"&ip=%s" +
				"&areaid=%s" +
				"&serverid=%s" +
				"&psw=%s" +
				"&logintype=%s" +
				"&domain=%s" +
				"&getkxid=%s" +
				"&sign=%s" +
				"&dataext=%s" ;
	}

	@Override
	public IResponse getResponse(String[] args) {
		return new LoginResponse(args);
	}
	@Override
	public void recordUrl(String uuid, String url){
		StringBuffer sb = new StringBuffer(url);
		sb.replace(sb.indexOf("psw=")+4, sb.indexOf("&", sb.indexOf("psw=")+4), "******");
		config.getRecord().recordInfo(uuid + "\t" + sb.toString());
	}

	@Override
	public void setParams(Object... objects) {
		long timestamp = getTimestamp();
		int areaId = config.getAreaId();
		int serverId = config.getServerId();
		
		String userName = objects[0].toString();
		String password = objects[1].toString();
		String ip = objects[2].toString();
		int loginType = Integer.valueOf(objects[3].toString());
		int getkxid = Integer.valueOf(objects[4].toString());
		
		ReportForDGBean bean = (ReportForDGBean) objects[5];
		long date= System.currentTimeMillis()/1000;
		//System.out.println(date);
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		java.util.Calendar cal = java.util.Calendar.getInstance();   
	    cal.setTime(new Date(date*1000));
		int zoneOffset = cal.get(java.util.Calendar.ZONE_OFFSET);   
		int dstOffset = cal.get(java.util.Calendar.DST_OFFSET);    
		cal.add(java.util.Calendar.MILLISECOND, -(zoneOffset + dstOffset)); 
		String nowTime = df.format(new Date(date*1000));
		String utcTime = df.format(cal.getTime());
		bean.complement(timestamp*1000, utcTime, nowTime, config.getGamecode(), config.getPlatformid(), ""+areaId,""+serverId, config.getDomain());
		
		String sign = getSign(timestamp,encodeUrl(userName),ip,areaId,serverId,password,loginType);
		//System.out.println(JSONObject.fromObject(bean).toString());
		generateUrl(timestamp,userName,ip,areaId,serverId,password,loginType,domain,getkxid,sign,JSONObject.fromObject(bean).toString());		
	}
	

}
