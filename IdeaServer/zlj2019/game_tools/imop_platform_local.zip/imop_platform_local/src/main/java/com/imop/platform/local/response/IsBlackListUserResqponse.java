package com.imop.platform.local.response;

public class IsBlackListUserResqponse extends AbstractResponse {

	private String state=null;
	
	public IsBlackListUserResqponse(String[] args) {
		super(args, 2);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void onSuccess(String[] args) {
		this.state = args[0];
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}
}
