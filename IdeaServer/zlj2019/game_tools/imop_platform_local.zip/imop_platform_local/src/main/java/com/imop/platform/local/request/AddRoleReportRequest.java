package com.imop.platform.local.request;

import com.imop.platform.local.config.IConfig;
import com.imop.platform.local.response.AddRoleReportResponse;
import com.imop.platform.local.response.IResponse;

public class AddRoleReportRequest extends AbstractRequest {

	public AddRoleReportRequest(IConfig config) {
		super(config);
		this.page="u.addrolereport.php" +
				"?timestamp=%s" +
				"&userId=%s" +
				"&roleId=%s" +
				"&rolename=%s" +
				"&ip=%s" +
				"&areaid=%s" +
				"&serverid=%s" +
				"&domain=%s"+
				"&sign=%s" ;
	}

	@Override
	public IResponse getResponse(String[] args) {
		// TODO Auto-generated method stub
		return new AddRoleReportResponse(args);
	}

	@Override
	public void setParams(Object... objects) {
		long timestamp = getTimestamp();
		
		long userId = Long.valueOf(objects[0].toString());
		String roleId = objects[1].toString();
		String rolename = objects[2].toString();
		String ip = objects[3].toString();
		
		int areaId = config.getAreaId();
		int serverId = config.getServerId();
		String domain = config.getDomain();
		String sign = getSign(timestamp,userId,roleId,rolename,ip,areaId,serverId);
		String datetime = getDateTime();
		generateUrl(timestamp,userId,roleId,rolename,ip,areaId,serverId,domain,sign,datetime);

	}

}
