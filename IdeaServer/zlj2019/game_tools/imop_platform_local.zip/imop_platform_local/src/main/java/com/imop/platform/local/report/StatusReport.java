package com.imop.platform.local.report;

import com.imop.platform.local.config.IConfig;
import com.imop.platform.local.response.IResponse;
import com.imop.platform.local.response.ReportResponse;

/**
 * 游戏server运行状态汇报接口<br>
 * 接口功能：<br>
 * 提供汇报游戏server运行状态功能。我们定义游戏服务从启动到关闭，需要经历以下的状态变化，游戏服务程序需要每分钟向local汇报一次当前的状态。
 * @author lu.liu
 *
 */
public class StatusReport extends AbstractReport {

	public StatusReport(IConfig config){
		super(config);
		this.page = "u.status.php" +
				"?timestamp=%s" +
				"&servers=%s" +
				"&status=%s" +
				"&extra=%s" +
				"&sign=%s" +
				"&areaid=%s"+
				"&serverid=%s";
	}

	@Override
	public IResponse getResponse(String[] args) {
		return new ReportResponse(args);
	}

	@Override
	public void setParams(Object... objects) {
		long timestamp = getTimestamp();
		String domain = config.getDomain();
		
		String servers = objects[0].toString();
		String status = objects[1].toString();
		String extra = objects[2].toString();
	
		String sign = getSign(timestamp,servers,domain,status,extra);
		generateUrl(timestamp,servers,status,extra,sign,""+config.getAreaId(),""+config.getServerId());
	}
	
	public static void main(String[] args){}
}
