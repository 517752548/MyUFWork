package com.imop.platform.local.response;

public class ActiveUseCodeResponse extends AbstractResponse {

	/**
	 * 玩家账号ID，默认为-1
	 */
	private long userId = -1;
	
	/**
	 * 获取账号ID
	 */
	public long getUserId() {
		return userId;
	}

	public ActiveUseCodeResponse(String[] args) {
		super(args, 2);
	}

	@Override
	public void onSuccess(String[] args) {
		userId = Long.valueOf(args[1]);

	}
	
}
