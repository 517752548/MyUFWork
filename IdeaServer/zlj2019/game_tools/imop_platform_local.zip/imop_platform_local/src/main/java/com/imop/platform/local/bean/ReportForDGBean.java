package com.imop.platform.local.bean;

import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

public class ReportForDGBean {
	
	/**
	 * "当前时间戳（毫秒数）
	 */
	private Long 	log_timestamp;
	/**
	 * UTC标准时间
	 */
	private String 	log_utctime;
	/**
	 * 服务器所在地域时间（即当地时间）
	 */
	private String 	log_localtime;
	/**
	 * 服务器主机名

	 */
	private String 	log_hostname;
	/**
	 * 服务器IP地址
	 */
	private String 	log_server_ip;
	/**
	 * 客户端IP地址，如果使用代理服务器则需要汇报最终真实的用户IP
	 */
	private String 	log_client_ip;
	/**
	 * 日志类型（此项由数据组确定）
	 */
	private String 	log_type="data.game.login";
	/**
	 * 可选，日志记录的唯一编号，如果游戏Log Db对应记录可以获得自增id就可以填写这一列，如果不填写，Log发送程序会自动填写
	 */
	private Integer	log_serial_no;
	/**
	 * 可选，缺省为空串, 可以随意记录任何数据，用于对账记录便于查询和筛选的标志字符串
	 */
	private String 	log_note;
	/**
	 * 游戏code（此项由数据组确定）
	 */
	private String	game_id;
	/**
	 * 游戏平台code（此项由数据组确定）
	 */
	private String	platform_id;
	/**
	 * 大区ID（默认是1，天书等多local的游戏按照实际local ID汇报），默认是1
	 */
	private String	region_id;
	/**
	 * 服务器ID（默认是1001，天书、龙之刃等分线的游戏不需要汇报各线的ID，只需要汇报服务器ID如101），默认是1001
	 */
	private String	server_id;
	/**
	 * 服务器名（该服务器的实际名称，如果游戏不分服，比如Socail Game可以汇报游戏名称）
	 */
	private String	server_name;
	/**
	 * 服务器域名（服务器实际域名，如果游戏不分服可以汇报游戏域名），不带http:// 和斜线，全小写。
	 */
	private String	server_domain;
	/**
	 * 平台账号ID
	 */
	private String	account_id;
	/**
	 * 平台账号名（登录名），全小写。
	 */
	private String	account_name;
	/**
	 * 角色ID
	 */
	private String	char_id;
	/**
	 * 角色名
	 */
	private String	char_name;
	/**
	 * 角色等级（用户的核心评价数据，如无等级的游戏可以使用主城的等级、人口、声望等），默认为0
	 */
	private String	char_level;
	/**
	 * VIP等级（用户的充值vip等级，如果没有此字段可以设置为-1），默认为0
	 */
	private String	char_vip;
	/**
	 * "终端设备分类，全小写。
	 * 枚举为：pc，ios，android。"
	 */
	private String	device;
	/**
	 * "设备型号，例如：ipad/iphone/htc，全小写。
	 * 1、ios：通过[[UIDevice currentDevice] model]获取
	 * 2、android：通过Build的Model来获取
	 * 3、获取不到此项置为：-1"
	 */
	private String	device_type;
	/**
	 * "操作系统版本，全小写。
	 * 1、ios：通过[[UIDevice currentDevice] systemVersion]获取
	 * 2、android：通过Build的Release来获取
	 * 3、获取不到此项置为-1"
	 */
	private String	device_version;
	/**
	 * "设备唯一识别id，md5( )，32位小写。
	 * 1、ios设备获取方法：md5(Mac)
	 * 2、android设备获取方法：md5(serialno_deviceid_macaddress)
	 * 其中各参数说明
	 * a).serialno  序列号，android2.2版本以后可以通过从android.os.SystemProperties获取ro.serialno
	 * b).deviceid  通过TelephonyManager的getDeviceId()来获取
	 * c). macaddress 无线网卡地址，通过WifiManager 的getMacAddress()来获取
	 * 3、获取不到此项置为-1"
	 */
	private String	device_guid;
	/**
	 * 设备MAC地址，去冒号，全小写，例如：40:30:04:e7:0f:24 应填写为：403004e70f24，无法获取填写：-1
	 */
	private String	device_mac;
	/**
	 * 设备IMEI串号，全小写，例如：868623010841302，无法获取填写：-1
	 */
	private String	device_imei;
	/**
	 * 设备User-Agent标识，无法获取填写：-1
	 */
	private String	device_user_agent;
	/**
	 * 设备接入网络环境，全小写，例如：wifi/3g/2g/wwan，如无法获取网络环境请填写：-1
	 */
	private String	device_connect_type;
	/**
	 * "IOS设备属性：是否越狱。
	 * 1、越狱：1
	 * 2、未越狱：0
	 * 3、未知/默认：-1"
	 */
	private Integer	device_jailbroken;
	/**
	 * "登录行为。
	 * 1、登入：login
	 * 2、登出：logout"
	 */
	private String	login_action;
	/**
	 * 当前会话登入类型：全小写。
	 * 1、如果是用户名密码登陆，请记录pwd。平台local接口对应为：u.login.php中logintype为1或4.
	 * 2、如果是cookie登陆，请记录cookie。平台local接口对应为：u.login.php中logintype为2。
	 * 3、如果是IOS快客登陆，请记录为quicklogin，平台local接口对应为：u.quicklogin.php。
	 * 4、如果是渠道用户登陆，请记录为channeluserlogin，平台local接口对应为：u.channeluserlogin.php。
	 * 5、如果是GM登陆，请记录为gm，平台local接口对应为：u.gmlogin.php。"
	 */
	private String	login_type;
	/**
	 * 记录上次登入的时间
	 */
	private Long	last_login_time;
	/**
	 * 截止到当前行为发生为止的累计登录时长，单位为秒
	 */
	private Integer	total_login_time;
	/**
	 * "渠道编号：只有login_type=4时需要填写
	 * 1、如果是用户名密码登陆，不需要填写。
	 * 2、如果是cookie登陆，不需要填写。
	 * 3、如果是IOS快客登陆，不需要填写。
	 * 4、如果是渠道用户登陆，请记录对应的渠道编号。（即u.channeluserlogin.php的channelcode参数）
	 * 5、如果是GM登陆，不需要填写。"
	 */
	private String	channel_code;
	/**
	 * "渠道编号：只有login_type=3或4时需要填写
	 * 1、如果是用户名密码登陆，不需要填写。
	 * 2、如果是cookie登陆，不需要填写。
	 * 3、如果是IOS快客登陆，请记录对应的渠道用户ID。（即u.quicklogin.php的uuid参数）
	 * 4、如果是渠道用户登陆，请记录对应的渠道用户ID。（即u.channeluserlogin.php的channeluserid参数）
	 * 5、如果是GM登陆，不需要填写。"
	 */
	private String	channel_userid;
	/**
	 * "可选，推广码，即F值
	 * 如果是混服请务必填写，此F值关系到对账。"
	 */
	private String	promotion_code;
	
	/**
	 * 汇报代理
	 * 统一由平台汇报，SDK内统一设置为 platform-local-sdk；
	 */
	private String log_agent = "platform-local-sdk";
	
	/**
	 * UDID，此字段主要用于跟第三方进行推广效果核对，只接受系统原生的UDID，无法获取填写：-1
	 * 例如:c2d28ea9c5002896
	 * 1、IOS设备填写 UDID；
	 * 2、Android设备填写 ANDROID_ID；
	 * 3、Windows Phone设备填写 DeviceUniqueId；
	 * 
	 */
	private String device_udid = "-1";
	
	/**
	 * IOS IDFA，此字段主要用于跟第三方进行推广效果核对，IOS SDK版本 >=6 必须填写，无法获取填写：-1
	 * 例如:9ff8dc127e5c4a5198af4f58f6514806
	 * 使用ANE SDK的获取办法：
	 * var idfa:String = RenRenGamesKitHttpService.instance.getIDFA();
	 */
	private String device_idfa = "-1";
	
	/**
	 * IOS IDFV，此字段主要用于跟第三方进行推广效果核对，IOS SDK版本 >=6 必须填写，无法获取填写：-1
	 * 例如:f0f6309f206b41a5b79733a0eeacb3a6
	 * 使用ANE SDK的获取办法：
	 * var idfv:String = RenRenGamesKitHttpService.instance.getIDFV();  
	 */
	private String device_idfv = "-1";
	
	/**
	 * 
	 */
	private String log_version = "1.1";
	
	
	public ReportForDGBean() {
	}
	
	/**
	 * 创建汇报Bean，其他参数可通过set方法进行补充
	 * @param log_client_ip 客户端IP地址，如果使用代理服务器则需要汇报最终真实的用户IP
	 * @param server_name 服务器名（该服务器的实际名称，如果游戏不分服，比如Socail Game可以汇报游戏名称）
	 * @param device 终端设备分类，全小写。pc，ios，android
	 * @param device_type 
	 * 			设备型号，例如：ipad/iphone/htc，全小写。
	 * 			1、ios：通过[[UIDevice currentDevice] model]获取
	 * 			2、android：通过Build的Model来获取
	 * 			3、获取不到此项置为：-1
	 * @param device_version
	 * 			操作系统版本，全小写。
	 * 			1、ios：通过[[UIDevice currentDevice] systemVersion]获取
	 * 			2、android：通过Build的Release来获取
	 * 			3、获取不到此项置为-1
	 * @param device_guid
	 * 			设备唯一识别id，md5( )，32位小写。
	 * 			1、ios设备获取方法：md5(Mac)
	 * 			2、android设备获取方法：md5(serialno_deviceid_macaddress)
	 *			 	其中各参数说明
	 * 				a).serialno  序列号，android2.2版本以后可以通过从android.os.SystemProperties获取ro.serialno
	 * 				b).deviceid  通过TelephonyManager的getDeviceId()来获取
	 * 				c). macaddress 无线网卡地址，通过WifiManager 的getMacAddress()来获取
	 * 			3、获取不到此项置为-1
	 * @param device_mac 设备MAC地址，去冒号，全小写，例如：40:30:04:e7:0f:24 应填写为：403004e70f24，无法获取填写：-1
	 * @param device_imei 设备IMEI串号，全小写，例如：868623010841302，无法获取填写：-1
	 * @param device_user_agent 设备User-Agent标识，无法获取填写：-1
	 * @param device_connect_type 设备接入网络环境，全小写，例如：wifi/3g/2g/wwan，如无法获取网络环境请填写：-1
	 * @param device_jailbroken 
	 * 			IOS设备属性：是否越狱。
	 * 			1、越狱：1
	 * 			2、未越狱：0
	 * 			3、未知/默认：-1
	 * @param login_action
	 * 			登录行为。
	 * 			1、登入：login
	 * 			2、登出：logout
	 * @param login_type
	 * 			当前会话登入类型：全小写。
	 * 			1、如果是用户名密码登陆，请记录pwd。平台local接口对应为：u.login.php中logintype为1或4.
	 * 			2、如果是cookie登陆，请记录cookie。平台local接口对应为：u.login.php中logintype为2。
	 * 			3、如果是IOS快客登陆，请记录为quicklogin，平台local接口对应为：u.quicklogin.php。
	 * 			4、如果是渠道用户登陆，请记录为channeluserlogin，平台local接口对应为：u.channeluserlogin.php。
	 * 			5、如果是GM登陆，请记录为gm，平台local接口对应为：u.gmlogin.php。"
	 * @param last_login_time 记录上次登入的时间
	 * @param total_login_time 截止到当前行为发生为止的累计登录时长，单位为秒
	 * @param channel_code 
	 * 			渠道编号：只有login_type=4时需要填写
	 * 			1、如果是用户名密码登陆，不需要填写。
	 * 			2、如果是cookie登陆，不需要填写。
	 *  		3、如果是IOS快客登陆，不需要填写。
	 *  		4、如果是渠道用户登陆，请记录对应的渠道编号。（即u.channeluserlogin.php的channelcode参数）
	 *  		5、如果是GM登陆，不需要填写。
	 * @param channel_userid
	 * 			渠道编号：只有login_type=3或4时需要填写
	 * 			1、如果是用户名密码登陆，不需要填写。
	 * 			2、如果是cookie登陆，不需要填写。
	 * 			3、如果是IOS快客登陆，请记录对应的渠道用户ID。（即u.quicklogin.php的uuid参数）
	 * 			4、如果是渠道用户登陆，请记录对应的渠道用户ID。（即u.channeluserlogin.php的channeluserid参数）
	 * 			5、如果是GM登陆，不需要填写。
	 * @param promotion_code
	 * 			可选，推广码，即F值
	 * 			如果是混服请务必填写，此F值关系到对账。
	 */
	public ReportForDGBean(String log_client_ip, String server_name,
			String device, String device_type, String device_version,
			String device_guid, String device_mac, String device_imei,
			String device_user_agent, String device_connect_type,
			Integer device_jailbroken, String login_action, String login_type,
			Long last_login_time, Integer total_login_time,
			String channel_code, String channel_userid, String promotion_code) {
		super();
		this.log_client_ip = log_client_ip;
		this.server_name = server_name;
		this.device = device;
		this.device_type = device_type;
		this.device_version = device_version;
		this.device_guid = device_guid;
		this.device_mac = device_mac;
		this.device_imei = device_imei;
		this.device_user_agent = device_user_agent;
		this.device_connect_type = device_connect_type;
		this.device_jailbroken = device_jailbroken;
		this.login_action = login_action;
		this.login_type = login_type;
		this.last_login_time = last_login_time;
		this.total_login_time = total_login_time;
		this.channel_code = channel_code;
		this.channel_userid = channel_userid;
		this.promotion_code = promotion_code;
	}
	/**
	 * 创建logout汇报Bean，其他参数可通过set方法进行补充
	 * @param log_client_ip 客户端IP地址，如果使用代理服务器则需要汇报最终真实的用户IP
	 * @param server_name 服务器名（该服务器的实际名称，如果游戏不分服，比如Socail Game可以汇报游戏名称）
	 * @param device 终端设备分类，全小写。pc，ios，android
	 * @param device_type 
	 * 			设备型号，例如：ipad/iphone/htc，全小写。
	 * 			1、ios：通过[[UIDevice currentDevice] model]获取
	 * 			2、android：通过Build的Model来获取
	 * 			3、获取不到此项置为：-1
	 * @param device_version
	 * 			操作系统版本，全小写。
	 * 			1、ios：通过[[UIDevice currentDevice] systemVersion]获取
	 * 			2、android：通过Build的Release来获取
	 * 			3、获取不到此项置为-1
	 * @param device_guid
	 * 			设备唯一识别id，md5( )，32位小写。
	 * 			1、ios设备获取方法：md5(Mac)
	 * 			2、android设备获取方法：md5(serialno_deviceid_macaddress)
	 *			 	其中各参数说明
	 * 				a).serialno  序列号，android2.2版本以后可以通过从android.os.SystemProperties获取ro.serialno
	 * 				b).deviceid  通过TelephonyManager的getDeviceId()来获取
	 * 				c). macaddress 无线网卡地址，通过WifiManager 的getMacAddress()来获取
	 * 			3、获取不到此项置为-1
	 * @param device_mac 设备MAC地址，去冒号，全小写，例如：40:30:04:e7:0f:24 应填写为：403004e70f24，无法获取填写：-1
	 * @param device_imei 设备IMEI串号，全小写，例如：868623010841302，无法获取填写：-1
	 * @param device_user_agent 设备User-Agent标识，无法获取填写：-1
	 * @param device_connect_type 设备接入网络环境，全小写，例如：wifi/3g/2g/wwan，如无法获取网络环境请填写：-1
	 * @param device_jailbroken 
	 * 			IOS设备属性：是否越狱。
	 * 			1、越狱：1
	 * 			2、未越狱：0
	 * 			3、未知/默认：-1
	 * @param last_login_time 记录上次登入的时间
	 * @param total_login_time 截止到当前行为发生为止的累计登录时长，单位为秒
	 * @param promotion_code
	 * 			可选，推广码，即F值
	 * 			如果是混服请务必填写，此F值关系到对账。
	 */
	public ReportForDGBean(String log_client_ip, String server_name,
			String device, String device_type, String device_version,
			String device_guid, String device_mac, String device_imei,
			String device_user_agent, String device_connect_type,
			Integer device_jailbroken,Long last_login_time, Integer total_login_time,
			String promotion_code) {
		super();
		this.log_client_ip = log_client_ip;
		this.server_name = server_name;
		this.device = device;
		this.device_type = device_type;
		this.device_version = device_version;
		this.device_guid = device_guid;
		this.device_mac = device_mac;
		this.device_imei = device_imei;
		this.device_user_agent = device_user_agent;
		this.device_connect_type = device_connect_type;
		this.device_jailbroken = device_jailbroken;
		this.login_action =  "logout";
		this.login_type = "";
		this.last_login_time = last_login_time;
		this.total_login_time = total_login_time;
		this.channel_code = "";
		this.channel_userid = "";
		this.promotion_code = promotion_code;
	}
	/**
	 * "当前时间戳（毫秒数）
	 */
	public void setLog_timestamp(Long log_timestamp) {
		this.log_timestamp = log_timestamp;
	}
	/**
	 * UTC标准时间
	 */
	public void setLog_utctime(String log_utctime) {
		this.log_utctime = log_utctime;
	}
	/**
	 * 服务器所在地域时间（即当地时间）
	 */
	public void setLog_localtime(String log_localtime) {
		this.log_localtime = log_localtime;
	}
	/**
	 * 服务器主机名,本方法由Jar包自行设置值
	 */
	@Deprecated
	public void setLog_hostname(String log_hostname) {
		this.log_hostname = log_hostname;
	}
	/**
	 * 服务器IP地址,本方法由Jar包自行设置值
	 */
	@Deprecated
	public void setLog_server_ip(String log_server_ip) {
		this.log_server_ip = log_server_ip;
	}
	/**
	 * 客户端IP地址，如果使用代理服务器则需要汇报最终真实的用户IP
	 */
	public void setLog_client_ip(String log_client_ip) {
		this.log_client_ip = log_client_ip;
	}
	/**
	 * 日志类型（此项由数据组确定）
	 */
	public void setLog_type(String log_type) {
		this.log_type = log_type;
	}
	/**
	 * 可选，日志记录的唯一编号，如果游戏Log Db对应记录可以获得自增id就可以填写这一列，如果不填写，Log发送程序会自动填写
	 */
	public void setLog_serial_no(Integer log_serial_no) {
		this.log_serial_no = log_serial_no;
	}
	/**
	 * 可选，缺省为空串, 可以随意记录任何数据，用于对账记录便于查询和筛选的标志字符串
	 */
	public void setLog_note(String log_note) {
		this.log_note = log_note;
	}
	/**
	 * 游戏code（此项由数据组确定）
	 */
	public void setGame_id(String game_id) {
		this.game_id = game_id;
	}
	/**
	 * 游戏平台code（此项由数据组确定）
	 */
	public void setPlatform_id(String platform_id) {
		this.platform_id = platform_id;
	}
	/**
	 * 大区ID（默认是1，天书等多local的游戏按照实际local ID汇报），默认是1
	 */
	public void setRegion_id(String region_id) {
		this.region_id = region_id;
	}
	/**
	 * 服务器ID（默认是1001，天书、龙之刃等分线的游戏不需要汇报各线的ID，只需要汇报服务器ID如101），默认是1001
	 */
	public void setServer_id(String server_id) {
		this.server_id = server_id;
	}
	/**
	 * 服务器名（该服务器的实际名称，如果游戏不分服，比如Socail Game可以汇报游戏名称）
	 */
	public void setServer_name(String server_name) {
		this.server_name = server_name;
	}
	/**
	 * 服务器域名（服务器实际域名，如果游戏不分服可以汇报游戏域名），不带http:// 和斜线，全小写。
	 */
	public void setServer_domain(String server_domain) {
		this.server_domain = server_domain;
	}
	/**
	 * 平台账号ID
	 */
	public void setAccount_id(String account_id) {
		this.account_id = account_id;
	}
	/**
	 * 平台账号名（登录名），全小写。
	 */
	public void setAccount_name(String account_name) {
		this.account_name = account_name;
	}
	/**
	 * 角色ID
	 */
	public void setChar_id(String char_id) {
		this.char_id = char_id;
	}
	/**
	 * 角色名
	 */
	public void setChar_name(String char_name) {
		this.char_name = char_name;
	}
	/**
	 * 角色等级（用户的核心评价数据，如无等级的游戏可以使用主城的等级、人口、声望等），默认为0
	 */
	public void setChar_level(String char_level) {
		this.char_level = char_level;
	}
	/**
	 * VIP等级（用户的充值vip等级，如果没有此字段可以设置为-1），默认为0
	 */
	public void setChar_vip(String char_vip) {
		this.char_vip = char_vip;
	}
	/**
	 * "终端设备分类，全小写。
	 * 枚举为：pc，ios，android。"
	 */
	public void setDevice(String device) {
		this.device = device;
	}
	/**
	 * "设备型号，例如：ipad/iphone/htc，全小写。
	 * 1、ios：通过[[UIDevice currentDevice] model]获取
	 * 2、android：通过Build的Model来获取
	 * 3、获取不到此项置为：-1"
	 */
	public void setDevice_type(String device_type) {
		this.device_type = device_type;
	}
	/**
	 * "操作系统版本，全小写。
	 * 1、ios：通过[[UIDevice currentDevice] systemVersion]获取
	 * 2、android：通过Build的Release来获取
	 * 3、获取不到此项置为-1"
	 */
	public void setDevice_version(String device_version) {
		this.device_version = device_version;
	}
	/**
	 * "设备唯一识别id，md5( )，32位小写。
	 * 1、ios设备获取方法：md5(Mac)
	 * 2、android设备获取方法：md5(serialno_deviceid_macaddress)
	 * 其中各参数说明
	 * a).serialno  序列号，android2.2版本以后可以通过从android.os.SystemProperties获取ro.serialno
	 * b).deviceid  通过TelephonyManager的getDeviceId()来获取
	 * c). macaddress 无线网卡地址，通过WifiManager 的getMacAddress()来获取
	 * 3、获取不到此项置为-1"
	 */
	public void setDevice_guid(String device_guid) {
		this.device_guid = device_guid;
	}
	/**
	 * 设备MAC地址，去冒号，全小写，例如：40:30:04:e7:0f:24 应填写为：403004e70f24，无法获取填写：-1
	 */
	public void setDevice_mac(String device_mac) {
		this.device_mac = device_mac;
	}
	/**
	 * 设备IMEI串号，全小写，例如：868623010841302，无法获取填写：-1
	 */
	public void setDevice_imei(String device_imei) {
		this.device_imei = device_imei;
	}
	/**
	 * 设备User-Agent标识，无法获取填写：-1
	 */
	public void setDevice_user_agent(String device_user_agent) {
		this.device_user_agent = device_user_agent;
	}
	/**
	 * 设备接入网络环境，全小写，例如：wifi/3g/2g/wwan，如无法获取网络环境请填写：-1
	 */
	public void setDevice_connect_type(String device_connect_type) {
		this.device_connect_type = device_connect_type;
	}
	/**
	 * "IOS设备属性：是否越狱。
	 * 1、越狱：1
	 * 2、未越狱：0
	 * 3、未知/默认：-1"
	 */
	public void setDevice_jailbroken(Integer device_jailbroken) {
		this.device_jailbroken = device_jailbroken;
	}
	/**
	 * "登录行为。
	 * 1、登入：login
	 * 2、登出：logout"
	 */
	public void setLogin_action(String login_action) {
		this.login_action = login_action;
	}
	/**
	 * 当前会话登入类型：全小写。
	 * 1、如果是用户名密码登陆，请记录pwd。平台local接口对应为：u.login.php中logintype为1或4.
	 * 2、如果是cookie登陆，请记录cookie。平台local接口对应为：u.login.php中logintype为2。
	 * 3、如果是IOS快客登陆，请记录为quicklogin，平台local接口对应为：u.quicklogin.php。
	 * 4、如果是渠道用户登陆，请记录为channeluserlogin，平台local接口对应为：u.channeluserlogin.php。
	 * 5、如果是GM登陆，请记录为gm，平台local接口对应为：u.gmlogin.php。"
	 */
	public void setLogin_type(String login_type) {
		this.login_type = login_type;
	}
	/**
	 * 记录上次登入的时间
	 */
	public void setLast_login_time(Long last_login_time) {
		this.last_login_time = last_login_time;
	}
	/**
	 * 截止到当前行为发生为止的累计登录时长，单位为秒
	 */
	public void setTotal_login_time(Integer total_login_time) {
		this.total_login_time = total_login_time;
	}
	/**
	 * "渠道编号：只有login_type=4时需要填写
	 * 1、如果是用户名密码登陆，不需要填写。
	 * 2、如果是cookie登陆，不需要填写。
	 * 3、如果是IOS快客登陆，不需要填写。
	 * 4、如果是渠道用户登陆，请记录对应的渠道编号。（即u.channeluserlogin.php的channelcode参数）
	 * 5、如果是GM登陆，不需要填写。"
	 */
	public void setChannel_code(String channel_code) {
		this.channel_code = channel_code;
	}
	/**
	 * "渠道编号：只有login_type=3或4时需要填写
	 * 1、如果是用户名密码登陆，不需要填写。
	 * 2、如果是cookie登陆，不需要填写。
	 * 3、如果是IOS快客登陆，请记录对应的渠道用户ID。（即u.quicklogin.php的uuid参数）
	 * 4、如果是渠道用户登陆，请记录对应的渠道用户ID。（即u.channeluserlogin.php的channeluserid参数）
	 * 5、如果是GM登陆，不需要填写。"
	 */
	public void setChannel_userid(String channel_userid) {
		this.channel_userid = channel_userid;
	}
	/**
	 * "可选，推广码，即F值
	 * 如果是混服请务必填写，此F值关系到对账。"
	 */
	public void setPromotion_code(String promotion_code) {
		this.promotion_code = promotion_code;
	}
	
	public Long getLog_timestamp() {
		return log_timestamp;
	}

	public String getLog_utctime() {
		return log_utctime;
	}

	public String getLog_localtime() {
		return log_localtime;
	}

	public String getLog_hostname() {
		return log_hostname;
	}

	public String getLog_server_ip() {
		return log_server_ip;
	}

	public String getLog_client_ip() {
		return log_client_ip;
	}

	public String getLog_type() {
		return log_type;
	}

	public Integer getLog_serial_no() {
		return log_serial_no;
	}

	public String getLog_note() {
		return log_note;
	}

	public String getGame_id() {
		return game_id;
	}

	public String getPlatform_id() {
		return platform_id;
	}

	public String getRegion_id() {
		return region_id;
	}

	public String getServer_id() {
		return server_id;
	}

	public String getServer_name() {
		return server_name;
	}

	public String getServer_domain() {
		return server_domain;
	}

	public String getAccount_id() {
		return account_id;
	}

	public String getAccount_name() {
		return account_name;
	}

	public String getChar_id() {
		return char_id;
	}

	public String getChar_name() {
		return char_name;
	}

	public String getChar_level() {
		return char_level;
	}

	public String getChar_vip() {
		return char_vip;
	}

	public String getDevice() {
		return device;
	}

	public String getDevice_type() {
		return device_type;
	}

	public String getDevice_version() {
		return device_version;
	}

	public String getDevice_guid() {
		return device_guid;
	}

	public String getDevice_mac() {
		return device_mac;
	}

	public String getDevice_imei() {
		return device_imei;
	}

	public String getDevice_user_agent() {
		return device_user_agent;
	}

	public String getDevice_connect_type() {
		return device_connect_type;
	}

	public Integer getDevice_jailbroken() {
		return device_jailbroken;
	}

	public String getLogin_action() {
		return login_action;
	}

	public String getLogin_type() {
		return login_type;
	}

	public Long getLast_login_time() {
		return last_login_time;
	}

	public Integer getTotal_login_time() {
		return total_login_time;
	}

	public String getChannel_code() {
		return channel_code;
	}

	public String getChannel_userid() {
		return channel_userid;
	}

	public String getPromotion_code() {
		return promotion_code;
	}

	public String getLog_agent() {
		return log_agent;
	}

	public void setLog_agent(String log_agent) {
		this.log_agent = log_agent;
	}

	public String getDevice_udid() {
		return device_udid;
	}

	public void setDevice_udid(String device_udid) {
		this.device_udid = device_udid;
	}

	public String getDevice_idfa() {
		return device_idfa;
	}

	public void setDevice_idfa(String device_idfa) {
		this.device_idfa = device_idfa;
	}

	public String getDevice_idfv() {
		return device_idfv;
	}

	public void setDevice_idfv(String device_idfv) {
		this.device_idfv = device_idfv;
	}
	
	public String getLog_version() {
		return log_version;
	}

	public void setLog_version(String log_version) {
		this.log_version = log_version;
	}

	/**
	 * 信息补全
	 * @param log_timestamp 当前时间戳（毫秒数）
	 * @param log_utctime 	UTC标准时间
	 * @param log_localtime 服务器所在地域时间（即当地时间）
	 * @param game_id 游戏code（此项由数据组确定）
	 * @param platform_id 游戏平台code（此项由数据组确定）
	 * @param server_id 服务器ID（默认是1001，天书、龙之刃等分线的游戏不需要汇报各线的ID，只需要汇报服务器ID如101），默认是1001
	 * @param server_domain 服务器域名（服务器实际域名，如果游戏不分服可以汇报游戏域名），不带http:// 和斜线，全小写。
	 */
	public void complement(
			Long 	log_timestamp,
			String 	log_utctime,
			String 	log_localtime,
			String	game_id,
			String	platform_id,
			String	region_id,
			String	server_id,
			String	server_domain){
	 	this.log_timestamp=log_timestamp;
	 	this.log_utctime=log_utctime;
	 	this.log_localtime=log_localtime;
	 	this.log_hostname=getHostName();
	 	this.log_server_ip=getIp();
		this.game_id=game_id;
		this.platform_id=platform_id;
		this.region_id=region_id;
		this.server_id=server_id;
		this.server_domain=server_domain;		
	}
	private String getHostName(){
		try {
			return InetAddress.getLocalHost().getHostName();
		} catch (UnknownHostException e) {
			e.printStackTrace();
			return "";
		}
	}
	private String getIp(){
		TreeMap<Long,String> ipMap = new TreeMap<Long,String>();
		try{
			Enumeration allNetInterfaces = NetworkInterface.getNetworkInterfaces();
			InetAddress ip = null;
			while (allNetInterfaces.hasMoreElements())
			{
				NetworkInterface netInterface = (NetworkInterface) allNetInterfaces.nextElement();
				Enumeration addresses = netInterface.getInetAddresses();
				while (addresses.hasMoreElements())
				{
					ip = (InetAddress) addresses.nextElement();
					
					if (ip != null && ip instanceof Inet4Address && ip.toString().indexOf("127.0.0.1")==-1)
					{
						long ipLong =  ((long)ip.hashCode()) & 0xFFFFFFFFL;
						String ipString = ip.getHostAddress();
						ipMap.put(ipLong, ipString);
					}
				}
			}
			Set<Long> key = ipMap.keySet();
			Long minIp = key.iterator().next();
			return ipMap.get(minIp);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "";
	}
	
	/*
	public static void main(String [] args) {
		ReportForDGBean bean = new ReportForDGBean();
		String ip = bean.getIp();
		System.out.println(ip);
	}
	*/

}
