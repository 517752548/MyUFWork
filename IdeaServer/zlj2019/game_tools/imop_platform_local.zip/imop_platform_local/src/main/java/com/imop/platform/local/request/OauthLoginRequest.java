package com.imop.platform.local.request;

import com.imop.platform.local.config.IConfig;
import com.imop.platform.local.response.IResponse;
import com.imop.platform.local.response.LoginResponse;

public class OauthLoginRequest extends AbstractRequest {

	public OauthLoginRequest(IConfig config) {
		super(config);
		this.page="u.oauthlogin.php" +
		"?timestamp=%s" +
		"&token=%s" +
		"&channelcode=%s" +
		"&ip=%s" +
		"&areaid=%s" +
		"&serverid=%s" +
		"&domain=%s"+
		"&sign=%s" ;
	}

	@Override
	public IResponse getResponse(String[] args) {
		return new LoginResponse(args);
	}

	@Override
	public void setParams(Object... objects) {
		long timestamp = getTimestamp();
		String token =objects[0].toString();
		String channelcode = objects[1].toString();
		String ip = objects[2].toString();
		
		int areaId = config.getAreaId();
		int serverId = config.getServerId();
		String domain = config.getDomain();
		String sign = getSign(timestamp,token,channelcode,ip,areaId,serverId);
		String datetime = getDateTime();
		generateUrl(timestamp,token,channelcode,ip,areaId,serverId,domain,sign,datetime);
	

	}

}
