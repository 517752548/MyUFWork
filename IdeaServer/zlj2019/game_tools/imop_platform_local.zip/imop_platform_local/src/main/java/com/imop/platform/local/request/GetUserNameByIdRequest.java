package com.imop.platform.local.request;

import com.imop.platform.local.config.IConfig;
import com.imop.platform.local.response.GetUserNameByIdResponse;
import com.imop.platform.local.response.IResponse;

/**
 * 通过用户id获取用户名称接口<br>
 * 接口功能： <br>
 * 提供通过用户的id获取用户名称的功能。此接口为可选接口。
 * @author lu.liu
 *
 */
public class GetUserNameByIdRequest extends AbstractRequest {
	
	public GetUserNameByIdRequest(IConfig config){
		super(config);
		this.page = "u.getusernamebyid.php" +
				"?timestamp=%s" +
				"&userid=%s" +
				"&ip=%s" +
				"&areaid=%s" +
				"&serverid=%s" +
				"&sign=%s";
	}

	@Override
	public IResponse getResponse(String[] args) {
		return new GetUserNameByIdResponse(args);
	}

	@Override
	public void setParams(Object... objects) {
		long timestamp = getTimestamp();
		int areaId = config.getAreaId();
		int serverId = config.getServerId();
		
		long userId = Long.valueOf(objects[0].toString());
		
		String ip = objects[1].toString();
		
		String sign = getSign(timestamp,userId,ip,areaId,serverId);
		generateUrl(timestamp,userId,ip,areaId,serverId,sign);
	}

}
