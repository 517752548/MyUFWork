package com.imop.platform.local.response;

/**
 * 游戏世界余额查询的请求结果
 * @author lu.liu
 *
 */
public class QueryBalanceResponse extends AbstractResponse {

	/**
	 * 平台余额，默认为-1
	 */
	private int balance = -1;
	
	public QueryBalanceResponse(String[] args){
		super(args,2);
	}


	@Override
	public void onSuccess(String[] args) {
		balance = Integer.valueOf(args[1]);
	}
	
	/**
	 * 获取玩家平台余额
	 * @return	玩家平台余额
	 */
	public int getBalance() {
		return balance;
	}
}
