package com.imop.platform.local.response;

/**
 * 汇报类的处理结果
 * @author lu.liu
 *
 */
public class ReportResponse extends AbstractResponse {
	
	/**
	 * 汇报状态值，默认为-1
	 */
	private int status = -1;
	
	public ReportResponse(String[] args){
		super(args, 2);
	}

	@Override
	public void onSuccess(String[] args) {
		status = Integer.valueOf(args[1]);
	}

	/**
	 * 获取状态汇报值
	 * @return	状态汇报值
	 */
	public int getStatus(){
		return status;
	}
}
