package com.imop.platform.local.response;

import java.util.ArrayList;


import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

public class ExchangeRechargeResponse extends AbstractResponse {

	private String json_str = "";
	
	/**
	 * 充值信息，如果无充值信息，则长度为0.
	 */
	private ArrayList<Order> recharge = new ArrayList<Order>();
	
	public ExchangeRechargeResponse(String[] args) {
		super(args,2);
	}
	
//	public static void main(String[]args) {
//		ExchangeRechargeResponse response = new ExchangeRechargeResponse(new String[]{"OK",""});
//		response.onSuccess(new String[]{"","{\"recharge\":[{\"id\":\"3183\",\"user_id\":\"255237508\",\"user_name\":null,\"order_id\":\"6000201212279504250380754715\",\"third_pay_id\":\"201212271856490796982\",\"pay_channel\":\"rrdou\",\"sub_channel\":null,\"amount\":\"10.00\",\"currency\":\"RRDOU\",\"item_id\":\"430\",\"game_points\":\"100\",\"type\":\"GAME\",\"device_type\":null,\"device_version\":null,\"udid\":null,\"device_id\":null,\"areaid\":null,\"serverid\":null,\"game_code\":\"cq\",\"game_domain\":\"cq.renren.com\",\"game_server_domain\":\"m1.cq.renren.com\",\"char_id\":null,\"char_name\":null,\"add_time\":\"1356605809\",\"expend_time\":\"0\",\"delay_time\":\"0\",\"terminal\":\"android\",\"remark\":null,\"chargetype\":\"expend\"}]}"});
//		System.out.println(response);
//	}

	@Override
	public void onSuccess(String[] args) {
		this.json_str = args[1].toString();
		String json_value = this.getJsonValue(JSONObject.fromObject(this.json_str),"recharge");
		JSONArray json_arr = JSONArray.fromObject(json_value);
		for(int i=0;i<json_arr.size();i++){
			JSONObject json_temp = json_arr.getJSONObject(i);
			Order order = new Order();
			order.id=this.getJsonValue(json_temp,"id");
			order.user_id=this.getJsonValue(json_temp,"user_id");
			order.user_name=this.getJsonValue(json_temp,"user_name");
			order.order_id=this.getJsonValue(json_temp,"order_id");
			order.amount=this.getJsonValue(json_temp,"amount");
			order.currency=this.getJsonValue(json_temp,"currency");
			order.item_id=this.getJsonValue(json_temp,"item_id");
			order.game_points=this.getJsonValue(json_temp,"game_points");
			order.type=this.getJsonValue(json_temp,"type");
			order.udid=this.getJsonValue(json_temp,"udid");
			order.device_id=this.getJsonValue(json_temp,"device_id");
			order.game_code=this.getJsonValue(json_temp,"game_code");
			order.game_domain=this.getJsonValue(json_temp,"game_domain");
			order.game_server_domain=this.getJsonValue(json_temp,"game_server_domain");
			order.char_id=this.getJsonValue(json_temp,"char_id");
			order.char_name=this.getJsonValue(json_temp,"char_name");
			order.add_time=this.getJsonValue(json_temp,"add_time");
			order.expend_time=this.getJsonValue(json_temp,"expend_time");
			order.delay_time=this.getJsonValue(json_temp,"delay_time");
			order.terminal=this.getJsonValue(json_temp,"terminal");
			order.remark=this.getJsonValue(json_temp,"remark");
			order.chargetype=this.getJsonValue(json_temp,"chargetype");
			order.pay_channel=this.getJsonValue(json_temp,"pay_channel");
			order.sub_channel=this.getJsonValue(json_temp,"sub_channel");
			recharge.add(order);
		}
	}
	/**
	 * 充值信息，如果无充值信息，则长度为0.
	 */
	public ArrayList<Order> getRecharge() {
		return recharge;
	}

	/**
	 * 内部类，用于存储一条充值信息
	 * @author jiang.li
	 *
	 */
	public class Order{
		/**
		 * 唯一ID
		 */
		public String id;
		/**
		 * 用户Id
		 */
		public String user_id;
		/**
		 * 用户名
		 */
		public String user_name;
		/**
		 * 订单流水号
		 */
		public String order_id;
		/**
		 * 金额
		 */
		public String amount;
		/**
		 * 币种
		 */
		public String currency;
		/**
		 * 套餐ID
		 */
		public String item_id;
		/**
		 * 游戏币
		 */
		public String game_points;
		/**
		 * 充值类型，IOS、PLATFORM、GAME等
		 */
		public String type;
		/**
		 * 苹果终端号
		 */
		public String udid;
		/**
		 * MAC信息
		 */
		public String device_id;
		/**
		 * 游戏唯一code
		 */
		public String game_code;
		/**
		 * 游戏唯一域名
		 */
		public String game_domain;
		/**
		 * 游戏服唯一域名
		 */
		public String game_server_domain;
		/**
		 * 角色ID
		 */
		public String char_id;
		/**
		 * 角色名
		 */
		public String char_name;
		/**
		 * 添加时间
		 */
		public String add_time;
		/**
		 * 消费时间
		 */
		public String expend_time;
		/**
		 * 延迟获取时间
		 */
		public String delay_time;
		/**
		 * 终端类型
		 */
		public String terminal;
		/**
		 * 备注信息
		 */
		public String remark;
		
		/**
		 * 消耗类型
		 */
		public String chargetype = null;
		
		/**
		 * 渠道
		 */
		public String pay_channel = null;
		
		/**
		 * 子渠道
		 */
		public String sub_channel = null;

		public String getId() {
			return id;
		}

		public String getUser_id() {
			return user_id;
		}

		public String getUser_name() {
			return user_name;
		}

		public String getOrder_id() {
			return order_id;
		}

		public String getAmount() {
			return amount;
		}

		public String getCurrency() {
			return currency;
		}

		public String getItem_id() {
			return item_id;
		}

		public String getGame_points() {
			return game_points;
		}

		public String getType() {
			return type;
		}

		public String getUdid() {
			return udid;
		}

		public String getDevice_id() {
			return device_id;
		}

		public String getGame_code() {
			return game_code;
		}

		public String getGame_domain() {
			return game_domain;
		}

		public String getGame_server_domain() {
			return game_server_domain;
		}

		public String getChar_id() {
			return char_id;
		}

		public String getChar_name() {
			return char_name;
		}

		public String getAdd_time() {
			return add_time;
		}

		public String getExpend_time() {
			return expend_time;
		}

		public String getDelay_time() {
			return delay_time;
		}

		public String getTerminal() {
			return terminal;
		}

		public String getRemark() {
			return remark;
		}

		public String getChargetype() {
			return chargetype;
		}

		public String getPay_channel() {
			return pay_channel;
		}

		public String getSub_channel() {
			return sub_channel;
		}
	}

}
