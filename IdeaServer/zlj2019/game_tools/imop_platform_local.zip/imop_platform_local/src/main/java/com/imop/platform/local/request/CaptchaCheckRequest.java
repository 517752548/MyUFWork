package com.imop.platform.local.request;

import com.imop.platform.local.config.IConfig;
import com.imop.platform.local.response.CaptchaCheckResponse;
import com.imop.platform.local.response.IResponse;

public class CaptchaCheckRequest extends AbstractRequest {

	public CaptchaCheckRequest(IConfig config) {
		super(config);
	}

	@Override
	public IResponse getResponse(String[] args) {
		return new CaptchaCheckResponse(args);
	}

	@Override
	public void setParams(Object... objects) {

	}

}
