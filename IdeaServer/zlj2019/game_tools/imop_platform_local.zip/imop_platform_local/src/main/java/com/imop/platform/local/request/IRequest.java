package com.imop.platform.local.request;

import java.util.Map;
import java.util.TreeSet;
import java.util.concurrent.Future;

import com.imop.platform.local.callback.ICallback;
import com.imop.platform.local.response.IResponse;

/**
 * 游戏对平台的HTTP请求接口
 * @author lu.liu
 *
 */
public interface IRequest {
	
	/**
	 * 发送同步接口请求
	 * @return	请求结果
	 */
	public IResponse send();
	
	/**
	 * 发送同步接口请求 ,如果statu=true则采用新式数据请求方式，如果statu=false则采用就是的数据请求方式
	 * @return	请求结果
	 */
	public IResponse send(boolean statu);
	/**
	 * 发送异步接口请求
	 * @param callback	回调接口
	 * @return
	 */
	public Future<IResponse> asyncSend(ICallback callback);
	
	/**
	 * 获取请求结果
	 * @param args	参数数组
	 * @return		请求结果
	 */
	public IResponse getResponse(String[] args);
	
	/**
	 * 获取MD5后的标识
	 * @param objects
	 * @return
	 */
	public String getSign(Object...objects);
	
	public String createSign(TreeSet<String> param_set);
	
	/**
	 * 生成URL
	 * @param objects	URL参数值
	 */
	public void generateUrl(Object...objects);
	
	/**
	 * 根据新加密规则生成URL
	 * @param objects	URL参数值
	 */
	public void getUrl(Object...objects);
	/**
	 * 设置参数值
	 * @param objects	URL参数值
	 */
	public void setParams(Object...objects);
	
	public void genOptinalURL(String page,Map<String,Object> params);
	
	public IResponse sendByPost(boolean statu);

	public Future<IResponse> asyncSend(final boolean responseJson,final ICallback callback);
	
}
