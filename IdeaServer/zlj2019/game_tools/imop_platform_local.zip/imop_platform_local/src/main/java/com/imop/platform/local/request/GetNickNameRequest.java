package com.imop.platform.local.request;

import com.imop.platform.local.config.IConfig;
import com.imop.platform.local.response.GetNickNameResponse;
import com.imop.platform.local.response.IResponse;

/**
 * 通过人人用户id获取昵称<br>
 * 接口功能：<br>
 * 通过人人用户id获取昵称。
 * @author lu.liu
 *
 */
public class GetNickNameRequest extends AbstractRequest {
	
	public GetNickNameRequest(IConfig config){
		super(config);
		this.page = "u.getnickname.php?userid=%s&domain=%s&sign=%s&currenttime=%s";
	}

	@Override
	public IResponse getResponse(String[] args) {
		return new GetNickNameResponse(args);
	}

	@Override
	public void setParams(Object... objects) {
		String domain = config.getDomain();
		
		long userId = Long.valueOf(objects[0].toString());
		
		String sign = getSign(userId);
		String datetime = getDateTime();
		generateUrl(userId,domain,sign,datetime);		
	}

}
