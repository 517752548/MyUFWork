package com.imop.platform.local.response;

public class GetUserIdByChannelNameResponse extends AbstractResponse {
	

	/**
	 * 玩家账号ID，默认为-1
	 */
	private long userId = -1;
	
	/**
	 * 获取玩家账号ID
	 * @return 玩家账号ID
	 */
	public long getUserId() {
		return userId;
	}
	
	public GetUserIdByChannelNameResponse(String[] args) {
		super(args, 2);
	}
	@Override
	public void onSuccess(String[] args) {

		userId = Long.valueOf(args[1]);

	}

}
