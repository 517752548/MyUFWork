package com.imop.platform.local.util;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.Enumeration;
import java.util.jar.Attributes;
import java.util.jar.Manifest;

/**
 * 获取JAR版本号信息
 * @author lu.liu
 *
 */
public class VersionUtil {
	
	/**
	 *	当前服务器运行的版本号 
	 */
	private static String serverVersion = null;
	
	/**
	 * 获取当前服务器运行的版本号
	 * @return	当前服务器运行的版本号
	 */
	public static String getServerVersion() {
		if (serverVersion == null) {
			String _version = null;
			Enumeration<URL> resources = null;
			try {
				resources = Thread.currentThread().getContextClassLoader().getResources("META-INF/MANIFEST.MF");
				_version = findInManifest(resources, "Platform-Version");
			} catch (IOException e) {
				e.printStackTrace();
			}
			if (_version == null) {
				_version = "Unknown";
			}
			serverVersion = _version;
		}
		return serverVersion;
	}
	
	static String findInManifest(final Enumeration<URL> resources, final String attributeName) {
		String _version = null;
		URL _foundUrl = null;
		while (resources.hasMoreElements()) {
			URL _url = resources.nextElement();
			InputStream _in = null;
			Manifest _manifest = null;
			try {
				_in = _url.openStream();
				_manifest = new Manifest(_in);
			} catch (Exception ioe) {
				ioe.printStackTrace();
			} finally {
				if (_in != null) {
					try {
						_in.close();
					} catch (Exception e) {
					}
				}
			}
			if (_manifest == null) {
				continue;
			}
			Attributes _mainAttributes = _manifest.getMainAttributes();
			if (_mainAttributes == null) {
				continue;
			}
			String _versionAttr = _mainAttributes.getValue(attributeName);
			if (_versionAttr != null) {
				if (_version == null) {
					_version = _versionAttr;
					_foundUrl = _url;
				} else {
					throw new IllegalStateException("Found a duplicate " + attributeName + " at " + _url + ",which is "
							+ _versionAttr + ".The previous url is " + _foundUrl);
				}
			}
		}
		return _version;
	}

}
