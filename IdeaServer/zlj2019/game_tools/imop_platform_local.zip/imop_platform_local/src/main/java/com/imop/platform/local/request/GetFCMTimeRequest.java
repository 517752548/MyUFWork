package com.imop.platform.local.request;

import com.imop.platform.local.config.IConfig;
import com.imop.platform.local.response.GetFCMTimeResponse;
import com.imop.platform.local.response.IResponse;

public class GetFCMTimeRequest extends AbstractRequest {

	public GetFCMTimeRequest(IConfig config) {
		super(config);
		this.page="u.getfcmtime.php?timestamp=%s" +
				"&userid=%s" +
				"&ip=%s" +
				"&areaid=%s" +
				"&serverid=%s" +
				"&domain=%s" +
				"&currenttime=%s" +
				"&sign=%s";
	}

	@Override
	public IResponse getResponse(String[] args) {
		// TODO Auto-generated method stub
		return new GetFCMTimeResponse(args);
	}

	@Override
	public void setParams(Object... objects) {
		long timestamp = getTimestamp();
		int areaid = config.getAreaId();
		int serverid = config.getServerId();
		String domain = config.getDomain();		
		
		long userid = Long.valueOf(objects[0].toString());
		String ip = objects[1].toString();
		long currenttime = Long.valueOf(objects[2].toString());
		
		String sign = getSign(timestamp, userid,ip,areaid,serverid);
		generateUrl(timestamp, userid, ip, areaid, serverid,domain,currenttime,sign);

	}

}
