package com.imop.platform.local.response;

import net.sf.json.JSONObject;

/**
 * 游戏世界兑换游戏币的请求结果
 * @author lu.liu
 *
 */
public class TransferResponse extends AbstractResponse {
	
	/**
	 * 账号ID，默认为-1
	 */
	private long userId = -1;
	
	/**
	 * 平台余额，默认为-1
	 */
	private int balance = -1;
	
	/**
	 * 订单ID，默认为null；
	 */ 
	private String orderID = null;
	
	/**
	 * 该笔兑换平台币数量,默认为0;
	 */
	private double money = 0;
	
	/**
	 * 币种类型（目前为RRDOU，表示平台币）
	 */
	private String currency = null;
	
	/**
	 * 消耗类型 （目前为expend,表示兑换）
	 */
	private String chargetype = null;
	
	/**
	 * 渠道（目前为renren，表示人人渠道）
	 */
	private String pay_channel = null;
	
	/**
	 * 子渠道（目前为空字符串，表示没有子渠道）
	 */
	private String sub_channel = null;
	
	
	public TransferResponse(String[] args){
		super(args, 2);
	}

	@Override
	public void onSuccess(String[] args) {
//		userId = Long.valueOf(args[1]);
//		balance = Integer.valueOf(args[2]);
//		if(args.length>=4){
//			orderID = args[3];
//		}
//		if(args.length>=5){
//			money = Long.valueOf(args[4]);
//		}
		
		String json_str = args[1];
		JSONObject o = JSONObject.fromObject(json_str);
		userId = o.getLong("user_id");
		balance = o.getInt("balance");
		orderID = getJsonValue(o, "orderid");// o.getString("orderid");
		money = o.getDouble("amount");
		currency = getJsonValue(o, "currency");//o.getString("currency");
		chargetype = getJsonValue(o, "chargetype");//o.getString("chargetype");
		pay_channel = getJsonValue(o, "pay_channel");//o.getString("pay_channel");
		sub_channel = getJsonValue(o, "sub_channel");//o.getString("sub_channel");
		
	}
	
	/**
	 * 获取账号ID
	 * @return	账号ID
	 */
	public long getUserId(){
		return userId;
	}
	
	/**
	 * 获取平台余额
	 * @return	平台余额
	 */
	public int getBalance(){
		return balance;
	}
	/**
	 * 获取订单ID
	 * @return 订单ID
	 */
	public String getOrderID() {
		return orderID;
	}

	/**
	 * 获取该笔兑换平台币数量
	 * @return 该笔兑换平台币数量
	 */
	public double getMoney() {
		return money;
	}

	public String getCurrency() {
		return currency;
	}

	public String getChargetype() {
		return chargetype;
	}

	public String getPay_channel() {
		return pay_channel;
	}

	public String getSub_channel() {
		return sub_channel;
	}

	

	
}
