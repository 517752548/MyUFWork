package com.imop.platform.local.request;

import java.io.UnsupportedEncodingException;

import org.apache.commons.codec.digest.DigestUtils;

import com.imop.platform.local.config.IConfig;
import com.imop.platform.local.response.CreateIOSPaymentResponse;
import com.imop.platform.local.response.IResponse;

public class CreateIOSPaymentRequest extends AbstractRequest {

	public CreateIOSPaymentRequest(IConfig config) {
		super(config);
		this.page = "u.createiospayment.php?" +
				"timestamp=%s&" +
				"userid=%s&" +
				"roleid=%s&" +
				"item_table=%s&" +
				"token=%s&" +
				"ip=%s&" +
				"udid=%s&" +
				"areaid=%s&" +
				"serverid=%s&" +
				"domain=%s&" +
				"macInfo=%s&"+
				"uuid=%s&" +
				"sign=%s";
	}

	@Override
	public IResponse getResponse(String[] args) {
		return new CreateIOSPaymentResponse(args);
	}

	@Override
	public void setParams(Object... objects) {
		long timestamp = getTimestamp();
		
		long userId = Long.valueOf(objects[0].toString());
		String roleId = objects[1].toString();
		String ip = objects[2].toString();
		String item_table = objects[3].toString();
		String token = objects[4].toString();
		String udid = objects[5].toString();
		String uuid = objects[6].toString();
		String macInfo = objects[7].toString();
		int areaId = config.getAreaId();
		int serverId = config.getServerId();
		String domain = config.getDomain();
		
		String sign = getSign(timestamp,userId,roleId,token,ip,udid,areaId,serverId);
		generateUrl(timestamp,userId,roleId,item_table,token,ip,udid,areaId,serverId,domain,macInfo,uuid,sign);
	}
	/* (non-Javadoc)
	 * @see com.imop.platform.request.IRequest#send()
	 */
	@Override
	public IResponse send() {
		try {
			return doRequest(true);
		} catch (Exception e) {
			config.getRecord().recordError("#LOCAL.PLATFORM.REQUEST.ERROR:" + url, e);
			return getFailResponse();
		}
	}

}
