package com.imop.platform.local.response;

/**
 * 用户退出游戏的请求结果
 * @author lu.liu
 *
 */
public class LogoutResponse extends AbstractResponse {
	
	/**
	 * 玩家账号ID，默认为-1
	 */
	private long userId = -1;
	
	public LogoutResponse(String[] args){
		super(args, 2);
	}

	@Override
	public void onSuccess(String[] args) {
		userId = Long.valueOf(args[1]);
	}
	
	/**
	 * 获取玩家账号ID
	 * @return	玩家账号ID
	 */
	public long getUserId() {
		return userId;
	}

}
