package com.imop.platform.local.response;

import net.sf.json.JSONObject;

public class GenerateOrderResponse extends AbstractResponse {

	protected String gameOrderId;
	
	public GenerateOrderResponse(String[] args) {
		super(args, 2);
	}

	@Override
	public void onSuccess(String[] args) {
		String json_str = args[1];
		JSONObject o = JSONObject.fromObject(json_str);
		if(o.has("gameOrderId")) gameOrderId = o.getString("gameOrderId");
	}

	public String getGameOrderId() {
		return gameOrderId;
	}

	public void setGameOrderId(String gameOrderId) {
		this.gameOrderId = gameOrderId;
	}

}
