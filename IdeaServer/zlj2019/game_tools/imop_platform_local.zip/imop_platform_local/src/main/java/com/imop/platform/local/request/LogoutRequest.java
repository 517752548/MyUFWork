package com.imop.platform.local.request;

import java.text.SimpleDateFormat;
import java.util.Date;

import net.sf.json.JSONObject;

import com.imop.platform.local.bean.ReportForDGBean;
import com.imop.platform.local.config.IConfig;
import com.imop.platform.local.response.IResponse;
import com.imop.platform.local.response.LogoutResponse;

/**
 * 用户退出游戏接口<br>
 * 接口功能：<br>
 * 提供记录用户登出游戏功能，玩家退出游戏需要调用此接口。
 * @author lu.liu
 *
 */
public class LogoutRequest extends AbstractRequest {

	public LogoutRequest(IConfig config){
		super(config);
		this.page = "u.logout.php" +
				"?timestamp=%s" +
				"&userid=%s" +
				"&ip=%s" +
				"&areaid=%s" +
				"&serverid=%s" +
				"&sign=%s" +
				"&dataext=%s" ;
	}

	@Override
	public IResponse getResponse(String[] args) {
		return new LogoutResponse(args);
	}

	@Override
	public void setParams(Object... objects) {
		long timestamp = getTimestamp();
		int areaId = config.getAreaId();
		int serverId = config.getServerId();

		long userId = Long.valueOf(objects[0].toString());
		String ip = objects[1].toString();
		
		ReportForDGBean bean = (ReportForDGBean) objects[2];
		long date= System.currentTimeMillis()/1000;
		//System.out.println(date);
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		java.util.Calendar cal = java.util.Calendar.getInstance();   
	    cal.setTime(new Date(date*1000));
		int zoneOffset = cal.get(java.util.Calendar.ZONE_OFFSET);   
		int dstOffset = cal.get(java.util.Calendar.DST_OFFSET);    
		cal.add(java.util.Calendar.MILLISECOND, -(zoneOffset + dstOffset)); 
		String nowTime = df.format(new Date(date*1000));
		String utcTime = df.format(cal.getTime());
		bean.complement(timestamp*1000, utcTime, nowTime, config.getGamecode(), config.getPlatformid(), ""+areaId,""+serverId, config.getDomain());
		
		String sign = getSign(timestamp,userId,ip,areaId,serverId);
		generateUrl( timestamp,userId,ip,areaId,serverId,sign,JSONObject.fromObject(bean).toString());
	}

}
