package com.imop.platform.local.request;

import com.imop.platform.local.config.IConfig;
import com.imop.platform.local.response.AddWallowInfoResponse;
import com.imop.platform.local.response.IResponse;
import com.imop.platform.local.util.IdcardUtils;
import com.imop.platform.local.util.ValidateUtil;

public class AddWallowInfoRequest extends AbstractRequest {
	
	private String trueName;
	private String idCard;

	public AddWallowInfoRequest(IConfig config) {
		super(config);
		this.page = "u.addwallowinfo.php" +
				"?timestamp=%s" +
				"&userid=%s" +
				"&truename=%s" +
				"&idcard=%s" +
				"&ip=%s" +
				"&areaid=%s" +
				"&serverid=%s" +
				"&cookie=%s" +
				"&sign=%s";
	}
	
	@Override
	public IResponse send(){
		if(trueName != null && idCard != null){
			if(trueName.length() < 2 || !ValidateUtil.containsFamilyName(String.valueOf(trueName.toCharArray()[0]))){
				return getFailResponse(4);
			}
			
			if(!IdcardUtils.validateCard(idCard)){
				return getFailResponse(5);
			}
			
			return super.send();
		}else{
			return getFailResponse();
		}
	}

	@Override
	public IResponse getResponse(String[] args) {
		return new AddWallowInfoResponse(args);
	}

	@Override
	public void setParams(Object... objects) {
		long timestamp = getTimestamp();
		int areaId = config.getAreaId();
		int serverId = config.getServerId();
	
		long userId = Long.valueOf(objects[0].toString());
		trueName = objects[1].toString();
		idCard = objects[2].toString();
		String cookie = objects[3].toString();

		config.getRecord().recordInfo("trueName:" + trueName + "\tidCard:" + idCard);

		String ip = objects[3].toString();
		
		String sign = getSign(timestamp,userId, trueName,idCard,ip,areaId,serverId);
		generateUrl(timestamp,userId,trueName,idCard,ip,areaId,serverId,cookie,sign);
	}

}
