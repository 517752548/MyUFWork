package com.imop.platform.local.request;

import com.imop.platform.local.config.IConfig;
import com.imop.platform.local.response.IResponse;
import com.imop.platform.local.response.QueryOnlineTimeResponse;

/**
 * 获取用户登录千橡游戏累计时间接口<br>
 * 接口功能：<br>
 * 获取用户登录千橡游戏累计时间，只有是防沉迷用户才需要调用此接口，每5分钟请求一次。
 * @author lu.liu
 *
 */
public class QueryOnlineTimeRequest extends AbstractRequest {
	
	public QueryOnlineTimeRequest(IConfig config){
		super(config);
		this.page = "u.queryonlinetime.php" +
				"?timestamp=%s" +
				"&userid=%s" +
				"&areaid=%s" +
				"&serverid=%s" +
				"&sign=%s" ;
	}

	@Override
	public IResponse getResponse(String[] args) {
		return new QueryOnlineTimeResponse(args);
	}

	@Override
	public void setParams(Object... objects) {
		long timestamp = getTimestamp();
		int areaId = config.getAreaId();
		int serverId = config.getServerId();
		
		long userId = Long.valueOf(objects[0].toString());
		
		String sign = getSign(timestamp,userId,areaId,serverId);
		generateUrl(timestamp,userId,areaId,serverId,sign);
	}

}
