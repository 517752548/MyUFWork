package com.imop.platform.local.report;

import com.imop.platform.local.config.IConfig;
import com.imop.platform.local.response.IResponse;
import com.imop.platform.local.response.ReportResponse;

/**
 * 游戏同时在线人数接口<br>
 * 接口功能：<br>
 * 提供记录同时在线人数功能。游戏需要每5分钟请求一次该接口。
 * @author lu.liu
 *
 */
public class OnlineReport extends AbstractReport {
	
	public OnlineReport(IConfig config){
		super(config);
		this.page = "u.online.php" +
				"?timestamp=%s" +
				"&areaid=%s" +
				"&serverid=%s" +
				"&onlinenum=%s" +
				"&sign=%s";
	}

	@Override
	public IResponse getResponse(String[] args) {
		return new ReportResponse(args);
	}

	@Override
	public void setParams(Object... objects) {
		long timestamp = getTimestamp();
		int areaId = config.getAreaId();
		int serverId = config.getServerId();

		int onlineNum = Integer.valueOf(objects[0].toString());
		
		if(objects.length == 2){
			serverId = Integer.valueOf(objects[1].toString());
		}
		
		String sign = getSign(timestamp,areaId,serverId,onlineNum);
		
		generateUrl(timestamp,areaId,serverId,onlineNum,sign);
	}

}
