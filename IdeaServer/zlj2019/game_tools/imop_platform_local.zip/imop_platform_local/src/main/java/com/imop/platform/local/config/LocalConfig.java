package com.imop.platform.local.config;

import java.io.File;
import java.io.InputStream;
import java.util.Properties;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.apache.commons.lang.StringUtils;
import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

import com.imop.platform.local.exception.LocalConfigException;
import com.imop.platform.local.exception.LocalException;
import com.imop.platform.local.record.IRecord;
import com.imop.platform.local.record.Slf4jRecord;

/**
 * 接口配置类
 * @author lu.liu
 *
 */
public class LocalConfig implements IConfig{
	
	/**
	 * 连接超时时间，默认11s，大于LOCAL和人人超时时间1s
	 */
	private int timeout = 11;
	
	/**
	 * 线程池大小，默认为2
	 */
	private int threadNum = 2;
	
	/**
	 * 各游戏唯一Key
	 */
	private String gameKey;
	
	/**
	 * 游戏请求类接口域名，如：http://local.ts.mop.com
	 */
	private String requestDomain = null;
	
	/**
	 * 游戏汇报类接口域名，现阶段和请求类为同一域名
	 */
	private String reportDomain = null;

	/**
	 * 配置文件默认名
	 */
	private String configFile = "config/local_cfg.xml";
	
	/**
	 * 日志记录器
	 */
	private IRecord record;
	
	/**
	 * 线程管理器
	 */
	private ExecutorService reportService;
	
	/**
	 * 游戏大区ID
	 */
	private int areaId;
	
	/**
	 * 游戏服务器ID
	 */
	private int serverId;
	
	/**
	 * 游戏服务器域名
	 */
	private String domain;
	
	/**
	 * 游戏服务器域名
	 */
	private String gamecode;
	
	/**
	 * 游戏服务器域名
	 */
	private String platformid;
	
	private static String localJarVersion;
	
	/**
	 * 构造函数（只初始化日志记录器和线程池）
	 * @throws LocalException
	 */
	public LocalConfig() throws LocalException {
		initLogger();
		initThreadPool();
		
		initLocalJarVersion();
		
	}
	
	public void initLocalJarVersion() {
		localJarVersion = "0.0.0";
		
		try {
			record.recordInfo("start getting local jar version");
			Properties prop = new Properties();
			InputStream input = Thread.currentThread().getContextClassLoader().getResourceAsStream("rrg_local_init.properties");
			prop.load(input);
			localJarVersion = prop.getProperty("localJarVersion");
		} catch (Exception e) {
			record.recordError("Get Local Jar Version failed:"+e.getMessage(), e);
			//System.out.println("Get Local Jar Version failed!");
			e.printStackTrace();
		}
		
		record.recordInfo("Local Jar Version:"+localJarVersion);
	}

	/**
	 * @deprecated
	 * 构造函数
	 * @param configFile	配置文件名
	 * @param areaId		大区ID
	 * @param serverId		服务器ID
	 * @param domain		游戏域名
	 * @throws LocalException
	 */
	public LocalConfig(String configFile, int areaId, int serverId, String domain) throws LocalException{
		if(null != configFile){
			this.configFile = configFile;
		}
		
		this.areaId = areaId;
		
		this.serverId = serverId;
		
		this.domain = domain;
		
		initlize();
		
		initLocalJarVersion();
		
		checkConfig();
	}
	
	/**
	 * 构造函数
	 * @param configFile	配置文件名
	 * @param areaId		大区ID
	 * @param serverId		服务器ID
	 * @param domain		游戏域名
	 * @throws LocalException
	 */
	public LocalConfig(String configFile, int areaId, int serverId, String domain ,String gamecode , String platformid) throws LocalException{
		
		if(null != configFile){
			this.configFile = configFile;
		}
		
		File f = new File(configFile);
		if(!f.exists()) {
			throw new RuntimeException("Cannot find the config file! config file is:["+configFile+"]");
		}
		
		this.areaId = areaId;
		
		this.serverId = serverId;
		
		this.domain = domain;
		
		this.gamecode = gamecode;
		
		this.platformid = platformid;
		
		initlize();
		
		initLocalJarVersion();
		
		checkConfig();
	}

	/**
	 * 初始化相关配置
	 * @throws LocalException 
	 * @throws LocalException 
	 */
	public void initlize() throws LocalException {
		
		initLogger();
		
		initConfigFile();
		
		initThreadPool();
		
	}
	
	
	/**
	 * 初始化日志管理器
	 * @throws LocalException 
	 */
	private void initLogger() throws LocalException {
		
		record = new Slf4jRecord();
		
		record.recordInfo("#IMOP.LOCAL.LOGGER.INITLIZE...");
		
	}
	
	/**
	 * 初始化XML配置文件
	 */
	private void initConfigFile(){
		try {
			Document document = new SAXReader().read(configFile);
			
			if(null != document){
				Element root = document.getRootElement();
				
				if(null == root){
					record.recordError("#IMOP.LOCAL.CONFIGFILE.ERROR:ROOT IS NULL", null);
					return;
				}

				initGameInfoElement(root);
			}
			record.recordInfo("#IMOP.LOCAL.INITLIZE...FILE:" + configFile);
		} catch (Exception e) {
			record.recordError("#IMOP.LOCAL.INITLIZE.ERROR...FILE:" + configFile,e);
		}

	}
	
	/**
	 * 初始化配置文件中的game_info节点内容
	 * @param element	config节点
	 */
	private void initGameInfoElement(Element element){
		try {
			for(Object obj : element.elements()){
				Element e = (Element)obj;
				
				if(null == e){
					continue;
				}
				
				String name = e.getName();
				String value = e.getStringValue();
				
				if(null == value){
					continue;
				}
				
				if(LOCAL_CONFIG_TIMEOUT.equals(name)){
					timeout = Integer.valueOf(value);
				}else if(LOCAL_CONFIG_THREADNUM.equals(name)){
					threadNum = Integer.valueOf(value);
				}else if(LOCAL_CONFIG_GAMEKEY.equals(name)){
					gameKey = value;
				}else if(LOCAL_CONFIG_REQUESTDOMAIN.equals(name)){
					requestDomain = validateUrl(value);
				}else if(LOCAL_CONFIG_REPORTDOMAIN.equals(name)){
					reportDomain = validateUrl(value);
				}
			}
		} catch (Exception e) {
			record.recordError("#IMOP.LOCAL.FILEELEMENT.INITLIZE.ERROR:",e);			
		}
	}
	
	/**
	 * 初始化线程池
	 */
	private void initThreadPool(){
		if(null == reportService){
			reportService = Executors.newFixedThreadPool(threadNum);
		}
		record.recordInfo("#IMOP.LOCAL.INIT.THREADPOOL.OK:SIZE:" + threadNum);
	}
	
	/**
	 * 检查必须配置是否完整
	 * @throws LocalConfigException
	 */
	public void checkConfig() throws LocalConfigException{
		if(0 == areaId){
			throw new LocalConfigException("areaId cannot be zero");
		}
		
		if(0 == serverId){
			throw new LocalConfigException("serverId cannot be zero");
		}
		
		if(StringUtils.isBlank(gameKey)){
			throw new LocalConfigException("gameKey cannot be null");
		}
		
		if(StringUtils.isBlank(domain)){
			throw new LocalConfigException("domain cannot be null");
		}
		
		if(StringUtils.isBlank(requestDomain)){
			throw new LocalConfigException("requestDomain cannot be null");
		}
		
		if(StringUtils.isBlank(reportDomain)){
			throw new LocalConfigException("reportDomain cannot be null");
		}
		
		if(10 > timeout){
			throw new LocalConfigException("timeout is too short");
		}
		
		if(null == reportService){
			throw new LocalConfigException("reportService is null");
		}
		
		if(StringUtils.isBlank(gamecode)){
			throw new LocalConfigException("gamecode cannot be null");
		}
		
		if(StringUtils.isBlank(platformid)){
			throw new LocalConfigException("platformid cannot be null");
		}
		
		record.recordInfo("#IMOP.LOCAL.START:AREAID:" + areaId + " SERVERID:" + serverId + " DOMAIN:" + domain);
	}
	
	/* (non-Javadoc)
	 * @see com.imop.platform.local.config.IConfig#getTimeout()
	 */
	@Override
	public int getTimeout() {
		return timeout;
	}

	/* (non-Javadoc)
	 * @see com.imop.platform.local.config.IConfig#getGameKey()
	 */
	@Override
	public String getGameKey() {
		return gameKey;
	}

	/* (non-Javadoc)
	 * @see com.imop.platform.local.config.IConfig#getRequestDomain()
	 */
	@Override
	public String getRequestDomain() {
		return requestDomain;
	}

	/* (non-Javadoc)
	 * @see com.imop.platform.local.config.IConfig#getReportDomain()
	 */
	@Override
	public String getReportDomain() {
		return reportDomain;
	}

	/* (non-Javadoc)
	 * @see com.imop.platform.local.config.IConfig#getRecord()
	 */
	@Override
	public IRecord getRecord() {
		return record;
	}

	/* (non-Javadoc)
	 * @see com.imop.platform.local.config.IConfig#getReportService()
	 */
	@Override
	public ExecutorService getReportService() {
		return reportService;
	}
	
	/* (non-Javadoc)
	 * @see com.imop.platform.local.config.IConfig#getAreaId()
	 */
	@Override
	public int getAreaId() {
		return areaId;
	}
	
	/* (non-Javadoc)
	 * @see com.imop.platform.local.config.IConfig#getServerId()
	 */
	@Override
	public int getServerId() {
		return serverId;
	}
	/* (non-Javadoc)
	 * @see com.imop.platform.local.config.IConfig#getDomain()
	 */
	@Override
	public String getDomain() {
		return domain;
	}

	@Override
	public void setReportService(ExecutorService reportService) {
		this.reportService = reportService;
	}
	
	/**
	 * 检查域名配置是否以"/"结尾，如果不是则追加
	 * @param url	待处理的URL
	 * @return	处理后的URL
	 */
	private String validateUrl(String url){
		if(url.lastIndexOf("/") == (url.length()-1)){
			return url;
		}else{
			return url + "/";
		}
	}

	/**
	 * 设置线程池启动的线程数
	 * @param threadNum	线程数
	 */
	public void setThreadNum(int threadNum) {
		this.threadNum = threadNum;
	}

	/**
	 * 设置超时时间（单位：秒）
	 * @param timeout	超时时间
	 */
	public void setTimeout(int timeout) {
		this.timeout = timeout;
	}

	/**
	 * 设置游戏唯一KEY
	 * @param gameKey	游戏KEY
	 */
	public void setGameKey(String gameKey) {
		this.gameKey = gameKey;
	}

	/**
	 * 设置请求接口域名
	 * @param requestDomain	域名
	 */
	public void setRequestDomain(String requestDomain) {
		this.requestDomain = requestDomain;
	}

	/**
	 * 设置汇报接口域名
	 * @param reportDomain	域名
	 */
	public void setReportDomain(String reportDomain) {
		this.reportDomain = reportDomain;
	}

	/**
	 * 设置大区ID
	 * @param areaId	大区ID
	 */
	public void setAreaId(int areaId) {
		this.areaId = areaId;
	}

	/**
	 * 设置服务器ID
	 * @param serverId	服务器ID
	 */
	public void setServerId(int serverId) {
		this.serverId = serverId;
	}

	/**
	 * 设置游戏域名
	 * @param domain	游戏域名
	 */
	public void setDomain(String domain) {
		this.domain = domain;
	}

	/**
	 * 设置游戏code
	 * @param code	游戏code
	 */
	public String getGamecode() {
		return gamecode;
	}

	/**
	 * 获取游戏code
	 * @param code	游戏code
	 */
	public void setGamecode(String gamecode) {
		this.gamecode = gamecode;
	}

	/**
	 * 设置游戏的Platformid
	 * @param  Platformid	游戏的Platformid
	 */
	public String getPlatformid() {
		return platformid;
	}

	/**
	 * 获取游戏的Platformid
	 * @param Platformid	游戏的Platformid
	 */
	public void setPlatformid(String platformid) {
		this.platformid = platformid;
	}

	public static String getLocalJarVersion() {
		return localJarVersion;
	}

	
}
