package com.imop.platform.local;

import java.io.File;
import java.net.URL;

import com.imop.platform.local.config.IConfig;
import com.imop.platform.local.config.LocalConfig;
import com.imop.platform.local.exception.LocalException;
import com.imop.platform.local.handler.IHandler;
import com.imop.platform.local.handler.LocalHandler;
import com.imop.platform.local.response.GetVersionResponse;
import com.imop.platform.local.util.VersionUtil;

/**
 * 接口处理器工厂
 * @author lu.liu
 *
 */
public class HandlerFactory {

	private static IHandler handler;
	
	/**
	 * 根据配置文件初始化处理器
	 * @param filePath		配置文件路径
	 * @param areaId		游戏大区ID
	 * @param serverId		游戏服务器ID
	 * @param domain		游戏域名
	 * @return				所创建的Handler
	 * @throws LocalException 
	 */
	@Deprecated
	public static IHandler createHandler(String filePath, int areaId, int serverId, String domain) throws LocalException{
		if(null == handler){
			LocalConfig config = new LocalConfig(filePath, areaId, serverId, domain);
			handler = new LocalHandler(config);

			requestLocalVersion();
		}
		return handler;
	}
	
	/**
	 * 根据配置文件初始化处理器
	 * @param filePath		配置文件路径
	 * @param areaId		游戏大区ID
	 * @param serverId		游戏服务器ID
	 * @param domain		游戏域名
	 * @return				所创建的Handler
	 * @throws LocalException 
	 */
	@Deprecated
	public static IHandler createHandler(String filePath, int areaId, int serverId, String domain , String gamecode, String platformid) throws LocalException{
		if(null == handler){
			LocalConfig config = new LocalConfig(filePath, areaId, serverId, domain , gamecode , platformid);
			handler = new LocalHandler(config);

			requestLocalVersion();
		}
		return handler;
	}
	
	
	/**
	 * 根据配置对象初始化处理器
	 * @param config	游戏内构造的配置对象
	 * @return
	 * @throws LocalException
	 */
	public static IHandler createHandler(LocalConfig config) throws LocalException{
		if(null == handler){
			config.checkConfig();
			handler = new LocalHandler(config);
			requestLocalVersion();
		}
		return handler;
	}
	
	/**
	 * 创建一个默认的处理器
	 * @return
	 * @throws LocalException 
	 */
	@Deprecated
	public static IHandler createDefaultHandler() throws LocalException{
		if(null == handler){
			String fileName = null;
			
			URL url = Thread.currentThread().getContextClassLoader().getResource(IConfig.LOCAL_CFG_FILE);
			
			if(null != url){
				fileName = url.getFile();
			} else {
				fileName = System.getProperty("user.dir") + File.separator + IConfig.LOCAL_CFG_FILE;
			}
			
			handler = createHandler(fileName,1,110,"");
		}
		return handler;
	}
	
	/**
	 * 请求LOCAL版本号信息
	 */
	private static void requestLocalVersion(){
		GetVersionResponse response = handler.getVersion();
		String jarVersion = VersionUtil.getServerVersion();
		
		if(response.isSuccess()){
			handler.getConfig().getRecord().recordInfo("#IMOP.LOCAL.REQUEST.LOCAL.VERSION:" + response.getVersion() + "\tJAR.VERSION:" + jarVersion);
		}else{
			handler.getConfig().getRecord().recordError("#IMOP.LOCAL.REQUEST.LOCAL.VERSION.ERROR:" + response.getErrorCode(),null);
		}
	}
	
	
}
