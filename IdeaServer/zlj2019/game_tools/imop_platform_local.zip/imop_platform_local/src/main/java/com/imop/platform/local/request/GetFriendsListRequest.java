package com.imop.platform.local.request;

import java.util.UUID;

import com.imop.platform.local.config.IConfig;
import com.imop.platform.local.response.GetFriendsListResponse;
import com.imop.platform.local.response.IResponse;
import com.imop.platform.local.util.HttpUtil;

public class GetFriendsListRequest extends AbstractRequest{
	
	private String ticket;

	public GetFriendsListRequest(IConfig config) {
		super(config);
		this.page = "u.getfriendslist.php" +
				"?timestamp=%s" +
				"&ticket=%s" +
				"&areaid=%s" +
				"&serverid=%s" +
				"&sign=%s" ;
	}
	
	@Override
	public IResponse send() {
		try {
			return request();
		} catch (Exception e) {
			config.getRecord().recordError("#LOCAL.PLATFORM.REQUEST.ERROR:" + url, e);
			return getFailResponse();
		}
	}
	
	private IResponse request(){
		IResponse response = null;
		long time = 0;
		try {			
			String uuid = UUID.randomUUID().toString();
			
			config.getRecord().recordInfo(uuid + "\t" + url);
			
			beginTime = System.currentTimeMillis();
			
			String result = HttpUtil.getUrl(url, config.getTimeout(),false);
			
			endTime = System.currentTimeMillis();
			
			time = endTime - beginTime;
			
			config.getRecord().recordInfo(uuid + "\t" + result + "\tTime:" + time + "ms");
			
			String[] params = getParamters(result.trim());
			
			if(null != params){
				response = getResponse(params);
			}else{
				response = getFailResponse();
			}
			
			if(response.isSuccess()){
				response.onSuccess(params);
			}
			
			if(null != response){
				response.setUseTime(time);
			}
			
		} catch (Exception e) {
			config.getRecord().recordError("#PLATFORM.LOCAL.REQUEST.ERROR:", e);
			response = getFailResponse();
			
			if(null != response){
				response.setUseTime(time);
			}
		}
		
		return response;
	}
	
	@Override
	protected String[] getParamters(String result) {
		String[] res = new String[2];
		if(null == result){
			return null;
		} else {
			res[0] = result.substring(0,result.indexOf(":"));
			res[1] = result.substring(result.indexOf(":")+1);
			return res;
		}
	}

	@Override
	public IResponse getResponse(String[] args) {
		return new GetFriendsListResponse(args);
	}

	@Override
	public void setParams(Object... objects) {
		long timestamp = getTimestamp();
		ticket = objects[0].toString();
		int areaId = config.getAreaId();
		int serverId = config.getServerId();
		config.getRecord().recordInfo("user ticket is " + ticket);
		
		String sign = getSign(ticket, timestamp);
		generateUrl(timestamp, ticket, areaId,serverId, sign);
	}

}
