package com.imop.platform.local.response;

public class CaptchaSendResponse extends AbstractResponse {

	public CaptchaSendResponse(String[] args) {
		super(args, 2);
	}

	@Override
	public void onSuccess(String[] args) {

	}

}
