package com.imop.platform.local.response;

public class GetFCMTimeResponse extends AbstractResponse {

	/**
	 * 防沉迷时间段字符串格式：000000-000000|000000-000000|....
	 */
	private String FCMtime="";
	
	public GetFCMTimeResponse(String[] args) {
		super(args, 2);
	}

	@Override
	public void onSuccess(String[] args) {
		FCMtime = args[1];
	}
	/**
	 * 获取防沉迷时间段字符串，格式：000000-000000|000000-000000|....
	 */
	public String getFCMtime() {
		return FCMtime;
	}

}
