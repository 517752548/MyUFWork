package com.imop.platform.local.exception;

public class LocalException extends Exception {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public LocalException(String msg){
		super(msg);
	}
	
	public LocalException(Exception e){
		super(e);
	}
	
	public LocalException(String msg, Exception e){
		super(msg, e);
	}

}
