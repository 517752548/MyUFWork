package com.imop.platform.local.request;

import com.imop.platform.local.config.IConfig;
import com.imop.platform.local.response.GetVersionResponse;
import com.imop.platform.local.response.IResponse;

/**
 * 获取local接口版本号<br>
 * 接口功能：<br>
 * 获取local接口版本号以及最后更新时间。
 * @author lu.liu
 *
 */
public class GetVersionRequest extends AbstractRequest {

	public GetVersionRequest(IConfig config) {
		super(config);
		this.page = "u.getversion.php?domain=%s";
	}

	@Override
	public IResponse getResponse(String[] args) {
		return new GetVersionResponse(args);
	}

	@Override
	public void setParams(Object... objects) {
		generateUrl(config.getDomain());		
	}

}
