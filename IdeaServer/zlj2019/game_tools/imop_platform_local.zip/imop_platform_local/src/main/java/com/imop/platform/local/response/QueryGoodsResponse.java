package com.imop.platform.local.response;

import java.util.ArrayList;
import java.util.List;

import com.imop.platform.local.config.IConfig;


/**
 * 奖品查询扩展的请求结果
 * @author lu.liu
 *
 */
public class QueryGoodsResponse extends AbstractResponse {
	
	/**
	 * 玩家礼包列表，默认为null
	 */
	private List<GoodsInfo> goodsInfoList = null;

	public QueryGoodsResponse(String[] args){
		super(args, 2);
	}

	@Override
	public void onSuccess(String[] args) {
		String temp = args[1];
		goodsInfoList = new ArrayList<GoodsInfo>();
		String[] goodsArr = temp.split(IConfig.SPLIT_VERTICAL);
		for(String infoStr : goodsArr){
			String[] infoArr = infoStr.split(IConfig.SPLIT_STRIPING);
			if(null == infoArr || infoArr.length != 2){
				continue;
			}
			goodsInfoList.add(new GoodsInfo(Integer.valueOf(infoArr[0]),Integer.valueOf(infoArr[1])));
		}
		
	}
	
	/**
	 * 获取玩家礼包列表
	 * @return	玩家礼包列表
	 */
	public List<GoodsInfo> getGoodsInfoList() {
		return goodsInfoList;
	}
	
}
