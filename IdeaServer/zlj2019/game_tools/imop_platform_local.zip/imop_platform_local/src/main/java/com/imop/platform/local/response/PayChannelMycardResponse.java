package com.imop.platform.local.response;

public class PayChannelMycardResponse extends AbstractResponse {

	public PayChannelMycardResponse(String[] args) {
		super(args, 2);
	}

	@Override
	public void onSuccess(String[] args) {

	}

}
