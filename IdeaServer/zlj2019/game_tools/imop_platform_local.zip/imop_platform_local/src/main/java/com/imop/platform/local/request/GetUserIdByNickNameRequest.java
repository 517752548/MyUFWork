package com.imop.platform.local.request;

import com.imop.platform.local.config.IConfig;
import com.imop.platform.local.response.GetUserIdByNickNameResponse;
import com.imop.platform.local.response.IResponse;

/**
 * 通过昵称得到人人用户id<br>
 * 接口功能：<br>
 * 通过昵称得到人人用户id。
 * @author lu.liu
 *
 */
public class GetUserIdByNickNameRequest extends AbstractRequest {

	public GetUserIdByNickNameRequest(IConfig config){
		super(config);
		this.page = "u.getuseridbynickname.php?nickname=%s&domain=%s&sign=%s&currenttime=%s";
	}
	
	@Override
	public IResponse getResponse(String[] args) {
		return new GetUserIdByNickNameResponse(args);
	}

	@Override
	public void setParams(Object... objects) {
		String domain = config.getDomain();
		
		String nickName = objects[0].toString();
		
		String sign = getSign(nickName);
		String datetime = getDateTime();
		generateUrl(nickName,domain,sign, datetime);		
	}

}
