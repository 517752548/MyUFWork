package com.imop.platform.local.response;

import java.util.ArrayList;
import java.util.List;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;


import com.imop.platform.local.ro.FriendsInfo;

public class GetFriendsListResponse extends AbstractResponse {

	private String friendsListJson;
	private List<FriendsInfo> friendList;
	
	public GetFriendsListResponse(String[] args) {
		super(args, 2);
	}

	@Override
	public void onSuccess(String[] args) {
		friendsListJson = args[1];
		processJson();
	}

	public String getFriendsListJson() {
		return friendsListJson;
	}
	
	public List<FriendsInfo> getFriendList(){
		return friendList;
	}
	
	private void processJson(){
		friendList = new ArrayList<FriendsInfo>();
		JSONObject json = JSONObject.fromObject(friendsListJson);
		JSONArray jarr = json.getJSONArray("result");
		for (Object object : jarr) {
			JSONObject jo = (JSONObject) object;
			FriendsInfo fInfo = (FriendsInfo) JSONObject.toBean(jo, FriendsInfo.class);
			friendList.add(fInfo);
		}
	}
	
//	public static void main(String[] args) {
//		String[] res = new String[2];
//		String json = "ok:{\"result\":[{\"id\":\"12345\",\"name\":\"shangzhenyu\",\"headurl\":\"http:\\/\\/www.renren.com\",\"tinyurl\":\"http:\\/\\/www.renren.com\"}," +
//				"{\"id\":\"12345\",\"name\":\"shangzhenyu\",\"headurl\":\"http:\\/\\/www.renren.com\",\"tinyurl\":\"http:\\/\\/www.renren.com\"}]}";
//		res[0] = json.substring(0,json.indexOf(":"));
//		res[1] = json.substring(json.indexOf(":")+1);
//		GetFriendsList list = new GetFriendsList(res);
//		list.onSuccess(res);
//		List<FriendsInfo> friendLists = list.getFriendList();
//		for (FriendsInfo friendsInfo : friendLists) {
//			System.out.println(friendsInfo.getName());
//		}
//	}
}
