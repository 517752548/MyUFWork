package com.imop.platform.local.response;

import net.sf.json.JSONObject;

public class TransferReportResponse extends AbstractResponse {
	
	/**
	 * result 如果值为success表示汇报成功，其他表示汇报失败，默认值为空
	 */
	private String result="";

	public TransferReportResponse(String[] args) {
		super(args, 2);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void onSuccess(String[] args) {
		String json_str = args[1].toString();
		JSONObject json_temp = JSONObject.fromObject(json_str);		
		this.result = getJsonValue(json_temp, "result");
	}

	/**
	 * 返回汇报是否成功。esult 如果值为success表示汇报成功，其他表示汇报失败
	 * @return
	 */
	public String getResult() {
		return result;
	}

	
}
