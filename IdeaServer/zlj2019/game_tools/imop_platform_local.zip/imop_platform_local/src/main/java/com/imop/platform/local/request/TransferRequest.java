package com.imop.platform.local.request;

import java.util.UUID;

import com.imop.platform.local.config.IConfig;
import com.imop.platform.local.response.IResponse;
import com.imop.platform.local.response.TransferResponse;

/**
 * 游戏世界兑换游戏币接口<br>
 * 接口功能：<br>
 * 提供用户在游戏内将平台账户内金钱兑换成游戏货币的功能。调用此接口之前需要调用2.4接口查询该玩家是否有充足的余额。
 * @author lu.liu
 *
 */
public class TransferRequest extends AbstractRequest {
	
	public TransferRequest(IConfig config){
		super(config);
		this.page = "u.transfer.php?timestamp=%s" +
				"&userid=%s" +
				"&roleid=%s" +
				"&money=%s" +
				"&ip=%s" +
				"&areaid=%s" +
				"&serverid=%s" +
				"&sign=%s" +
				"&getorderid=%s" +
				"&gettransfer=%s" +
				"&getjson=1";
	}
	
	public void generateUrl(Object...objects){
		super.generateUrl(objects);
		this.url += "&serialid=" + UUID.randomUUID().toString();
	}

	@Override
	public IResponse getResponse(String[] args) {
		return new TransferResponse(args);
	}

	@Override
	public void setParams(Object... objects) {
		long timestamp = getTimestamp();
		int areaId = config.getAreaId();
		int serverId = config.getServerId();
		
		long userId = Long.valueOf(objects[0].toString());
		String roleId = objects[1].toString();
		int money = Integer.valueOf(objects[2].toString());
		String ip = objects[3].toString();
		int getorderid = Integer.valueOf(objects[4].toString());
		int gettransfer = Integer.valueOf(objects[5].toString());
		
		String sign = getSign(timestamp,userId,roleId,money,ip,areaId,serverId);
		generateUrl(timestamp,userId,roleId,money,ip,areaId,serverId,sign,getorderid,gettransfer);
	}

}
