package com.imop.platform.local.request;

import com.imop.platform.local.config.IConfig;
import com.imop.platform.local.response.GetGoodsResponse;
import com.imop.platform.local.response.IResponse;

/**
 * 奖品领取扩展接口<br>
 * 接口功能：<br>
 * 根据礼品编号和奖励唯一ID获取用户礼品。此处奖励唯一ID为2.6接口所返回的ID。
 * @author lu.liu
 *
 */
public class GetGoodsRequest extends AbstractRequest {
	
	public GetGoodsRequest(IConfig config){
		super(config);
		this.page = "u.getgoods.php" +
				"?timestamp=%s" +
				"&userid=%s" +
				"&roleid=%s" +
				"&ip=%s" +
				"&areaid=%s" +
				"&serverid=%s" +
				"&id=%s" +
				"&largessid=%s" +
				"&sign=%s";
	}

	@Override
	public IResponse getResponse(String[] args) {
		return new GetGoodsResponse(args);
	}

	@Override
	public void setParams(Object... objects) {
		long timestamp = getTimestamp();
		int areaId = config.getAreaId();
		int serverId = config.getServerId();
	
		long userId = Long.valueOf(objects[0].toString());
		String roleId = objects[1].toString();
		String ip = objects[2].toString();
		int id = Integer.valueOf(objects[3].toString());
		int largessId = Integer.valueOf(objects[4].toString());
		
		String sign = getSign(timestamp,userId,roleId,ip,areaId,serverId,id,largessId);
		generateUrl(timestamp,userId,roleId,ip,areaId,serverId,id,largessId,sign);
	}

}
