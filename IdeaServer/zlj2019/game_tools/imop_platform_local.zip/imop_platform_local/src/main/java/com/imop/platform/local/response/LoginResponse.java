package com.imop.platform.local.response;

/**
 * 用户登录验证的请求结果
 * @author lu.liu
 *
 */
public class LoginResponse extends AbstractResponse {
	
	/**
	 * 玩家账号ID，默认为-1
	 */
	private long userId = -1;
	
	/**
	 * 帐号名，默认为null
	 */
	private String userName = null;
	
	/**
	 * 用户是否为防沉迷对象，默认为不是
	 */
	private boolean antiIndulge = false;
	
	/**
	 * 玩家资料是否完整，默认为完整
	 */
	private boolean infoIntegrity = false;
	
	/**
	 * 玩家登陆cookie
	 */
	private String cookie ="";
	


	public LoginResponse(String[] args){
		super(args, 6);
	}

	@Override
	public void onSuccess(String[] args) {
		userId = Long.valueOf(args[1]);
		userName = args[2];
		antiIndulge = Integer.valueOf(args[3]) == 1;
		if(5 <= args.length){
			infoIntegrity = Integer.valueOf(args[4]) == 1;
		}
		if(6 <= args.length){
			cookie = args[5];
		}
	}
	
	/**
	 * 获取账号ID
	 * @return	账号ID
	 */
	public long getUserId() {
		return userId;
	}

	/**
	 * 获取帐号名
	 * @return	帐号名
	 */
	public String getUserName() {
		return userName;
	}
	
	/**
	 * 是否为防沉迷
	 * @return	
	 */
	public boolean isAntiIndulge(){
		return antiIndulge;
	}
	
	/**
	 * 是否资料完整
	 * @return
	 */
	public boolean isInfoIntegrity(){
		return infoIntegrity;
	}
	/**
	 * 玩家登陆cookie，默认不返回该参数
	 * @return cookie
	 */
	public String getCookie() {
		return cookie;
	}
	
}
