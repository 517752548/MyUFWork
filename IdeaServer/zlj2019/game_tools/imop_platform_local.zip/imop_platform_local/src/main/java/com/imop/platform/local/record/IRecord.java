package com.imop.platform.local.record;

/**
 * 日志信息记录接口，log4j、slf4j、db可分别实现
 * @author lu.liu
 *
 */
public interface IRecord {

	/**
	 * 记录普通信息
	 * @param info	
	 */
	public void recordInfo(String info);
	
	/**
	 * 记录错误异常信息
	 * @param errorInfo
	 * @param throwable
	 */
	public void recordError(String errorInfo,Throwable throwable);
	
}
