package com.imop.platform.local.type;

/**
 * 服务器状态枚举
 * @author lu.liu
 *
 */
public enum StatusType implements IEnumType<StatusType> {

	RUN("run"),ERROR("error"),STOPPING("stopping"),STOPPED("stopped"),INIT("init"),LIMITED("limited");
	
	private String status;
	
	private StatusType(String status){
		this.status = status;
	}

	@Override
	public String getStatus() {
		return status;
	}

	@Override
	public int getType() {
		return 0;
	}

}
