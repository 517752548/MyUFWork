package com.imop.platform.local.request;

import com.imop.platform.local.config.IConfig;
import com.imop.platform.local.response.ExpendIOSPaymentResponse;
import com.imop.platform.local.response.IResponse;

public class ExpendIOSPaymentRequest extends AbstractRequest {

	public ExpendIOSPaymentRequest(IConfig config) {
		super(config);
		this.page = "u.expendiospayment.php?" +
				"timestamp=%s&" +
				"userid=%s&" +
				"roleid=%s&" +
				"ip=%s&" +
				"udid=%s&" +
				"areaid=%s&" +
				"serverid=%s&" +
				"domain=%s&" +
				"sign=%s";
	}

	@Override
	public IResponse getResponse(String[] args) {
		// TODO Auto-generated method stub
		return new ExpendIOSPaymentResponse(args);
	}

	@Override
	public void setParams(Object... objects) {
		long timestamp = getTimestamp();
		
		long userId = Long.valueOf(objects[0].toString());
		String roleId = objects[1].toString();
		String ip = objects[2].toString();
		String udid = objects[3].toString();
		
		int areaId = config.getAreaId();
		int serverId = config.getServerId();
		String domain = config.getDomain();

		String sign = getSign(timestamp,userId,roleId,ip,udid,areaId,serverId);
		generateUrl(timestamp,userId,roleId,ip,udid,areaId,serverId,domain,sign);
	}

}
