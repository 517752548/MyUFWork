package com.imop.platform.local.response;

import java.util.ArrayList;
import java.util.List;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

public class SurveyResponse extends AbstractResponse {

	public class Survey {
		private String surveyName;
		private String surveyURL;
		public Survey(){}
		public String getSurveyName() {
			return surveyName;
		}
		public void setSurveyName(String surveyName) {
			this.surveyName = surveyName;
		}
		public String getSurveyURL() {
			return surveyURL;
		}
		public void setSurveyURL(String surveyURL) {
			this.surveyURL = surveyURL;
		}
		
	}
	
	protected List<Survey> surveyList;
	
	
	public SurveyResponse(String[] args) {
		super(args, 2);
	}

	@SuppressWarnings("unchecked")
	@Override
	public void onSuccess(String[] args) {
		String json_str = args[1];
		JSONObject o = JSONObject.fromObject(json_str);
		JSONArray surveyArray = o.getJSONArray("survey");
		surveyList = new ArrayList<SurveyResponse.Survey>();
		
		for(Object obj:surveyArray) {
			JSONObject jobj = (JSONObject)obj;
			Survey survey = new Survey();
			survey.setSurveyName(jobj.getString("surveyName"));
			survey.setSurveyURL(jobj.getString("surveyURL"));
			surveyList.add(survey);
		}
	}

	public List<Survey> getSurveyList() {
		return surveyList;
	}

}
