package com.imop.platform.local.response;

import net.sf.json.JSONObject;

public class ChannelUserLoginResponse extends AbstractResponse {

	private String userid;
	private String username;
	private String wallow;
	private String infofull;
	private String cookie;
	
	private String json_str = "";
	
	public ChannelUserLoginResponse(String[] args) {
		super(args, 2);
	}

	@Override
	public void onSuccess(String[] args) {
		json_str = args[1];
		JSONObject jsonResult = JSONObject.fromObject(json_str);
		userid = getJsonValue(jsonResult, "userid");
		username = getJsonValue(jsonResult, "username");
		wallow = getJsonValue(jsonResult, "wallow");
		infofull = getJsonValue(jsonResult, "infofull");
		cookie = getJsonValue(jsonResult, "cookie");
	}

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getWallow() {
		return wallow;
	}

	public void setWallow(String wallow) {
		this.wallow = wallow;
	}

	public String getInfofull() {
		return infofull;
	}

	public void setInfofull(String infofull) {
		this.infofull = infofull;
	}

	public String getCookie() {
		return cookie;
	}

	public void setCookie(String cookie) {
		this.cookie = cookie;
	}

}
