package com.imop.platform.local.response;

import net.sf.json.JSONNull;
import net.sf.json.JSONObject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.imop.platform.local.config.IConfig;

public abstract class AbstractResponse implements IResponse {

	/**
	 * 接口返回是否成功，默认为不成功
	 */
	protected boolean success = false;

	/**
	 * 错误码，默认为异常返回值-1
	 */
	private int errorCode = -1;
	
	/**
	 * 返回参数数量，默认为-1
	 */
	protected int parasNum = -1;
	
	private String errorMsg = "";

	/**
	 * 接口耗时
	 */
	protected long useTime;

	/**
	 * 通过参数数组和个数构造返回对象
	 * @param args		参数数组
	 * @param parasNum	参数个数
	 */
	public AbstractResponse(String[] args,int parasNum) {
		
		if (IConfig.OK.equalsIgnoreCase(args[0])) {
			if(args.length != parasNum){
				//Logger logger = LoggerFactory.getLogger(IConfig.LOCAL_LOGGER_NAME);
				//logger.error("#IMOP.LOCAL.REQUEST.isOK.RESPONSE.isERROR" + args.length);
			}
			success = true;
		} else {
			this.errorCode = Integer.valueOf(args[1]);
			if(args.length>2) {
				this.errorMsg = args[2];
			}
		}
	}
	
	@Override
	public boolean isSuccess() {
		return success;
	}

	@Override
	public int getErrorCode() {
		return errorCode;
	}

	@Override
	public long getUseTime(){
		return useTime;
	}
	
	@Override
	public void setUseTime(long time){
		this.useTime = time;
	}
	
	protected String getJsonValue(JSONObject json , String key){
		if(json.has(key)) {
			Object val = json.get(key);
			if(val==null) return null;
			if(val instanceof JSONNull) {
				return null;
			} else if (val instanceof JSONObject && ((JSONObject)val).isNullObject()) {
				return null;
			}
			return val.toString();
		}
		return null;
	}

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

}
