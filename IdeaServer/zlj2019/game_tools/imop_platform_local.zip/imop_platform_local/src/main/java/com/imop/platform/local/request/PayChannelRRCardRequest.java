package com.imop.platform.local.request;

import com.imop.platform.local.config.IConfig;
import com.imop.platform.local.response.IResponse;
import com.imop.platform.local.response.PayChannelRRCardRespose;

public class PayChannelRRCardRequest extends AbstractRequest {

	public PayChannelRRCardRequest(IConfig config) {
		super(config);
	}

	@Override
	public IResponse getResponse(String[] args) {
		return new PayChannelRRCardRespose(args);
	}

	@Override
	public void setParams(Object... objects) {

	}

}
