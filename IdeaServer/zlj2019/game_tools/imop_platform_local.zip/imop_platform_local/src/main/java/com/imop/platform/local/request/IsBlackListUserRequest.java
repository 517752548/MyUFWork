package com.imop.platform.local.request;

import com.imop.platform.local.config.IConfig;
import com.imop.platform.local.response.IResponse;
import com.imop.platform.local.response.IsBlackListUserResqponse;

public class IsBlackListUserRequest extends AbstractRequest {

	public IsBlackListUserRequest(IConfig config) {
		super(config);
		this.page = "u.isblacklistuser.php?" +
				"timestamp=%s&" +
				"userid=%s&" +
				"ip=%s&" +
				"udid=%s&" +
				"areaid=%s&" +
				"serverid=%s&" +
				"macInfo=%s&" +
				"sign=%s";
	}

	@Override
	public IResponse getResponse(String[] args) {
		// TODO Auto-generated method stub
		return new IsBlackListUserResqponse(args);
	}

	@Override
	public void setParams(Object... objects) {
		long timestamp = getTimestamp();
		
		long userId = Long.valueOf(objects[0].toString());
		String ip = objects[1].toString();
		String udid = objects[2].toString();
		String uuid = objects[3].toString();
		
		int areaId = config.getAreaId();
		int serverId = config.getServerId();

		String sign = getSign(timestamp,userId,ip,udid,areaId,serverId);
		generateUrl(timestamp,userId,ip,udid,areaId,serverId,uuid,sign);
	}

}
