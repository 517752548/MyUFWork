package com.imop.platform.local.request;

import com.imop.platform.local.config.IConfig;
import com.imop.platform.local.response.CreateLinkResponse;
import com.imop.platform.local.response.IResponse;

public class CreateLinkRequest extends AbstractRequest {
	
	private String ticket;

	public CreateLinkRequest(IConfig config) {
		super(config);
		this.page = "u.createlink.php" +
				"?timestamp=%s" +
				"&ticket=%s" +
				"&areaid=%s" +
				"&serverid=%s" +
				"&sign=%s";
	}

	@Override
	public IResponse getResponse(String[] args) {
		return new CreateLinkResponse(args);
	}

	@Override
	public void setParams(Object... objects) {
		long timestamp = getTimestamp();
		ticket = objects[0].toString();
		int areaId = config.getAreaId();
		int serverId = config.getServerId();
		config.getRecord().recordInfo("user ticket is " + ticket);
		
		String sign = getSign(ticket, timestamp);
		generateUrl(timestamp, ticket,areaId,serverId, sign);
	}

}
