package com.imop.platform.local.response;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import net.sf.json.JSONArray;
import net.sf.json.JSONNull;
import net.sf.json.JSONObject;

import org.apache.commons.beanutils.BeanUtils;

public class QueryAllRechargeResponse extends AbstractResponse {


	private String json_str = "";
	private List<QueryAllRechargeResponse.Order> recharge = new ArrayList<QueryAllRechargeResponse.Order>();
	
	public QueryAllRechargeResponse(String[] args) {
		super(args, 2);
	}
	
	
//	public static void main(String [] args) {
//		try {
//			String [] aaa = new String [] {
//					"ok","{recharge:[{id:1,user_id:null},{id:2,user_id:null}]}"
//			};
//			QueryAllRechargeResponse response = new QueryAllRechargeResponse(aaa);
//			response.onSuccess(aaa);
//			System.out.println(response.toString());
//			
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//	}

	@Override
	public void onSuccess(String[] args) {
		json_str = args[1];
		JSONObject jsonResult = JSONObject.fromObject(json_str);
		if(jsonResult.has("recharge")) {
			JSONArray array = (JSONArray)jsonResult.get("recharge");
			
			for(Object obj:array) {
				JSONObject o = (JSONObject)obj;
				Map<String, Object> m = new LinkedHashMap<String, Object>();
				Set<String> keySet = o.keySet();
				for(String key:keySet) {
					Object v = o.get(key);
					
					if(v==null) {
						m.put(key, null);
					} else {
						if(v instanceof JSONNull) {
							m.put(key, null);
						} else if(v instanceof JSONObject && ((JSONObject)v).isNullObject()) {
							m.put(key, null);
						} else {
							m.put(key, v);
						}
					}
				}
				Order order = new Order();
				try {
					BeanUtils.populate(order, m);
				} catch (Exception e) {
					throw new RuntimeException(e);
				} 
				recharge.add(order);
			}
			
		}
	}
	
	public class Order {
		protected String id;
		protected String user_id;
		protected String user_name;
		protected String order_id;
		protected String third_pay_id;
		protected String amount;
		protected String currency;
		protected String item_id;
		protected String game_points;
		protected String type;
		protected String device_type;
		protected String device_version;
		protected String udid;
		protected String device_id;
		protected String areaid;
		protected String serverid;
		protected String game_code;
		protected String game_domain;
		protected String game_server_domain;
		protected String char_id;
		protected String add_time;
		protected String expend_time;
		protected String delay_time;
		protected String terminal;
		protected String remark;
		
		public Order(){
			
		}
		
		public String getId() {
			return id;
		}
		public void setId(String id) {
			this.id = id;
		}
		public String getUser_id() {
			return user_id;
		}
		public void setUser_id(String user_id) {
			this.user_id = user_id;
		}
		public String getUser_name() {
			return user_name;
		}
		public void setUser_name(String user_name) {
			this.user_name = user_name;
		}
		public String getOrder_id() {
			return order_id;
		}
		public void setOrder_id(String order_id) {
			this.order_id = order_id;
		}
		public String getThird_pay_id() {
			return third_pay_id;
		}
		public void setThird_pay_id(String third_pay_id) {
			this.third_pay_id = third_pay_id;
		}
		public String getAmount() {
			return amount;
		}
		public void setAmount(String amount) {
			this.amount = amount;
		}
		public String getCurrency() {
			return currency;
		}
		public void setCurrency(String currency) {
			this.currency = currency;
		}
		public String getItem_id() {
			return item_id;
		}
		public void setItem_id(String item_id) {
			this.item_id = item_id;
		}
		public String getGame_points() {
			return game_points;
		}
		public void setGame_points(String game_points) {
			this.game_points = game_points;
		}
		public String getType() {
			return type;
		}
		public void setType(String type) {
			this.type = type;
		}
		public String getDevice_type() {
			return device_type;
		}
		public void setDevice_type(String device_type) {
			this.device_type = device_type;
		}
		public String getDevice_version() {
			return device_version;
		}
		public void setDevice_version(String device_version) {
			this.device_version = device_version;
		}
		public String getUdid() {
			return udid;
		}
		public void setUdid(String udid) {
			this.udid = udid;
		}
		public String getDevice_id() {
			return device_id;
		}
		public void setDevice_id(String device_id) {
			this.device_id = device_id;
		}
		public String getAreaid() {
			return areaid;
		}
		public void setAreaid(String areaid) {
			this.areaid = areaid;
		}
		public String getServerid() {
			return serverid;
		}
		public void setServerid(String serverid) {
			this.serverid = serverid;
		}
		public String getGame_code() {
			return game_code;
		}
		public void setGame_code(String game_code) {
			this.game_code = game_code;
		}
		public String getGame_domain() {
			return game_domain;
		}
		public void setGame_domain(String game_domain) {
			this.game_domain = game_domain;
		}
		public String getGame_server_domain() {
			return game_server_domain;
		}
		public void setGame_server_domain(String game_server_domain) {
			this.game_server_domain = game_server_domain;
		}
		public String getChar_id() {
			return char_id;
		}
		public void setChar_id(String char_id) {
			this.char_id = char_id;
		}
		public String getAdd_time() {
			return add_time;
		}
		public void setAdd_time(String add_time) {
			this.add_time = add_time;
		}
		public String getExpend_time() {
			return expend_time;
		}
		public void setExpend_time(String expend_time) {
			this.expend_time = expend_time;
		}
		public String getDelay_time() {
			return delay_time;
		}
		public void setDelay_time(String delay_time) {
			this.delay_time = delay_time;
		}
		public String getTerminal() {
			return terminal;
		}
		public void setTerminal(String terminal) {
			this.terminal = terminal;
		}
		public String getRemark() {
			return remark;
		}
		public void setRemark(String remark) {
			this.remark = remark;
		}
		
	}

	public List<QueryAllRechargeResponse.Order> getRecharge() {
		return recharge;
	}

}
