package com.imop.platform.local.response;

import net.sf.json.JSONObject;

public class QuickLoginResponse extends AbstractResponse {

	/**
	 * userid 玩家账号ID 
	 */
	private Long userid;
	
	/**
	 * username 玩家用户名 
	 */
	private String username;
	
	/**
	 * wallow 玩家是否防沉迷(true是防沉迷，false不是防沉迷) 
	 */
	private boolean wallow;
	
	/**
	 * infofull 玩家资料是否完整(true资料完整，false资料不完整) 
	 */
	private boolean infofull;
	
	/**
	 * cookie 玩家登录cookie 
	 */
	private String cookie;
	
	
	public QuickLoginResponse(String[] args) {
		super(args, 2);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void onSuccess(String[] args) {
		String json_str = args[1].toString();
		JSONObject json_temp = JSONObject.fromObject(json_str);		
		this.userid = Long.parseLong(getJsonValue(json_temp, "userid"));
		this.username = getJsonValue(json_temp, "username");
		if("Y".equals(getJsonValue(json_temp, "wallow")))this.wallow = true;
		if("Y".equals(getJsonValue(json_temp, "infofull")))this.infofull = true;
		this.cookie = getJsonValue(json_temp, "cookie");
	}

	/**
	 * 获取玩家账号ID 
	 */
	public Long getUserid() {
		return userid;
	}
	
	
	/**
	 * 获取玩家用户名 
	 */
	public String getUsername() {
		return username;
	}
	
	/**
	 * 获取玩家是否防沉迷(true是防沉迷，false不是防沉迷) 
	 */
	public boolean isWallow() {
		return wallow;
	}

	/**
	 * 获取玩家资料是否完整(true资料完整，false资料不完整) 
	 */	
	public boolean isInfofull() {
		return infofull;
	}

	/**
	 * 获取玩家登录cookie 
	 */
	public String getCookie() {
		return cookie;
	}

	
	
}
