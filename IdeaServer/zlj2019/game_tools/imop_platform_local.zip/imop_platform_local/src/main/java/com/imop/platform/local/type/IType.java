package com.imop.platform.local.type;

public interface IType {

	public int getType();
	
	public String getStatus();
	
}
