package com.imop.platform.local.response;

/**
 * 玩家礼包信息
 * @author lu.liu
 *
 */
public class GoodsInfo {

	/**
	 * 礼包平台数据库ID
	 */
	private int id;
	
	/**
	 * 礼包游戏数据库ID
	 */
	private int goodsId;
	
	public GoodsInfo(int id,int goodsId){
		this.id = id;
		this.goodsId = goodsId;
	}

	/**
	 * 礼包平台数据库ID
	 * @return
	 */
	public int getId() {
		return id;
	}

	/**
	 * 礼包游戏数据库ID
	 * @return
	 */
	public int getGoodsId() {
		return goodsId;
	}
		
}