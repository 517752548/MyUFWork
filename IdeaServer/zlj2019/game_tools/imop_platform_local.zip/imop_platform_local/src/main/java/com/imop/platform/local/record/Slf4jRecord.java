package com.imop.platform.local.record;

import org.apache.log4j.LogManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.imop.platform.local.config.IConfig;
import com.imop.platform.local.exception.LocalException;
import com.imop.platform.local.exception.LocalLog4jException;

/**
 * slf4j实现日志记录接口
 * @author lu.liu
 *
 */
public class Slf4jRecord implements IRecord {
	
	/**
	 * 平台日志记录器
	 */
	private Logger localLogger;
	
	/**
	 * 构造方法
	 * @throws LocalException 
	 */
	public Slf4jRecord() throws LocalException{
		localLogger = LoggerFactory.getLogger(IConfig.LOCAL_LOGGER_NAME);

		
		if(null == LogManager.exists(IConfig.LOCAL_LOGGER_NAME)){
			throw new LocalLog4jException();
		}
		
	}

	@Override
	public void recordInfo(String info) {
		localLogger.info(info);
	}

	@Override
	public void recordError(String errorInfo, Throwable throwable) {
		localLogger.error(errorInfo,throwable);
	}

}
