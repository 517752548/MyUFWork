package com.imop.platform.local.request;

import java.math.BigDecimal;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import org.apache.commons.codec.digest.DigestUtils;

import com.imop.platform.local.config.IConfig;
import com.imop.platform.local.response.IResponse;
import com.imop.platform.local.response.TransferReportResponse;

public class TransferReportRequest extends AbstractRequest {

	public enum enum_chargetype{ 
		expend,		//直冲 
		transfer,	//平台币兑换
		iosexpend,	//ios直冲 
		largess;	//额外奖励 
		}
	public enum enum_currency{
		 RRDOU,//平台币
		 CNY, //人民币
		 USD, //美元
		 KRW, //韩元
		 THB, //泰元
		 TWD, //台币
		 FREEPOINT; //奖励的一级游戏币
	}
	public TransferReportRequest(IConfig config) {
		super(config);
		this.page = "u.transferreport.php" +
				"?timestamp=%s" +
				"&userid=%s" +
				"&roleid=%s" +
				"&ip=%s" +
				"&areaid=%s" +
				"&serverid=%s" +
				"&domain=%s" +
				"&orderid=%s" +
				"&gamebean=%s" +
				"&chargetype=%s" +
				"&currency=%s" +
				"&mount=%s" +
				"&addtioninfo=%s" +
				"&itemid=%s" +
				"&itemname=%s" +
				"&currenttime=%s";
	}

	@Override
	public IResponse getResponse(String[] args) {
		return new TransferReportResponse(args);
	}

	@Override
	public void setParams(Object... objects) {
		long timestamp = getTimestamp();
		Long userid = Long.valueOf(objects[0].toString());
		String roleid = objects[1].toString();
		String ip =  objects[2].toString();
		int areaid = config.getAreaId();
		int serverid = config.getServerId();
		String domain = config.getDomain();
		String orderid = objects[3].toString();
		BigDecimal gamebean = (BigDecimal) objects[4];
		String chargetype = objects[5].toString();
		String currency = objects[6].toString();
		BigDecimal mount = (BigDecimal) objects[7];
		String addtioninfo = objects[8].toString();
		String itemid = objects[9].toString();
		String itemname = objects[10].toString();
		Long currenttime = Long.valueOf(objects[11].toString());
		
		getUrl(timestamp,userid,roleid,ip,areaid,serverid,domain,orderid,gamebean,chargetype,currency,mount,addtioninfo,itemid,itemname,currenttime);

	}
	
	

}
