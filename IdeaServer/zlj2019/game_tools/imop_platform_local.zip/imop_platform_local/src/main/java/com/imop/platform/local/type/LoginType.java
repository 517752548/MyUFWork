package com.imop.platform.local.type;

public enum LoginType implements IEnumType<LoginType>{
	
	UserPasswordLogin(1),UserCookieLogin(2),UserTokenLogin(3),ReturnCookie(4);
	
	private final int typeId;

	private LoginType(int typeId){
		this.typeId = typeId;
	}

	@Override
	public int getType() {
		return typeId;
	}

	@Override
	public String getStatus() {
		return null;
	}
}
