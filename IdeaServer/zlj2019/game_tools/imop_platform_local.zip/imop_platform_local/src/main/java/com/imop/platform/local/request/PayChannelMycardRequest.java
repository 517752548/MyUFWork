package com.imop.platform.local.request;

import com.imop.platform.local.config.IConfig;
import com.imop.platform.local.response.IResponse;
import com.imop.platform.local.response.PayChannelMycardResponse;

public class PayChannelMycardRequest extends AbstractRequest {

	public PayChannelMycardRequest(IConfig config) {
		super(config);
	}

	@Override
	public IResponse getResponse(String[] args) {
		return new PayChannelMycardResponse(args);
	}

	@Override
	public void setParams(Object... objects) {

	}

}
