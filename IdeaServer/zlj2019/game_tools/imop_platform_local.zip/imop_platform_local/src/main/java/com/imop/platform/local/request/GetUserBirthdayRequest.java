package com.imop.platform.local.request;

import com.imop.platform.local.config.IConfig;
import com.imop.platform.local.response.GetUserBirthdayResponse;
import com.imop.platform.local.response.IResponse;
/**
 * 获取用户防沉迷注册时填写的生日信息<br>
 * 接口功能：<br>
 * 通过用户id获取该用户注册防沉迷时填写的生日信息<br>
 * 此接口为可选接口
 * @author jiang.li
 *
 */
public class GetUserBirthdayRequest extends AbstractRequest {

	public GetUserBirthdayRequest(IConfig config) {
		super(config);
		this.page="u.getuserbirthday.php?" +
				"timestamp=%s&" +
				"userid=%s&" +
				"ip=%s&" +
				"areaid=%s&" +
				"serverid=%s&" +
				"sign=%s&";
	}

	@Override
	public IResponse getResponse(String[] args) {
		return new GetUserBirthdayResponse(args);
	}

	@Override
	public void setParams(Object... objects) {
		
		long timestamp = getTimestamp();
		int areaid = config.getAreaId();
		int serverid = config.getServerId();
		
		long userid = Long.valueOf(objects[0].toString());
		String ip = objects[1].toString();
		
		String sign = getSign(timestamp,userid,ip,areaid,serverid);
		
		generateUrl(timestamp,userid,ip,areaid,serverid,sign);
	}

}
