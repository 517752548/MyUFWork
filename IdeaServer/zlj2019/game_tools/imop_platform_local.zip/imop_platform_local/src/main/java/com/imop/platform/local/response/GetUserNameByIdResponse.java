package com.imop.platform.local.response;

/**
 * 通过用户id获取用户名称的请求结果
 * @author lu.liu
 *
 */
public class GetUserNameByIdResponse extends AbstractResponse {

	/**
	 * 帐号名，默认为null
	 */
	private String userName = null;
	
	public GetUserNameByIdResponse(String[] args){
		super(args,2);
	}

	@Override
	public void onSuccess(String[] args) {
		userName = args[1];
	}
	
	/**
	 * 获取帐号名
	 * @return	帐号名
	 */
	public String getUserName(){
		return userName;
	}
}
