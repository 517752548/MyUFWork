package com.imop.platform.local.request;

import com.imop.platform.local.config.IConfig;
import com.imop.platform.local.response.ChannelUserLoginResponse;
import com.imop.platform.local.response.IResponse;

public class ChannelUserLoginRequest extends AbstractRequest {

	public ChannelUserLoginRequest(IConfig config) {
		super(config);
	}

	@Override
	public IResponse getResponse(String[] args) {
		return new ChannelUserLoginResponse(args);
	}

	@Override
	public void setParams(Object... objects) {

	}

}
