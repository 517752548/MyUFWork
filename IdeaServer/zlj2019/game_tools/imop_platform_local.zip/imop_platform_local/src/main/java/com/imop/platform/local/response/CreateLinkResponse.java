package com.imop.platform.local.response;

public class CreateLinkResponse extends AbstractResponse {
	
	private String inviteLink;

	public CreateLinkResponse(String[] args) {
		super(args, 2);
	}

	@Override
	public void onSuccess(String[] args) {
		this.inviteLink = args[1];
		if(args.length>2) {
			this.inviteLink = args[1];
			for(int i=2;i<args.length;i++) {
				this.inviteLink+=":"+args[i];
			}
		}
	}
	
	public String getInviteLink(){
		return inviteLink;
	}

}
