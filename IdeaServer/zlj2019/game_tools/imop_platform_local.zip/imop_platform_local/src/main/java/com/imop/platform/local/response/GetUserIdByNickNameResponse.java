package com.imop.platform.local.response;

/**
 * 通过昵称得到人人用户请求结果
 * @author lu.liu
 *
 */
public class GetUserIdByNickNameResponse extends AbstractResponse {

	/**
	 * 账号ID，默认为-1
	 */
	private long userId = -1;
	
	public GetUserIdByNickNameResponse(String[] args){
		super(args, 2);
	}

	@Override
	public void onSuccess(String[] args) {
		userId = Long.valueOf(args[1]);
	}

	/**
	 * 获取账号ID
	 * @return	账号ID
	 */
	public long getUserId() {
		return userId;
	}
	
}
