package com.imop.platform.local.request;

import com.imop.platform.local.config.IConfig;
import com.imop.platform.local.response.IResponse;
import com.imop.platform.local.response.QueryGoodsResponse;

/**
 * 奖品查询扩展接口<br>
 * 接口功能：<br>
 * 提供获取用户的多个礼品编号功能。
 * modify by liulu 0328 为盗墓LOCAL增加serverDomain
 * @author lu.liu
 *
 */
public class QueryGoodsRequest extends AbstractRequest {

	public QueryGoodsRequest(IConfig config){
		super(config);
		this.page = "u.querygoods.php" +
				"?timestamp=%s" +
				"&userid=%s" +
				"&roleid=%s" +
				"&ip=%s" +
				"&areaid=%s" +
				"&serverid=%s" +
				"&sign=%s";
	}

	@Override
	public IResponse getResponse(String[] args) {
		
		return new QueryGoodsResponse(args);
	}

	@Override
	public void setParams(Object... objects) {
		long timestamp = getTimestamp();
		int areaId = config.getAreaId();
		int serverId = config.getServerId();
	
		long userId = Long.valueOf(objects[0].toString());
		String roleId = objects[1].toString();
		String ip = objects[2].toString();
		
		String sign = getSign(timestamp,userId,roleId,ip,areaId,serverId);
		generateUrl(timestamp,userId,roleId,ip,areaId,serverId,sign);
	}

}
