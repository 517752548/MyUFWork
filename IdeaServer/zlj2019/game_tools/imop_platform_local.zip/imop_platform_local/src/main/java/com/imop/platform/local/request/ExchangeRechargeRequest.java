package com.imop.platform.local.request;

import com.imop.platform.local.config.IConfig;
import com.imop.platform.local.response.ExchangeRechargeResponse;
import com.imop.platform.local.response.IResponse;
import com.imop.platform.local.response.QueryRechargeResponse;

public class ExchangeRechargeRequest extends AbstractRequest{

	public ExchangeRechargeRequest(IConfig config) {
		super(config);
		this.page = "u.exchangerecharge.php?" +
				"timestamp=%s" +
				"&userid=%s" +
				"&pids=%s" +
				"&ip=%s" +
				"&areaid=%s" +
				"&serverid=%s";
	}

	@Override
	public IResponse getResponse(String[] args) {
		// TODO Auto-generated method stub
		return new ExchangeRechargeResponse(args);
	}

	@Override
	public void setParams(Object... objects) {
		long timestamp = getTimestamp();
		Long userid = Long.valueOf(objects[0].toString());
		String pids = objects[1].toString();
		String ip = objects[2].toString();
		int areaId = config.getAreaId();
		int serverId = config.getServerId();
		getUrl(timestamp,userid,pids,ip,areaId,serverId);
		
	}

}
