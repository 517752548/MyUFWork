package com.imop.platform.local.response;

public class PayChannelMobileCardResponse extends AbstractResponse {

	public PayChannelMobileCardResponse(String[] args) {
		super(args, 2);
	}

	@Override
	public void onSuccess(String[] args) {

	}

}
