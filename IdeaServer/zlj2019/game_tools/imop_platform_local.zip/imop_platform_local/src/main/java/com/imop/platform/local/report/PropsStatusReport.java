package com.imop.platform.local.report;

import com.imop.platform.local.config.IConfig;
import com.imop.platform.local.response.IResponse;
import com.imop.platform.local.response.ReportResponse;

/**
 * 发奖记录汇报接口<br>
 * 接口功能：<br>
 * 数据提供的发奖名单在GM后台发送时，每一条发奖记录都需要向CRM汇报一次发送状态。
 * @author lu.liu
 *
 */
public class PropsStatusReport extends AbstractReport {

	public PropsStatusReport(IConfig config){
		super(config);
		this.page = "props.status.php?timestamp=%s&domain=%s&areaid=%s&serverid=%s&activityid=%s&username=%s&passport=%s&rolename=%s&roleid=%s&serialid=%s&gmip=%s&gmer=%s&gmtime=%s&props=%s&propnum=%s&propname=%s&proplock=%s&propprice=%s&propaward=%s&status=%s&failure=%s&sign=%s&currenttime=%s";
	}

	@Override
	public IResponse getResponse(String[] args) {
		return new ReportResponse(args);
	}

	@Override
	public void setParams(Object... objects) {
		long timestamp = getTimestamp();
		int areaId = config.getAreaId();
		int serverId = config.getServerId();
		String domain = config.getDomain();
		
		String activityId = objects[0].toString();
		String userName = objects[1].toString();
		String passport = objects[2].toString();
		String roleName = objects[3].toString();
		String roleId = objects[4].toString();
		String serialid = objects[5].toString();
		String gmIp = objects[6].toString();
		String gmer = objects[7].toString();
		long gmTime = Long.valueOf(objects[8].toString());
		String props = objects[9].toString();
		String propnum = objects[10].toString();
		String propName = objects[11].toString();
		int propLock = Integer.valueOf(objects[12].toString());
		String propPrice = objects[13].toString();
		int propAward = Integer.valueOf(objects[14].toString());
		int status = Integer.valueOf(objects[14].toString());
		String failure = objects[15].toString();
		
		String sign = getSign(timestamp,passport,roleId,gmIp,areaId,serverId,serialid,status,failure);
		String datetime = getDateTime();
		generateUrl(timestamp,domain,areaId,serverId,activityId,userName,passport,roleName,roleId,serialid,gmIp,gmer,gmTime,props,propnum,propName,propLock,propPrice,propAward,status,failure,sign,datetime);
	}
	
}
