package com.imop.platform.local.response;

public class AddRoleReportResponse extends AbstractResponse {

	/**
	 * 账号ID，默认为-1
	 */
	private String state = null;
	
	public AddRoleReportResponse(String[] args) {
		super(args,2);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void onSuccess(String[] args) {
		state = args[0];
	}
	
	/**
	 * 获取账号ID
	 * @return	账号ID
	 */
	public String getState() {
		return state;
	}
	
}
