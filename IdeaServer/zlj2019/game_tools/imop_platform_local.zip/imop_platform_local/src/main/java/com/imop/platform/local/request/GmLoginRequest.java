package com.imop.platform.local.request;

import java.text.SimpleDateFormat;
import java.util.Date;

import net.sf.json.JSONObject;

import com.imop.platform.local.bean.ReportForDGBean;
import com.imop.platform.local.config.IConfig;
import com.imop.platform.local.response.IResponse;
import com.imop.platform.local.response.LoginResponse;

/**
 * 停机维护时测试用户登录验证接口<br>
 * 接口功能： <br>
 * （此接口供停服维护时使用）提供用户登录信息验证功能，游戏验证玩家登录需要调用此接口(原login3.php)。
 * @author lu.liu
 *
 */
public class GmLoginRequest extends AbstractRequest {
	
	public GmLoginRequest(IConfig config){
		super(config);
		this.page = "u.gmlogin.php" +
				"?timestamp=%s" +
				"&username=%s" +
				"&ip=%s" +
				"&areaid=%s" +
				"&serverid=%s" +
				"&psw=%s" +
				"&logintype=%s" +
				"&sign=%s" +
				"&dataext=%s";
	}
	
	@Override
	public IResponse getResponse(String[] args) {
		return new LoginResponse(args);
	}
	@Override
	public void recordUrl(String uuid, String url){
		StringBuffer sb = new StringBuffer(url);
		sb.replace(sb.indexOf("psw=")+4, sb.indexOf("&", sb.indexOf("psw=")+4), "******");
		config.getRecord().recordInfo(uuid + "\t" + sb.toString());
	}

	@Override
	public void setParams(Object... objects) {
		long timestamp = getTimestamp();
		int areaId = config.getAreaId();
		int serverId = config.getServerId();
		
		String userName = objects[0].toString();
		String ip = objects[1].toString();
		String password = objects[2].toString();
		int loginType = Integer.valueOf(objects[3].toString());
		
		ReportForDGBean bean = (ReportForDGBean) objects[4];
		long date= System.currentTimeMillis()/1000;
		//System.out.println(date);
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		java.util.Calendar cal = java.util.Calendar.getInstance();   
	    cal.setTime(new Date(date*1000));
		int zoneOffset = cal.get(java.util.Calendar.ZONE_OFFSET);   
		int dstOffset = cal.get(java.util.Calendar.DST_OFFSET);    
		cal.add(java.util.Calendar.MILLISECOND, -(zoneOffset + dstOffset)); 
		String nowTime = df.format(new Date(date*1000));
		String utcTime = df.format(cal.getTime());
		bean.complement(timestamp*1000, utcTime, nowTime, config.getGamecode(), config.getPlatformid(), ""+areaId,""+serverId, config.getDomain());
		
		
			
		String sign = getSign(timestamp,encodeUrl(userName),ip,areaId,serverId,password,loginType);
		generateUrl(timestamp,userName,ip,areaId,serverId,password,loginType,sign,JSONObject.fromObject(bean).toString());
	}
	

}
