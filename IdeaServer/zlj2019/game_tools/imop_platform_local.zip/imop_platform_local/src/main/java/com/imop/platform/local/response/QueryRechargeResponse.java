package com.imop.platform.local.response;

import java.awt.List;
import java.util.ArrayList;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

public class QueryRechargeResponse extends AbstractResponse {

	private String json_str = "";
	
	/**
	 * 充值信息，如果无充值信息，则长度为0.
	 */
	private ArrayList<Order> recharge = new ArrayList<Order>();
	
	public QueryRechargeResponse(String[] args) {
		super(args,2);
	}
	
	/**
	 * 充值信息，如果无充值信息，则长度为0.
	 */
	public ArrayList<Order> getRecharge() {
		return recharge;
	}

	@Override
	public void onSuccess(String[] args) {
		this.json_str = args[1].toString();
		String json_value = this.getJsonValue(JSONObject.fromObject(this.json_str),"recharge");
		JSONArray json_arr = JSONArray.fromObject(json_value);
		for(int i=0;i<json_arr.size();i++){
			JSONObject json_temp = json_arr.getJSONObject(i);
			Order order = new Order();
			order.id=this.getJsonValue(json_temp,"id");
			order.user_id=this.getJsonValue(json_temp,"user_id");
			order.user_name=this.getJsonValue(json_temp,"user_name");
			order.order_id=this.getJsonValue(json_temp,"order_id");
			order.amount=this.getJsonValue(json_temp,"amount");
			order.currency=this.getJsonValue(json_temp,"currency");
			order.item_id=this.getJsonValue(json_temp,"item_id");
			order.game_points=this.getJsonValue(json_temp,"game_points");
			order.type=this.getJsonValue(json_temp,"type");
			order.udid=this.getJsonValue(json_temp,"udid");
			order.device_id=this.getJsonValue(json_temp,"device_id");
			order.game_code=this.getJsonValue(json_temp,"game_code");
			order.game_domain=this.getJsonValue(json_temp,"game_domain");
			order.game_server_domain=this.getJsonValue(json_temp,"game_server_domain");
			order.char_id=this.getJsonValue(json_temp,"char_id");
			order.char_name=this.getJsonValue(json_temp,"char_name");
			order.add_time=this.getJsonValue(json_temp,"add_time");
			order.expend_time=this.getJsonValue(json_temp,"expend_time");
			order.delay_time=this.getJsonValue(json_temp,"delay_time");
			order.terminal=this.getJsonValue(json_temp,"terminal");
			order.remark=this.getJsonValue(json_temp,"remark");
			recharge.add(order);
		}
	}
	/**
	 * 内部类，用于存储一条充值信息
	 * @author jiang.li
	 *
	 */
	public class Order{
		/**
		 * 唯一ID
		 */
		public String id;
		/**
		 * 用户Id
		 */
		public String user_id;
		/**
		 * 用户名
		 */
		public String user_name;
		/**
		 * 订单流水号
		 */
		public String order_id;
		/**
		 * 金额
		 */
		public String amount;
		/**
		 * 币种
		 */
		public String currency;
		/**
		 * 套餐ID
		 */
		public String item_id;
		/**
		 * 游戏币
		 */
		public String game_points;
		/**
		 * 充值类型，IOS、PLATFORM、GAME等
		 */
		public String type;
		/**
		 * 苹果终端号
		 */
		public String udid;
		/**
		 * MAC信息
		 */
		public String device_id;
		/**
		 * 游戏唯一code
		 */
		public String game_code;
		/**
		 * 游戏唯一域名
		 */
		public String game_domain;
		/**
		 * 游戏服唯一域名
		 */
		public String game_server_domain;
		/**
		 * 角色ID
		 */
		public String char_id;
		/**
		 * 角色名
		 */
		public String char_name;
		/**
		 * 添加时间
		 */
		public String add_time;
		/**
		 * 消费时间
		 */
		public String expend_time;
		/**
		 * 延迟获取时间
		 */
		public String delay_time;
		/**
		 * 终端类型
		 */
		public String terminal;
		/**
		 * 备注信息
		 */
		public String remark;
	}
}
