package com.imop.platform.local.response;

public class AddWallowInfoResponse extends AbstractResponse {
	
	private long userId;

	public AddWallowInfoResponse(String[] args) {
		super(args, 2);
	}

	@Override
	public void onSuccess(String[] args) {
		userId = Long.valueOf(args[1]);
	}

	public long getUserId() {
		return userId;
	}

}
