package com.imop.platform.local.request;

import com.imop.platform.local.config.IConfig;
import com.imop.platform.local.response.ExpendGamePointsResponse;
import com.imop.platform.local.response.IResponse;

public class ExpendGamePointsRequest extends AbstractRequest {

	public ExpendGamePointsRequest(IConfig config) {
		super(config);
		this.page="u.expendgamepoints.php?" +
				"timestamp=%s&" +
				"userid=%s&" +
				"roleid=%s&" +
				"ip=%s&" +
				"areaid=%s&" +
				"serverid=%s&" +
				"domain=%s&" +
				"orderid=%s&" +
				"currenttime=%s&" +
				"type=%s&" +
				"sign=%s";
	}

	@Override
	public IResponse getResponse(String[] args) {
		return new ExpendGamePointsResponse(args);
	}

	@Override
	public void setParams(Object... objects) {

		long timestamp = getTimestamp();
		int areaId = config.getAreaId();
		int serverId = config.getServerId();
		String domain = config.getDomain();
		int type=1;

		long userid = Long.valueOf(objects[0].toString());
		long roleid = Long.valueOf(objects[1].toString());
		String ip = objects[2].toString();
		String orderid = objects[3].toString();
		long currenttime = Long.valueOf(objects[4].toString());
		if(6==objects.length)
			type=Integer.valueOf(objects[5].toString());
			
		
		String sign = getSign(timestamp,userid,roleid,ip,areaId,serverId,orderid);
		generateUrl(timestamp,userid,roleid,ip,areaId,serverId,domain,orderid,currenttime,type,sign);	

	}

}
