package com.imop.platform.local.response;

public class ExpendIOSPaymentResponse extends AbstractResponse {

	private String orderId=null;
	
	private long userId = -1;
	
	private long money = 0;
	
	public ExpendIOSPaymentResponse(String[] args) {
		super(args, 4);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void onSuccess(String[] args) {
		this.orderId = args[1];
		this.userId = Long.valueOf(args[2]);
		this.money  = Long.valueOf(args[3]);

	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public long getUserId() {
		return userId;
	}

	public void setUserId(long userId) {
		this.userId = userId;
	}

	public long getMoney() {
		return money;
	}

	public void setMoney(long money) {
		this.money = money;
	}

}
