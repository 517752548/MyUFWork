package com.imop.platform.local.response;

public class CaptchaCheckResponse extends AbstractResponse {

	public CaptchaCheckResponse(String[] args) {
		super(args, 2);
	}

	@Override
	public void onSuccess(String[] args) {

	}

}
