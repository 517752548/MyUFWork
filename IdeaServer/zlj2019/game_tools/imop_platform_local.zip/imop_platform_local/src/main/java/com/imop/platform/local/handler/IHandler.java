package com.imop.platform.local.handler;


import java.math.BigDecimal;
import java.util.Map;
import java.util.concurrent.ExecutorService;

import com.imop.platform.local.bean.ReportForDGBean;
import com.imop.platform.local.callback.ICallback;
import com.imop.platform.local.config.LocalConfig;
import com.imop.platform.local.request.TransferReportParam;
import com.imop.platform.local.request.TransferReportRequest.enum_chargetype;
import com.imop.platform.local.request.TransferReportRequest.enum_currency;
import com.imop.platform.local.response.ActiveUseCodeResponse;
import com.imop.platform.local.response.AddAttentionResponse;
import com.imop.platform.local.response.AddRoleReportResponse;
import com.imop.platform.local.response.AddWallowInfoResponse;
import com.imop.platform.local.response.CaptchaCheckResponse;
import com.imop.platform.local.response.CaptchaSendResponse;
import com.imop.platform.local.response.ChannelUserLoginResponse;
import com.imop.platform.local.response.CreateIOSPaymentResponse;
import com.imop.platform.local.response.CreateLinkResponse;
import com.imop.platform.local.response.DelRoleReportResponse;
import com.imop.platform.local.response.ExchangeRechargeResponse;
import com.imop.platform.local.response.ExpendGamePointsResponse;
import com.imop.platform.local.response.ExpendIOSPaymentResponse;
import com.imop.platform.local.response.GenerateOrderResponse;
import com.imop.platform.local.response.GetFCMTimeResponse;
import com.imop.platform.local.response.GetFriendsListResponse;
import com.imop.platform.local.response.GetGameUserInfoResponse;
import com.imop.platform.local.response.GetGoodsResponse;
import com.imop.platform.local.response.GetNGWordResponse;
import com.imop.platform.local.response.GetNickNameResponse;
import com.imop.platform.local.response.GetUserBirthdayResponse;
import com.imop.platform.local.response.GetUserIdByChannelNameResponse;
import com.imop.platform.local.response.GetUserIdByNameResponse;
import com.imop.platform.local.response.GetUserIdByNickNameResponse;
import com.imop.platform.local.response.GetUserInfoResponse;
import com.imop.platform.local.response.GetUserIsLegalResponse;
import com.imop.platform.local.response.GetUserNameByIdResponse;
import com.imop.platform.local.response.GetVersionResponse;
import com.imop.platform.local.response.IOSRechargeResponse;
import com.imop.platform.local.response.IsBlackListUserResqponse;
import com.imop.platform.local.response.LoginResponse;
import com.imop.platform.local.response.LogoutResponse;
import com.imop.platform.local.response.PayChannelMobileCardResponse;
import com.imop.platform.local.response.PayChannelMycardResponse;
import com.imop.platform.local.response.PayChannelQueryStatusResponse;
import com.imop.platform.local.response.PayChannelRRCardRespose;
import com.imop.platform.local.response.QueryAllRechargeResponse;
import com.imop.platform.local.response.QueryBalanceResponse;
import com.imop.platform.local.response.QueryGoodsResponse;
import com.imop.platform.local.response.QueryOnlineTimeResponse;
import com.imop.platform.local.response.QueryRechargeResponse;
import com.imop.platform.local.response.QuickLoginResponse;
import com.imop.platform.local.response.SurveyResponse;
import com.imop.platform.local.response.ThirdActivitiesCodeResponse;
import com.imop.platform.local.response.TransferReportResponse;
import com.imop.platform.local.response.TransferResponse;
import com.imop.platform.local.type.IEnumType;
import com.imop.platform.local.type.LoginType;

/**
 * 平台接口处理器
 * @author lu.liu
 *
 */
public interface IHandler {
	/**
	 * 充值接口 
	 * @param userId	用户ID。
	 * @param roleid	用户角色ID。
	 * @param ip		表示充值的客户端IP地址。
	 * @param orderid   接口调用方生成的订单流水号
	 * @param currenttime	游戏服系统时间，时间格式为YYYYMMDDHHmmss
	 * @return			充值结果<br><br>
	 * 					充值成功时：<br>&nbsp;&nbsp;1：调用方生成的订单流水号<br><br>
	 * 							   <br>&nbsp;&nbsp;2：userId表示用户ID<br><br>
	 * 	 						   <br>&nbsp;&nbsp;3：充值成功金额<br><br>
	 * 					充值失败时：errorCode表示错误码<br>
	 * 					&nbsp;&nbsp;1：签名验证失败<br>
	 * 					&nbsp;&nbsp;2：时间戳过期<br>
	 * 					&nbsp;&nbsp;3：有参数为空或格式不正确<br>
	 * 					&nbsp;&nbsp;999：系统异常，退出操作不成功<br>
	 */
	@Deprecated
	public ExpendGamePointsResponse expendGamePoints(long userId,long roleid,String ip,String orderid,long currenttime);
	
	/**
	 * 充值接口
	 * @param userId	用户ID。
	 * @param roleid	用户角色ID。
	 * @param ip		表示充值的客户端IP地址。
	 * @param orderid   接口调用方生成的订单流水号
	 * @param currenttime	游戏服系统时间，时间格式为YYYYMMDDHHmmss
	 * @param type 		接口返回类型，type=1 正常 ；type=2 返回值中多携带设备终端类型
	 * @return			充值结果<br><br>
	 * 					充值成功时：<br>&nbsp;&nbsp;1：调用方生成的订单流水号<br><br>
	 * 							   <br>&nbsp;&nbsp;2：userId表示用户ID<br><br>
	 * 	 						   <br>&nbsp;&nbsp;3：充值成功金额<br><br>
	 * 	 						   <br>&nbsp;&nbsp;4：终端类型，只有type=2的时候才返回，如果不存在返回unknown<br><br>	 * 					充值失败时：errorCode表示错误码<br>
	 * 					&nbsp;&nbsp;1：签名验证失败<br>
	 * 					&nbsp;&nbsp;2：时间戳过期<br>
	 * 					&nbsp;&nbsp;3：有参数为空或格式不正确<br>
	 * 					&nbsp;&nbsp;999：系统异常，退出操作不成功<br>
	 */
	@Deprecated
	public ExpendGamePointsResponse expendGamePoints(long userId,long roleid,String ip,String orderid,long currenttime,int type);
	
	/**
	 * 用户登录验证接口（同步调用）
	 * @param userName	当使用用户名密码认证时 username=用户名；当使用COOKIE认证 时 username=cookie值；当使用TOKEN认证时 username=token值。
	 * @param password	表示用户密码 。
	 * @param ip		表示用户登录游戏时的客户端IP地址。
	 * @param loginType	参见枚举类LoginType
	 * @return			登录结果<br><br>
	 * 					登录成功时：<br>&nbsp;&nbsp;1：userId表示用户ID<br>&nbsp;&nbsp;2：userName表示用户名<br>&nbsp;&nbsp;3：antiIndulge表示该用户是否为防沉迷对象（-1不是，1是）；<br>&nbsp;&nbsp;4：infoIntegrity表示资料是否完整<br><br>
	 * 					登录失败时：errorCode表示错误码<br>
	 * 					&nbsp;&nbsp;1：签名验证失败<br>
	 * 					&nbsp;&nbsp;2：时间戳过期<br>
	 * 					&nbsp;&nbsp;3：有参数为空或格式不正确<br>
	 * 					&nbsp;&nbsp;4：用户名密码验证未通过<br>
	 * 					&nbsp;&nbsp;5：用户已经被锁定<br>
	 * 					&nbsp;&nbsp;6：密保未通过<br>
	 * 					&nbsp;&nbsp;7：cookie验证未通过<br>
	 * 					&nbsp;&nbsp;8：token验证未通过<br>
	 * 					&nbsp;&nbsp;9：大区验证未通过<br>
	 * 					&nbsp;&nbsp;999：系统异常，登录操作不成功<br>
	 */
	public LoginResponse login(String userName,String password,String ip,IEnumType<LoginType> loginType);
	/**
	 * 用户登录验证接口（同步调用）
	 * @param userName	当使用用户名密码认证时 username=用户名；当使用COOKIE认证 时 username=cookie值；当使用TOKEN认证时 username=token值。
	 * @param password	表示用户密码 。
	 * @param ip		表示用户登录游戏时的客户端IP地址。
	 * @param loginType	参见枚举类LoginType
	 * @param bean		数据组汇报Bean
	 * @return			登录结果<br><br>
	 * 					登录成功时：<br>&nbsp;&nbsp;1：userId表示用户ID<br>&nbsp;&nbsp;2：userName表示用户名<br>&nbsp;&nbsp;3：antiIndulge表示该用户是否为防沉迷对象（-1不是，1是）；<br>&nbsp;&nbsp;4：infoIntegrity表示资料是否完整<br><br>
	 * 					登录失败时：errorCode表示错误码<br>
	 * 					&nbsp;&nbsp;1：签名验证失败<br>
	 * 					&nbsp;&nbsp;2：时间戳过期<br>
	 * 					&nbsp;&nbsp;3：有参数为空或格式不正确<br>
	 * 					&nbsp;&nbsp;4：用户名密码验证未通过<br>
	 * 					&nbsp;&nbsp;5：用户已经被锁定<br>
	 * 					&nbsp;&nbsp;6：密保未通过<br>
	 * 					&nbsp;&nbsp;7：cookie验证未通过<br>
	 * 					&nbsp;&nbsp;8：token验证未通过<br>
	 * 					&nbsp;&nbsp;9：大区验证未通过<br>
	 * 					&nbsp;&nbsp;999：系统异常，登录操作不成功<br>
	 */
	public LoginResponse login(String userName,String password,String ip,IEnumType<LoginType> loginType,ReportForDGBean bean);
	
	/**
	 * 用户登录验证接口（同步调用）
	 * @param userName	当使用用户名密码认证时 username=用户名；当使用COOKIE认证 时 username=cookie值；当使用TOKEN认证时 username=token值。
	 * @param password	表示用户密码 。
	 * @param ip		表示用户登录游戏时的客户端IP地址。
	 * @param loginType	参见枚举类LoginType
	 * @param getkxid	强制获取开心网ID时： getkxid=1；默认为获取人人ID： getkxid=2或者不传该参数；
	 * @return			登录结果<br><br>
	 * 					登录成功时：<br>&nbsp;&nbsp;1：userId表示用户ID<br>&nbsp;&nbsp;2：userName表示用户名<br>&nbsp;&nbsp;3：antiIndulge表示该用户是否为防沉迷对象（-1不是，1是）；<br>&nbsp;&nbsp;4：infoIntegrity表示资料是否完整<br><br>
	 * 					登录失败时：errorCode表示错误码<br>
	 * 					&nbsp;&nbsp;1：签名验证失败<br>
	 * 					&nbsp;&nbsp;2：时间戳过期<br>
	 * 					&nbsp;&nbsp;3：有参数为空或格式不正确<br>
	 * 					&nbsp;&nbsp;4：用户名密码验证未通过<br>
	 * 					&nbsp;&nbsp;5：用户已经被锁定<br>
	 * 					&nbsp;&nbsp;6：密保未通过<br>
	 * 					&nbsp;&nbsp;7：cookie验证未通过<br>
	 * 					&nbsp;&nbsp;8：token验证未通过<br>
	 * 					&nbsp;&nbsp;9：大区验证未通过<br>
	 * 					&nbsp;&nbsp;999：系统异常，登录操作不成功<br>
	 */
	public LoginResponse login(String userName, String password, String ip,IEnumType<LoginType> loginType, int getkxid);
	
	/**
	 * 用户登录验证接口（同步调用）
	 * @param userName	当使用用户名密码认证时 username=用户名；当使用COOKIE认证 时 username=cookie值；当使用TOKEN认证时 username=token值。
	 * @param password	表示用户密码 。
	 * @param ip		表示用户登录游戏时的客户端IP地址。
	 * @param loginType	参见枚举类LoginType
	 * @param getkxid	强制获取开心网ID时： getkxid=1；默认为获取人人ID： getkxid=2或者不传该参数；
	 * @param bean		数据组汇报Bean
	 * @return			登录结果<br><br>
	 * 					登录成功时：<br>&nbsp;&nbsp;1：userId表示用户ID<br>&nbsp;&nbsp;2：userName表示用户名<br>&nbsp;&nbsp;3：antiIndulge表示该用户是否为防沉迷对象（-1不是，1是）；<br>&nbsp;&nbsp;4：infoIntegrity表示资料是否完整<br><br>
	 * 					登录失败时：errorCode表示错误码<br>
	 * 					&nbsp;&nbsp;1：签名验证失败<br>
	 * 					&nbsp;&nbsp;2：时间戳过期<br>
	 * 					&nbsp;&nbsp;3：有参数为空或格式不正确<br>
	 * 					&nbsp;&nbsp;4：用户名密码验证未通过<br>
	 * 					&nbsp;&nbsp;5：用户已经被锁定<br>
	 * 					&nbsp;&nbsp;6：密保未通过<br>
	 * 					&nbsp;&nbsp;7：cookie验证未通过<br>
	 * 					&nbsp;&nbsp;8：token验证未通过<br>
	 * 					&nbsp;&nbsp;9：大区验证未通过<br>
	 * 					&nbsp;&nbsp;999：系统异常，登录操作不成功<br>
	 */
	public LoginResponse login(String userName, String password, String ip,IEnumType<LoginType> loginType, int getkxid,ReportForDGBean bean);
	/**
	 * 用户退出游戏接口（同步调用）
	 * @param userId	用户ID（userid）。
	 * @param ip		表示用户退出游戏时的客户端IP地址。
	 * @return			退出结果<br><br>
	 * 					退出成功时：<br>&nbsp;&nbsp;1：userId表示用户ID<br><br>
	 * 					退出失败时：errorCode表示错误码<br>
	 * 					&nbsp;&nbsp;1：签名验证失败<br>
	 * 					&nbsp;&nbsp;2：时间戳过期<br>
	 * 					&nbsp;&nbsp;3：有参数为空或格式不正确<br>
	 * 					&nbsp;&nbsp;999：系统异常，退出操作不成功<br>
	 */
	public LogoutResponse logout(long userId,String ip);
	/**
	 * 用户退出游戏接口（同步调用）
	 * @param userId	用户ID（userid）。
	 * @param ip		表示用户退出游戏时的客户端IP地址。
	 * @param bean		数据组汇报Bean
	 * @return			退出结果<br><br>
	 * 					退出成功时：<br>&nbsp;&nbsp;1：userId表示用户ID<br><br>
	 * 					退出失败时：errorCode表示错误码<br>
	 * 					&nbsp;&nbsp;1：签名验证失败<br>
	 * 					&nbsp;&nbsp;2：时间戳过期<br>
	 * 					&nbsp;&nbsp;3：有参数为空或格式不正确<br>
	 * 					&nbsp;&nbsp;999：系统异常，退出操作不成功<br>
	 */
	public LogoutResponse logout(long userId,String ip,ReportForDGBean bean);
	
	/**
	 * 游戏世界兑换游戏币接口（同步调用）,默认不获取订单ID,
	 * @deprecated 从3.3.14开始使用transfer(long userId,String roleId,int money,String ip,int getOrderId)代替。
	 * @param userId	用户ID（userid）。
	 * @param roleId	用户在游戏中的角色编号(role id)。
	 * @param money		充值金额。
	 * @param ip		用户兑换游戏币时的客户端IP地址。
	 * @return			兑换结果<br><br>
	 * 					兑换成功时：<br>&nbsp;&nbsp;1：userId表示用户ID<br>&nbsp;&nbsp;2：balance表示扣除后的用户账户余额<br>&nbsp;&nbsp;orderID表示订单ID<br><br>
	 * 					兑换失败时：errorCode表示错误码<br>
	 * 					&nbsp;&nbsp;1：签名验证失败<br>
	 * 					&nbsp;&nbsp;2：时间戳过期<br>
	 * 					&nbsp;&nbsp;3：有参数为空或格式不正确<br>
	 * 					&nbsp;&nbsp;4：余额不足<br>
	 * 					&nbsp;&nbsp;999：系统异常，兑换操作不成功<br>
	 */
	@Deprecated
	public TransferResponse transfer(long userId,String roleId,int money,String ip);
	
	/**
	 * 游戏世界兑换游戏币接口（同步调用）
	 * @param userId	用户ID（userid）。
	 * @param roleId	用户在游戏中的角色编号(role id)。
	 * @param money		充值金额。
	 * @param ip		用户兑换游戏币时的客户端IP地址。
	 * @param getOrderId 区分是否获取订单ID getorderid=1 返回%3订单ID getorderid=2或者不传该参数 默认，则不返回%3订单ID
	 * @return			兑换结果<br><br>
	 * 					兑换成功时：<br>&nbsp;&nbsp;1：userId表示用户ID<br>&nbsp;&nbsp;2：balance表示扣除后的用户账户余额<br>&nbsp;&nbsp;orderID表示订单ID<br><br>
	 * 					兑换失败时：errorCode表示错误码<br>
	 * 					&nbsp;&nbsp;1：签名验证失败<br>
	 * 					&nbsp;&nbsp;2：时间戳过期<br>
	 * 					&nbsp;&nbsp;3：有参数为空或格式不正确<br>
	 * 					&nbsp;&nbsp;4：余额不足<br>
	 * 					&nbsp;&nbsp;999：系统异常，兑换操作不成功<br>
	 */
	public TransferResponse transfer(long userId,String roleId,int money,String ip,int getOrderId);
	
	/**
	 * 游戏世界兑换游戏币接口（同步调用）
	 * @param userId	用户ID（userid）。
	 * @param roleId	用户在游戏中的角色编号(role id)。
	 * @param money		充值金额。
	 * @param ip		用户兑换游戏币时的客户端IP地址。
	 * @param getOrderId 区分是否获取订单ID getorderid=1 返回%3订单ID getorderid=2或者不传该参数 默认，则不返回%3订单ID
	 * @param getOrderId	区分是否获取该笔兑换平台币数量  getorderid=1 返回%4该笔兑换平台币数量 getorderid=2或者不传该参数 默认，则不返回%4该笔兑换平台币数量
	 * @return			兑换结果<br><br>
	 * 					兑换成功时：<br>&nbsp;&nbsp;1：userId表示用户ID<br>&nbsp;&nbsp;2：balance表示扣除后的用户账户余额<br>&nbsp;&nbsp;orderID表示订单ID<br><br>
	 * 					兑换失败时：errorCode表示错误码<br>
	 * 					&nbsp;&nbsp;1：签名验证失败<br>
	 * 					&nbsp;&nbsp;2：时间戳过期<br>
	 * 					&nbsp;&nbsp;3：有参数为空或格式不正确<br>
	 * 					&nbsp;&nbsp;4：余额不足<br>
	 * 					&nbsp;&nbsp;999：系统异常，兑换操作不成功<br>
	 */
	public TransferResponse transfer(long userId, String roleId, int money, String ip , int getOrderId , int gettransfer);
	
	/**
	 * 游戏内消耗汇报接口
	 * 提供用户在游戏内消耗平台一级货币或等值物品的汇报接口,包括直冲,IOS直冲,平台币兑换以及奖励
	 * @param userId	用户ID（userid）
	 * @param roleid	用户在游戏中的角色编号(roleid)
	 * @param ip		用户兑换游戏币时的客户端IP地址。eg：202.104.1.1
	 * @param orderid	订单号， 秒时间戳+6位随机串，例如：1270605064123456
	 * @param gamebean	获得一级游戏币数量
	 * @param chargetype	兑换类型(expend，transfer，iosexpend，largess)，只能选四种之一，全小写。直冲 expend , 平台币兑换 transfer , ios直冲 iosexpend , 额外奖励 largess
	 * @param currency	币种(全大写)，常用如下所示 ： BEAN 平台币 ， CNY 人民币 ， USD 美元 ， KRW 韩元， THB 泰元
	 * @param mount		数量(指货币的数量)
	 * @param addtionInfo	JSON格式扩展信息，如果确实没有扩展信息，可以不传递该参数，即为""
	 * @param itemid	套餐id，如果确实没有套餐id，可以不传递该参数，即为""
	 * @param itemname 	套餐名，如果确实没有套餐名，可以不传递该参数，即为""
	 * @param currettime	游戏服系统时间，时间格式为YYYYMMDDHHmmss,eg:20120506170824(表示2012年5月6日17时8分24秒) 。注：该时间传的是游戏服当地时间，用于解决时区问题。
	 * @return			
	 * 			成功：result	 如果值为success表示汇报成功，其他表示汇报失败
	 * 			失败：{"error_code":1}
	 */
	@Deprecated
	public TransferReportResponse transferReport(
			long userId,
			String roleid,
			String ip,
			String orderid,
			BigDecimal gamebean,
			enum_chargetype chargetype,
			enum_currency currency,
			BigDecimal mount,
			String addtionInfo,
			String itemid,
			String itemname,
			long currenttime);
	
	
	
	/**
	 * 游戏世界余额查询接口（同步调用）
	 * @param userId	用户ID（userid）。
	 * @param ip		表示用户查询余额时的客户端IP地址。
	 * @return			查询结果<br><br>
	 * 					查询成功时：<br>&nbsp;&nbsp;1：balance表示用户账户余额<br><br>
	 * 					查询失败时：errorCode表示错误码<br>
	 * 					&nbsp;&nbsp;1：签名验证失败<br>
	 * 					&nbsp;&nbsp;2：时间戳过期<br>
	 * 					&nbsp;&nbsp;3：有参数为空或格式不正确<br>
	 * 					&nbsp;&nbsp;999：系统异常，查询操作不成功<br>
	 */
	public QueryBalanceResponse queryBalance(long userId,String ip);
	
	/**
	 * 游戏同时在线人数接口（异步调用）
	 * @param onlineNum	当前的游戏服务器人数。
	 * @param callback	异步回调接口
	 */
	public void onlineReport(int onlineNum,ICallback callback);
	
	/**
	 * 游戏同时在线人数接口（异步调用）
	 * @param serverId	服务器ID（适用于分线汇报的游戏）
	 * @param onlineNum	当前的游戏服务器人数。
	 * @param callback	异步回调接口
	 */
	public void onlineReport(int serverId, int onlineNum,ICallback callback);
	
	/**
	 * 游戏同时在线人数接口（异步调用）
	 * @param onlineNum	当前的游戏服务器人数。
	 */
	public void onlineReport(int onlineNum);
	
	/**
	 * 游戏同时在线人数接口（异步调用）
	 * @param serverId	服务器ID（适用于分线汇报的游戏）
	 * @param onlineNum	当前的游戏服务器人数。
	 */
	public void onlineReport(int serverId, int onlineNum);
	
	/**
	 * 奖品查询扩展接口（同步调用）
	 * @param userId	用户ID（userid）。
	 * @param roleId	用户在游戏中的角色编号(role id)。
	 * @param ip		用户查询礼品时的客户端IP地址。
	 * @return			奖品查询结果<br><br>
	 * 					查询成功时：<br>&nbsp;&nbsp;1：goodsInfoList表示奖品集合<br><br>
	 * 					查询失败时：errorCode表示错误码<br>
	 * 					&nbsp;&nbsp;1：签名验证失败<br>
	 * 					&nbsp;&nbsp;2：时间戳过期<br>
	 * 					&nbsp;&nbsp;3：有参数为空或格式错误<br>
	 * 					&nbsp;&nbsp;4：该用户没有礼品。<br>
	 * 					&nbsp;&nbsp;999：系统异常，查询操作不成功<br>
	 */
	public QueryGoodsResponse queryGoods(long userId,String roleId,String ip);
	
	/**
	 * 奖品领取扩展接口（同步调用）
	 * @param userId	用户ID（userid）。
	 * @param roleId	用户在游戏中的角色编号(role id)。
	 * @param ip		用户领取奖品时的客户端IP地址。
	 * @param id		奖励唯一ID。
	 * @param largessId	礼品编号。
	 * @return			领奖结果<br><br>
	 * 					领奖成功时：<br>&nbsp;&nbsp;1：prizeId表示礼品编号<br><br>
	 * 					领奖失败时：errorCode表示错误码<br>
	 * 					&nbsp;&nbsp;1：签名验证失败<br>
	 * 					&nbsp;&nbsp;2：时间戳过期<br>
	 * 					&nbsp;&nbsp;3：有参数为空或格式错误<br>
	 * 					&nbsp;&nbsp;4：该用户没有礼品<br>
	 * 					&nbsp;&nbsp;999：系统异常，查询操作不成功<br>
	 */
	public GetGoodsResponse getGoods(long userId,String roleId,String ip,int id,int largessId);
	
	/**
	 * 游戏server运行状态汇报接口（异步调用）
	 * @param servers	服务器id
	 * @param status	当前运行状态，大写，例：RUN
	 * @param extra		其他备选信息。
	 * @param callback	异步回调接口
	 */
	public void statusReport(String servers,String status,String extra,ICallback callback);
	
	/**
	 * 游戏server运行状态汇报接口（异步调用）
	 * @param servers	服务器id
	 * @param status	当前运行状态，大写，例：RUN
	 * @param extra		其他备选信息。
	 */
	public void statusReport(String servers,String status,String extra);
	
	/**
	 * 记录游戏贵重物品消耗接口（异步调用）
	 * @param orderId	表示消耗订单号。
	 * @param userId	用户ID（userid）。
	 * @param roleId	用户在游戏中的角色编号(role id)。
	 * @param money		该笔消耗所花费的金额。
	 * @param goodSid	购买的游戏物品编号。
	 * @param ip		用户消耗贵重物品时的客户端IP地址。
	 * @param callback	异步回调接口
	 */
	public void transRecordReport(String orderId,long userId,String roleId,long money,String goodSid,String ip,ICallback callback);

	/**
	 * 记录游戏贵重物品消耗接口（异步调用）
	 * @param orderId	表示消耗订单号。
	 * @param userId	用户ID（userid）。
	 * @param roleId	用户在游戏中的角色编号(role id)。
	 * @param money		该笔消耗所花费的金额。
	 * @param goodSid	购买的游戏物品编号。
	 * @param ip		用户消耗贵重物品时的客户端IP地址。
	 */
	public void transRecordReport(String orderId,long userId,String roleId,long money,String goodSid,String ip);

	/**
	 * 停机维护时测试用户登录验证接口（同步调用）
	 * @param userName	当使用用户名密码认证时 username=用户名<br>当使用COOKIE认证 时 username=cookie值<br>当使用TOKEN认证时 username=token值。
	 * @param ip		表示用户登录游戏时的客户端IP地址。
	 * @param password	表示用户密码 。
	 * @param loginType	参见枚举类LoginType
	 * @return			GM账号登录结果<br><br>
	 * 					登录成功时：<br>&nbsp;&nbsp;1：返回值同login接口返回值<br><br>
	 * 					登录失败时：errorCode同login接口<br>
	 * 					&nbsp;&nbsp;1：签名验证失败<br>
	 * 					&nbsp;&nbsp;2：时间戳过期<br>
	 * 					&nbsp;&nbsp;3：有参数为空或格式不正确<br>
	 * 					&nbsp;&nbsp;4：用户名密码验证未通过<br>
	 * 					&nbsp;&nbsp;5：用户已经被锁定<br>
	 * 					&nbsp;&nbsp;6：密保未通过<br>
	 * 					&nbsp;&nbsp;7：cookie验证未通过<br>
	 * 					&nbsp;&nbsp;8：token验证未通过<br>
	 * 					&nbsp;&nbsp;9：大区验证未通过<br>
	 * 					&nbsp;&nbsp;10：该用户不在GM白名单内<br>
	 * 					&nbsp;&nbsp;999：系统异常，登录操作不成功<br>
	 */
	public LoginResponse gmLogin(String userName,String ip,String password,IEnumType<LoginType> loginType);
	
	/**
	 * 停机维护时测试用户登录验证接口（同步调用）
	 * @param userName	当使用用户名密码认证时 username=用户名<br>当使用COOKIE认证 时 username=cookie值<br>当使用TOKEN认证时 username=token值。
	 * @param ip		表示用户登录游戏时的客户端IP地址。
	 * @param password	表示用户密码 。
	 * @param loginType	参见枚举类LoginType
	 * @param bean		数据组汇报Bean
	 * @return			GM账号登录结果<br><br>
	 * 					登录成功时：<br>&nbsp;&nbsp;1：返回值同login接口返回值<br><br>
	 * 					登录失败时：errorCode同login接口<br>
	 * 					&nbsp;&nbsp;1：签名验证失败<br>
	 * 					&nbsp;&nbsp;2：时间戳过期<br>
	 * 					&nbsp;&nbsp;3：有参数为空或格式不正确<br>
	 * 					&nbsp;&nbsp;4：用户名密码验证未通过<br>
	 * 					&nbsp;&nbsp;5：用户已经被锁定<br>
	 * 					&nbsp;&nbsp;6：密保未通过<br>
	 * 					&nbsp;&nbsp;7：cookie验证未通过<br>
	 * 					&nbsp;&nbsp;8：token验证未通过<br>
	 * 					&nbsp;&nbsp;9：大区验证未通过<br>
	 * 					&nbsp;&nbsp;10：该用户不在GM白名单内<br>
	 * 					&nbsp;&nbsp;999：系统异常，登录操作不成功<br>
	 */
	public LoginResponse gmLogin(String userName,String ip,String password,IEnumType<LoginType> loginType,ReportForDGBean bean);
	/**
	 * 通过用户id获取用户名称接口（同步调用）
	 * @param userId	用户ID（userid）。
	 * @param ip		用户客户端IP地址。
	 * @param areaId	表示游戏服务器所在的大区号。
	 * @param serverId	表示游戏服务器号。
	 * @return			获取用户名结果<br><br>
	 * 					获取成功时：<br>&nbsp;&nbsp;1：userName表示用户名称<br><br>
	 * 					获取失败时：errorCode表示错误码<br>
	 *					&nbsp;&nbsp;1：签名验证失败<br>
	 *					&nbsp;&nbsp;2：时间戳过期<br>
	 *					&nbsp;&nbsp;3：有参数为空或格式错误<br>
	 *					&nbsp;&nbsp;4：该用户id不存在<br>
	 *					&nbsp;&nbsp;999：系统异常，操作不成功<br>
	 */
	public GetUserNameByIdResponse getUserNameById(long userId,String ip);
	
	/**
	 * 通过用户名称获取用户id接口（同步调用）
	 * @param userName	用户名称（username）。
	 * @param ip		用户客户端IP地址。
	 * @return			获取用户ID结果<br><br>
	 * 					获取成功时：<br>&nbsp;&nbsp;1：userId表示用户ID<br><br>
	 * 					获取失败时：error表示错误码<br>
	 * 					&nbsp;&nbsp;1：签名验证失败<br>
	 * 					&nbsp;&nbsp;2：时间戳过期<br>
	 * 					&nbsp;&nbsp;3：有参数为空或格式错误<br>
	 * 					&nbsp;&nbsp;4：该用户名称不存在<br>
	 * 					&nbsp;&nbsp;999：系统异常，操作不成功<br>
	 */
	public GetUserIdByNameResponse getUserIdByName(String userName,String ip);
	
	/**
	 * 检测用户是否合法接口（同步调用）
	 * @param userName	用户名称。
	 * @param psw		用户密码。
	 * @param ip		用户客户端IP地址。
	 * @return			检测结果<br><br>
	 * 					检测成功时：<br>&nbsp;&nbsp;1：userId表示合法用户ID<br>&nbsp;&nbsp;2：userName表示合法用户名<br>&nbsp;&nbsp;3：reserve表示预留字段<br><br>
	 * 					检测失败时：errorCode表示错误码<br>
	 * 					&nbsp;&nbsp;1：签名验证失败<br>
	 * 					&nbsp;&nbsp;2：时间戳过期<br>
	 * 					&nbsp;&nbsp;3：有参数为空或格式错误<br>
	 * 					&nbsp;&nbsp;4：非法用户<br>
	 * 					&nbsp;&nbsp;999：系统异常，操作不成功<br>
	 */
	public GetUserIsLegalResponse getUserIsLegal(String userName,String psw,String ip);
	
	/**
	 * 获取用户登录千橡游戏累计时间接口（同步调用）
	 * @param userId	用户id。
	 * @return			获取累计时间结果<br><br>
	 * 					获取成功时：<br>&nbsp;&nbsp;1：userId表示用户ID<br>&nbsp;&nbsp;2：onlinetime表示用户的在线累计秒数<br><br>
	 * 					获取失败时：errorCode表示错误码<br>
	 * 					&nbsp;&nbsp;1：签名验证失败<br>
	 * 					&nbsp;&nbsp;2：时间戳过期<br>
	 * 					&nbsp;&nbsp;3：有参数为空或格式错误<br>
	 * 					&nbsp;&nbsp;4：非法用户<br>
	 * 					&nbsp;&nbsp;999：系统异常，操作不成功<br>
	 */
	public QueryOnlineTimeResponse queryOnlineTime(long userId);
	
	/**
	 * 举报玩家非法言论接口（异步调用）
	 * @param ip		举报人客户端IP地址。
	 * @param repoterUname	举报人的登录账户名
	 * @param repoterUid	举报人的账户id
	 * @param repoterRid	举报人的角色id
	 * @param repoterRolename	举报人的角色名称
	 * @param repoterLevel		举报人的角色等级
	 * @param repoterTime	举报时间
	 * @param playerUname	被举报人的登录账户名
	 * @param playerUid		被举报人的账户id
	 * @param playerRoleId	被举报人的角色id
	 * @param playerRoleName	被举报人的角色名称
	 * @param playerLevel		被举报人的角色等级
	 * @param channel	被举报人发言频道
	 * @param sayTime	被举报人发言时间
	 * @param msgId		被举报人所发消息的流水号（uuid）
	 * @param msg		被举报人所发消息的内容
	 * @param callback	异步回调接口
	 */
	public void reportPlayerReport(String ip,String repoterUname,long repoterUid,long repoterRid,String repoterRoleName,int repoterLevel,long repoterTime,String playerUname,long playerUid,long playerRoleId,String playerRoleName,int playerLevel,String channel,String sayTime,String msgId,String msg,ICallback callback);

	/**
	 * 举报玩家非法言论接口（异步调用）
	 * @param ip		举报人客户端IP地址。
	 * @param repoterUname	举报人的登录账户名
	 * @param repoterUid	举报人的账户id
	 * @param repoterRid	举报人的角色id
	 * @param repoterRolename	举报人的角色名称
	 * @param repoterLevel		举报人的角色等级
	 * @param repoterTime	举报时间
	 * @param playerUname	被举报人的登录账户名
	 * @param playerUid		被举报人的账户id
	 * @param playerRoleId	被举报人的角色id
	 * @param playerRoleName	被举报人的角色名称
	 * @param playerLevel		被举报人的角色等级
	 * @param channel	被举报人发言频道
	 * @param sayTime	被举报人发言时间
	 * @param msgId		被举报人所发消息的流水号（uuid）
	 * @param msg		被举报人所发消息的内容
	 */
	public void reportPlayerReport(String ip,String repoterUname,long repoterUid,long repoterRid,String repoterRoleName,int repoterLevel,long repoterTime,String playerUname,long playerUid,long playerRoleId,String playerRoleName,int playerLevel,String channel,String sayTime,String msgId,String msg);
	
	/**
	 * 领取GM奖励汇报接口（异步调用）
	 * @param ip		领奖人客户端IP地址。
	 * @param activityId	发奖活动编号。如 1111
	 * @param serialid	发奖或者补偿的流水号
	 * @param getTime	领奖时间，标准时间戳（精确到秒）
	 * @param userName	玩家领取账号
	 * @param userId	玩家领取账号id
	 * @param roleName	玩家领取角色
	 * @param roleId	玩家领取角色id
	 * @param props		领取道具
	 * @param propNum	领取数量
	 * @param callback	异步回调接口
	 */
	public void reportGmLargessReport(String ip,String activityId,String serialid,long getTime,String userName,long userId,String roleName,long roleId,String props,String propNum,ICallback callback);

	/**
	 * 领取GM奖励汇报接口（异步调用）
	 * @param ip		领奖人客户端IP地址。
	 * @param activityId	发奖活动编号。如 1111
	 * @param serialid	发奖或者补偿的流水号
	 * @param getTime	领奖时间，标准时间戳（精确到秒）
	 * @param userName	玩家领取账号
	 * @param userId	玩家领取账号id
	 * @param roleName	玩家领取角色
	 * @param roleId	玩家领取角色id
	 * @param props		领取道具
	 * @param propNum	领取数量
	 */
	public void reportGmLargessReport(String ip,String activityId,String serialid,long getTime,String userName,long userId,String roleName,long roleId,String props,String propNum);
	
	/**
	 * 发奖记录汇报接口（异步调用）
	 * @param activityId	发奖活动编号。如 1111
	 * @param userName	玩家帐号 如darhli
	 * @param userId	玩家平台ID 如 13721231
	 * @param roleName	玩家游戏角色名 如baibai
	 * @param roleId	玩家游戏角色ID 如 10212
	 * @param serialid	发奖流水号 如1231
	 * @param gmIp		GM操作IP 如 211.100.1.11
	 * @param gmer		GM操作人 如 xx
	 * @param gmTime	GM操作时间戳（精确到秒），例如：1270605064。
	 * @param props		实际发放道具ID 如 100011
	 * @param propnum	实际发放道具数量 如100
	 * @param propName	实际发放道具中文名称 如 金币
	 * @param propLock	道具是否绑定 0 不绑定 1 绑定
	 * @param propPrice	道具参考单价（人民币） 如1.5（没有价格为0）
	 * @param propAward	道具领奖方式 0 主动领奖 1 直接发送至背包内
	 * @param status	是否发送成功 0 失败 1 成功
	 * @param failure	失败原因描述（成功时为空）
	 * @param callback	异步回调接口
	 */
	public void propsStatusReport(String activityId,String userName,String userId,String roleName,String roleId,String serialid,String gmIp,String gmer,long gmTime,String props,String propnum,String propName,int propLock,String propPrice,int propAward,int status,String failure,ICallback callback);

	/**
	 * 发奖记录汇报接口（异步调用）
	 * @param activityId	发奖活动编号。如 1111
	 * @param userName	玩家帐号 如darhli
	 * @param userId	玩家平台ID 如 13721231
	 * @param roleName	玩家游戏角色名 如baibai
	 * @param roleId	玩家游戏角色ID 如 10212
	 * @param serialid	发奖流水号 如1231
	 * @param gmIp		GM操作IP 如 211.100.1.11
	 * @param gmer		GM操作人 如 xx
	 * @param gmTime	GM操作时间戳（精确到秒），例如：1270605064。
	 * @param props		实际发放道具ID 如 100011
	 * @param propnum	实际发放道具数量 如100
	 * @param propName	实际发放道具中文名称 如 金币
	 * @param propLock	道具是否绑定 0 不绑定 1 绑定
	 * @param propPrice	道具参考单价（人民币） 如1.5（没有价格为0）
	 * @param propAward	道具领奖方式 0 主动领奖 1 直接发送至背包内
	 * @param status	是否发送成功 0 失败 1 成功
	 * @param failure	失败原因描述（成功时为空）
	 */
	public void propsStatusReport(String activityId,String userName,String userId,String roleName,String roleId,String serialid,String gmIp,String gmer,long gmTime,String props,String propnum,String propName,int propLock,String propPrice,int propAward,int status,String failure);
	
	/**
	 * 获取人人用户信息接口（同步调用）
	 * @param userId	用户ID（userid）。
	 * @return
	 */
	public GetUserInfoResponse getUserInfo(long userId);
	
	/**
	 * 通过昵称得到人人用户id（同步调用）
	 * @param nickName	用户昵称。
	 * @return			查询结果<br><br>
	 * 					获取成功时：<br>&nbsp;&nbsp;1：userId表示用户Id<br><br>
	 * 					获取失败时：errorCode表示错误码<br>
	 * 					&nbsp;&nbsp;1：签名验证失败<br>
	 * 					&nbsp;&nbsp;2：昵称参数为空<br>
	 * 					&nbsp;&nbsp;3：无用户信息<br>
	 * 					&nbsp;&nbsp;999：系统异常，操作不成功<br>
	 */
	public GetUserIdByNickNameResponse getUserIdByNickName(String nickName);
	
	/**
	 * 通过渠道用户名和渠道编号获取用户id（同步调用）
	 * @param channelusername	用户名称
	 * @param channelcode		渠道编号
	 * @param ip				用户客户端IP地址
	 * @return			查询结果<br><br>
	 * 					获取成功时：<br>&nbsp;&nbsp;1：userId表示用户Id<br><br>
	 * 					获取失败时：errorCode表示错误码<br>
	 * 					&nbsp;&nbsp;5：签名验证失败<br>
	 * 					&nbsp;&nbsp;6：时间戳过期<br>
	 * 					&nbsp;&nbsp;7：有参数为空或格式错误<br>
	 * 					&nbsp;&nbsp;8：该渠道用户名称不存在<br>
	 * 					&nbsp;&nbsp;999：系统异常，操作不成功<br>
	 */
	public GetUserIdByChannelNameResponse getUserIdByChannelName(String channelusername, String channelcode, String ip);
	
	/**
	 * 通过人人用户id获取昵称（同步调用）
	 * @param userId	用户id（userid）。
	 * @return			查询结果<br><br>
	 * 					查询成功时：<br>&nbsp;&nbsp;1：nickName表示用户昵称<br><br>
	 * 					查询失败时：errorCode表示错误码<br>
	 * 					&nbsp;&nbsp;1：签名验证失败<br>
	 * 					&nbsp;&nbsp;2：参数为空或格式不正确<br>
	 * 					&nbsp;&nbsp;3：没有用户信息<br>
	 * 					&nbsp;&nbsp;999：系统异常，操作不成功<br>
	 */
	public GetNickNameResponse getNickName(long userId);
	
	/**
	 * 用户防沉迷信息注册接口（同步调用）
	 * @param userId	用户ID（userid）
	 * @param trueName	用户真实名字,UTF-8汉字编码
	 * @param idCard	用户身份证号
	 * @param ip		表示用户提交信息时的客户端IP地址。
	 * @return			查询结果<br><br>
	 * 					查询成功时：<br>&nbsp;&nbsp;1：userId表示用户ID<br><br>
	 * 					查询失败时：errorCode表示错误码<br>
	 * 					&nbsp;&nbsp;1：签名验证失败<br>
	 * 					&nbsp;&nbsp;2：时间戳过期<br>
	 * 					&nbsp;&nbsp;3：有参数为空或格式不正确<br>
	 * 					&nbsp;&nbsp;4：真实姓名不合法<br>
	 * 					&nbsp;&nbsp;5：身份证格式错误<br>
	 * 					&nbsp;&nbsp;999：系统异常，操作不成功<br>
	 */
	public AddWallowInfoResponse addWallowInfo(long userId, String trueName, String idCard, String ip);
	
	/**
	 * @param userId
	 * @param ip
	 * @return
	 */
	public GetGameUserInfoResponse getGameUserInfo(long userId, String ip);
	
	/**
	 * 获取用户好友列表
	 * @param ticket 用户cookie的t值
	 * @return 查询结果<br/><br/>
	 *         查询正确时：<br/>返回用户列表List<FriendsInfo>或json串friendsListJson<br/>
	 *         查询错误时：<br/>fail:%1<br/>
	 *         &nbsp;&nbsp;1：签名验证失败<br>
	 *		   &nbsp;&nbsp;2：时间戳过期<br>
	 *		   &nbsp;&nbsp;3：有参数为空或格式不正确<br>
	 * 		   &nbsp;&nbsp;999：系统异常，操作不成功<br>
	 */
	public GetFriendsListResponse getFriendsList(String ticket);
	
	/**
	 * 获取用户防沉迷注册时填写的生日信息
	 * @param userId 	用户ID
	 * @param ip		用户客户端IP地址
	 * @return 查询结果<br/><br/>
	 *         查询正确时：<br>&nbsp;&nbsp;1：userId表示用户ID<br>&nbsp;&nbsp;2：用户生日<br><br>
	 *         查询错误时：<br/>fail:%1<br/>
	 *         &nbsp;&nbsp;1：签名验证失败<br>
	 *		   &nbsp;&nbsp;2：时间戳过期<br>
	 *		   &nbsp;&nbsp;3：有参数为空或格式错误<br>
	 * 		   &nbsp;&nbsp;11：用户为注册过防沉迷信息<br>
	 * 		   &nbsp;&nbsp;999：系统异常，操作不成功<br>
	 */
	public GetUserBirthdayResponse getUserBirthday(long userId, String ip);

	/**
	 * 添加用户关注
	 * @param ticket 用户cookie的t值
	 * @return 查询结果<br/><br/>
	 *         查询正确时：<br/>ok:1<br/>
	 *         &nbsp;&nbsp;1：签名验证失败<br>
	 *		   &nbsp;&nbsp;2：时间戳过期<br>
	 *		   &nbsp;&nbsp;3：有参数为空或格式不正确<br>
	 * 		   &nbsp;&nbsp;999：系统异常，操作不成功<br>
	 */
	public AddAttentionResponse addattention(String ticket);
	
	/**
	 * 创建用户链接
	 * @param ticket 用户cookie的t值
	 * @return 查询结果<br/><br/>
	 *         查询正确时：<br/>ok:%link<br/>
	 *         &nbsp;&nbsp;1：签名验证失败<br>
	 *		   &nbsp;&nbsp;2：时间戳过期<br>
	 *		   &nbsp;&nbsp;3：有参数为空或格式不正确<br>
	 * 		   &nbsp;&nbsp;999：系统异常，操作不成功<br>
	 */
	public CreateLinkResponse createlink(String ticket);
	
	/**
	 * 获取版本号信息（同步调用）
	 * @return
	 */
	public GetVersionResponse getVersion();

	
	/**
	 * 获取jar包配置
	 * @return	接口配置对象
	 */
	public LocalConfig getConfig();
	
	/**
	 * 设置线程池
	 * @param service	线程池
	 */
	public void setReportService(ExecutorService service);

	/**
	 * 领奖码激活接口
	 * @param userid			用户id
	 * @param activationCode	激活码
	 * @param ip				用户ip
	 * @return 查询结果<br/><br/>
	 *         查询正确时：<br/>ok:1<br/>
	 *         &nbsp;&nbsp;1：签名验证失败<br>
	 *		   &nbsp;&nbsp;2：时间戳过期<br>
	 *		   &nbsp;&nbsp;3：有参数为空或格式不正确<br>
	 *		   &nbsp;&nbsp;12：激活码无效或者已经使用
	 * 		   &nbsp;&nbsp;999：系统异常，操作不成功<br>
	 */
	public ActiveUseCodeResponse activeUseCode(long userid,String activationCode,String ip);
	
	/**
	 * 游戏创建角色汇报接口
	 * @param userid		用户id
	 * @param roleId		角色ID
	 * @param rolename		角色名
	 * @param ip			用户登陆游戏时的客户端IP地址，ip地址如果时代理的地址，必须取到最后真实的ip地址。
	 * @return 查询结果<br/><br/>
	 *         查询正确时：<br/>ok<br/>
	 *         &nbsp;&nbsp;1：签名验证失败<br>
	 *		   &nbsp;&nbsp;2：时间戳过期<br>
	 *		   &nbsp;&nbsp;3：有参数为空或格式不正确<br>
	 * 		   &nbsp;&nbsp;999：系统异常，操作不成功<br>
	 */
	 
	public AddRoleReportResponse addRoleReport(long userid,String roleId,String rolename,String ip);

	/**
	 * 游戏删除角色汇报接口
	 * @param userid		用户id
	 * @param roleId		角色ID
	 * @param rolename		角色名
	 * @param ip			用户登陆游戏时的客户端IP地址，ip地址如果时代理的地址，必须取到最后真实的ip地址。
	 * @return 查询结果<br/><br/>
	 *         查询正确时：<br/>ok<br/>
	 *         &nbsp;&nbsp;1：签名验证失败<br>
	 *		   &nbsp;&nbsp;2：时间戳过期<br>
	 *		   &nbsp;&nbsp;3：有参数为空或格式不正确<br>
	 * 		   &nbsp;&nbsp;999：系统异常，操作不成功<br>
	 */
	public DelRoleReportResponse delRoleReport(long userid,String roleId,String rolename,String ip);
	
	/**
	 * oauth类型渠道登陆接口 
	 * @param token 		票据
	 * @param channelcode	渠道编号
	 * @param ip			用户登陆游戏时的客户端IP地址
	 * @return			查询结果<br><br>
	 * 					查询成功时：<br>&nbsp;&nbsp;1：userId表示用户ID<br><br>
	 * 									&nbsp;&nbsp;2 username 用户名<br> 
	 * 	 								&nbsp;&nbsp;3：antiIndulge 防沉迷<br>
	 * 	  								&nbsp;&nbsp;4：infoIntegrity 资料完整性<br>
	 * 					查询失败时：errorCode表示错误码<br>
	 * 					&nbsp;&nbsp;1：签名验证失败<br>
	 * 					&nbsp;&nbsp;2：时间戳过期<br>
	 * 					&nbsp;&nbsp;3：有参数为空或格式不正确<br>
	 * 					&nbsp;&nbsp;4：用户名密码验证未通过<br>
	 * 					&nbsp;&nbsp;5：用户已经被锁定<br>
	 * 					&nbsp;&nbsp;6：密保未通过<br>
	 * 					&nbsp;&nbsp;7：cookie验证未通过<br>
	 * 	  				&nbsp;&nbsp;8：token验证未通过<br>
	 * 	 				&nbsp;&nbsp;9：大区验证未通过<br>
	 * 	 				&nbsp;&nbsp;11：账号未激活<br>
	 * 					&nbsp;&nbsp;999：系统异常，操作不成功<br>
	 */
	public LoginResponse oauthLogin(String token,String channelcode,String ip);
	
	/**
	 * 通过Yahoo验证用户发言信息合法性
	 * @param userId	用户ID（userid）
	 * @param ip		用户领取奖品时的客户端IP地址
	 * @param word		用户要发布的内容
	 * @param currenttime	游戏服系统时间，时间格式为YYYYMMDDHHmmss
	 	 * @return			查询结果<br><br>
	 * 					查询成功时：<br>&nbsp;&nbsp;1：1（表示用户输入内容合法）<br><br>
	 * 					查询失败时：errorCode表示错误码<br>
	 * 					&nbsp;&nbsp;1：签名验证失败<br>
	 * 					&nbsp;&nbsp;2：时间戳过期<br>
	 * 					&nbsp;&nbsp;3：有参数为空或格式不正确<br>
	 * 					&nbsp;&nbsp;4：用户输入内容为非法信息<br>
	 */
	public GetNGWordResponse getNGWord(long userId,String ip,String word,long currenttime);

	/**
	 * 获取玩家防沉迷时段接口
	 * @param userId	用户ID（userid）
	 * @param ip		用户客户端IP地址
	 * @param currenttime	游戏服系统时间，时间格式为YYYYMMDDHHmmss
	 	 * @return			查询结果<br><br>
	 * 					查询成功时：<br>&nbsp;&nbsp;1：时间段<br><br>
	 * 					查询失败时：errorCode表示错误码<br>
	 * 					&nbsp;&nbsp;1：签名验证失败<br>
	 * 					&nbsp;&nbsp;2：时间戳过期<br>
	 * 					&nbsp;&nbsp;3：有参数为空或格式不正确<br>
	 * 					&nbsp;&nbsp;4：用户非防沉迷用户<br>
	 * 	 				&nbsp;&nbsp;5：用户未填写实名信息<br>
	 */
	public GetFCMTimeResponse getFCMTime(long userId,String ip,long currenttime);
	
	/**
	 * ios直充接口（生成直充订单）
	 * 		提供IOS端游戏内进行直充功能的接口，生成直充订单。
	 * 		兼容{item_table}和{amount、itemID、itemName、coin}两种参数传递方式，必选其一
	 * @param userId 用户ID
	 * @param roleId 角色ID
	 * @param ip	表示用户登陆游戏时的客户端IP地址
	 * @param item_table 套餐信息
	 * @param token	票据
	 * @param udid 设备号
	 * @param uuid 也就是所谓的macinfo，是设备mac地址的MD5
	 * @return 查询结果<br/><br/>
	 *         查询正确时：<br>&nbsp;&nbsp;1：状态码
	 *         			&nbsp;&nbsp;&nbsp;<br>状态码具体描述：
	 *         			<br>&nbsp;&nbsp;&nbsp;&nbsp;1&nbsp;&nbsp;&nbsp;&nbsp;:正确情况
	 *         			<br>&nbsp;&nbsp;&nbsp;&nbsp;5000:IOS票据为空
	 *              	<br>&nbsp;&nbsp;&nbsp;&nbsp;5001:IOS请求失败
	 *             		<br>&nbsp;&nbsp;&nbsp;&nbsp;5002:IOS黑名单用户
	 *                	<br>&nbsp;&nbsp;&nbsp;&nbsp;5003:IOS票据错误
	 *                	<br>&nbsp;&nbsp;&nbsp;&nbsp;5004:IOS套餐ID错误
	 *         			<br>&nbsp;&nbsp;&nbsp;&nbsp;5005:IOS票据重复使用
	 *         			<br>&nbsp;&nbsp;&nbsp;&nbsp;5999:IOS用户被限制，一定时间不能获取游戏币
       						<br>&nbsp;&nbsp;2：appstore订单号<br><br>
	 *         				<br>&nbsp;&nbsp;3：产品id<br><br>
	 *  
	 *         查询失败时：errorCode表示错误码<br>  
	 *         &nbsp;&nbsp;1：签名验证失败<br>
	 *		   &nbsp;&nbsp;2：时间戳过期<br>
	 *		   &nbsp;&nbsp;3：有参数为空或格式不正确<br>
	 * 		   &nbsp;&nbsp;999：系统异常，操作不成功<br>
	 */
	public CreateIOSPaymentResponse createIOSPayment(long userId,String roleId,String ip,String item_table,String token,String udid,String uuid);
	
	/**
	 * ios直充接口（生成直充订单）
	 * 		提供IOS端游戏内进行直充功能的接口，生成直充订单。
	 * 		兼容{item_table}和{amount、itemID、itemName、coin}两种参数传递方式，必选其一
	 * 		uuid 与 macinfo 内容尽量保持一致，如不一致则以uuid为准
	 * @param userId 用户ID
	 * @param roleId 角色ID
	 * @param ip	表示用户登陆游戏时的客户端IP地址
	 * @param item_table 套餐信息
	 * @param token	票据
	 * @param udid 设备号
	 * @param uuid 设备mac地址的MD5
	 * @param macinfo 设备mac地址的MD5
	 * @return 查询结果<br/><br/>
	 *         查询正确时：<br>&nbsp;&nbsp;1：状态码
	 *         			&nbsp;&nbsp;&nbsp;<br>状态码具体描述：
	 *         			<br>&nbsp;&nbsp;&nbsp;&nbsp;1&nbsp;&nbsp;&nbsp;&nbsp;:正确情况
	 *         			<br>&nbsp;&nbsp;&nbsp;&nbsp;5000:IOS票据为空
	 *              	<br>&nbsp;&nbsp;&nbsp;&nbsp;5001:IOS请求失败
	 *             		<br>&nbsp;&nbsp;&nbsp;&nbsp;5002:IOS黑名单用户
	 *                	<br>&nbsp;&nbsp;&nbsp;&nbsp;5003:IOS票据错误
	 *                	<br>&nbsp;&nbsp;&nbsp;&nbsp;5004:IOS套餐ID错误
	 *         			<br>&nbsp;&nbsp;&nbsp;&nbsp;5005:IOS票据重复使用
	 *         			<br>&nbsp;&nbsp;&nbsp;&nbsp;5999:IOS用户被限制，一定时间不能获取游戏币
       						<br>&nbsp;&nbsp;2：appstore订单号<br><br>
	 *         				<br>&nbsp;&nbsp;3：产品id<br><br>
	 *  
	 *         查询失败时：errorCode表示错误码<br>  
	 *         &nbsp;&nbsp;1：签名验证失败<br>
	 *		   &nbsp;&nbsp;2：时间戳过期<br>
	 *		   &nbsp;&nbsp;3：有参数为空或格式不正确<br>
	 * 		   &nbsp;&nbsp;999：系统异常，操作不成功<br>
	 */
	public CreateIOSPaymentResponse createIOSPayment(long userId,String roleId,String ip,String item_table,String token,String udid,String uuid , String macinfo);


	/**
	 * ios直充接口（查询并兑换）
	 * @param userId 用户ID
	 * @param roleId 角色ID
	 * @param ip	表示用户登陆游戏时的客户端IP地址
	 * @param udid 设备号
	 * @return 查询结果<br/><br/>
	 *         查询正确时：	<br>&nbsp;&nbsp;1：调用方生成的订单流水号<br><br>
	 *         				<br>&nbsp;&nbsp;2：表示用户ID<br><br>
	 *         				<br>&nbsp;&nbsp;3：表示直充成功金额，没有充值的用户该返回值为0<br><br>
	 *         查询失败时：errorCode表示错误码<br>  
	 *         &nbsp;&nbsp;1：签名验证失败<br>
	 *		   &nbsp;&nbsp;2：时间戳过期<br>
	 *		   &nbsp;&nbsp;3：有参数为空或格式不正确<br>
	 * 		   &nbsp;&nbsp;999：系统异常，操作不成功<br>
	 */
	public ExpendIOSPaymentResponse expendIOSPayment(long userId,String roleId,String ip,String udid);

	/**
	 * 判断玩家是否黑名单用户
	 * @param userId 用户ID
	 * @param ip 用户登陆游戏时的客户端IP地址
	 * @param udid 设备号
	 * @param uuid 设备mac地址的MD5
	 * @return 查询结果<br/><br/>
	 *         查询正确时：<br/>ok<br/>
	 *         查询失败时：	         
	 *         errorCode表示错误码<br>  
	 *         &nbsp;&nbsp;1：签名验证失败<br>
	 *		   &nbsp;&nbsp;2：时间戳过期<br>
	 *		   &nbsp;&nbsp;3：有参数为空或格式不正确<br>
	 *		   &nbsp;&nbsp;4：黑名单玩家<br>
	 * 		   &nbsp;&nbsp;999：系统异常，操作不成功<br>
	 */
	public IsBlackListUserResqponse isBlackListUser(long userId,String ip,String udid,String uuid);

	/**
	 * 查询玩家充值信息
	 * 接口功能：<br>
	 * 		查询该玩家尚未进行兑换的充值信息，用于提供可供游戏调用兑换的相关信息。<br>
	 * 		该接口和"兑换玩家充值信息"接口联合一起进行使用，用于完成对玩家直冲信息的查询及兑换操作。
	 * @param userId 用户ID
	 * @param ip 用户登陆游戏时的客户端IP地址
	 * @param currenttime 游戏服系统时间，时间格式为YYYYMMDDHHmmss
	 * @return 查询结果<br/><br/>
	 *         查询正确时：<br/>ok<br/>
	 *         查询失败时：	         
	 *         errorCode表示错误码<br>  
	 *         &nbsp;&nbsp;1：签名验证失败<br>
	 *		   &nbsp;&nbsp;2：时间戳过期<br>
	 *		   &nbsp;&nbsp;3：有参数为空或格式不正确<br>
	 *		   &nbsp;&nbsp;4：玩家充值信息查询不成功<br>
	 * 		   &nbsp;&nbsp;999：系统异常，操作不成功<br>
	 */
	public QueryRechargeResponse queryRecharge(long userId,String ip,long currenttime);
	
	/**
	 * 兑换玩家充值信息
	 * 接口功能：<br> 
	 * 		兑换该玩家尚未进行兑换的充值信息。<br>
	 * 		该接口和"查询玩家充值信息"接口联合一起进行使用，用于完成对玩家直冲信息的查询及兑换操作。
	 * @param userId 用户ID
	 * @param pids 有三种形式：第一种 1002（表示只兑换1002订单），第二种 1002,1003,1004（表示只兑换这三个订单） ， 第三种 all/ALL(兑换全部)
	 * @param ip 用户登陆游戏时的客户端IP地址
	 * @param currenttime 游戏服系统时间，时间格式为YYYYMMDDHHmmss
	 * @return 查询结果<br/><br/>
	 *         查询正确时：<br/>ok<br/>
	 *         查询失败时：	         
	 *         errorCode表示错误码<br>  
	 *         &nbsp;&nbsp;1：签名验证失败<br>
	 *		   &nbsp;&nbsp;2：时间戳过期<br>
	 *		   &nbsp;&nbsp;3：有参数为空或格式不正确<br>
	 *		   &nbsp;&nbsp;4：玩家充值信息查询不成功<br>
	 * 		   &nbsp;&nbsp;999：系统异常，操作不成功<br>
	 */
	public ExchangeRechargeResponse exchangerecharge(long userId,String pids,String ip,long currenttime);
	
	/**
	 * 生成玩家IOS充值信息
	 * 接口功能：<br>
	 * 		提供IOS端游戏内进行直冲功能的接口，生成直冲订单。
	 * @param userId 用户ID
	 * @param roleId 角色ID
	 * @param item_table 套餐信息
	 * @param token 票据
	 * @param ip 表示用户登录游戏时的客户端IP地址。
	 * @param currenttime 游戏服系统时间，时间格式为YYYYMMDDHHmmss
	 * @param udid 设备号
	 * @param amount 充值的金额
	 * @param itemId 充值套餐的ID
	 * @param itemName 充值套餐的名称
	 * @param coin 充值的平台币数量
	 * @param macInfo 终端mac地址MD5后的结果
	 * @param userName 玩家姓名
	 * @param charName 角色姓名
	 * @param deviceType 设备型号
	 * @param deviceVersion 操作系统版本，全小写
	 * @return 
	 */
	public IOSRechargeResponse iosRecharge(long userId,String roleId,String item_table, String amount,String itemId,String itemName,long coin,String macInfo,String token,String ip,long currenttime,String udid,String userName,String charName,String deviceType,String deviceVersion);


	/**
	 * 游戏内发放第三方兑奖码接口
	 * 接口功能：<br>
	 * 		提供游戏内直接发放第三方兑奖码功能，每个用户ID在单活动中只能领取一个激活码，第二次领取时会显示上次领取的激活码，发放的激活码是针对大区发放的激活码。发奖报错仅提供一种错误信息，如果领奖错误请直接向玩家提示激活码已发完即可。
	 * @param userId 用户ID
	 * @param activiesNumbers 活动编号
	 * @param currenttime 游戏服系统时间，时间格式为YYYYMMDDHHmmss
	 * @return
	 * 		成功：{"code":"44C3B12717CD1B14972M"}<br>
	 * 		失败：{"error_code":1}		签名验证失败<br>
	 *			{"error_code":2}	时间戳过期<br>
	 *			{"error_code":3}	有参数为空或格式不正确<br>
	 *			{"error_code":4}	活动码已发放完<br>
	 *			{"error_code":999}	系统异常，操作不成功<br>
	 */
	public ThirdActivitiesCodeResponse thirdActivitiesCode(long userId , String activiesNumbers , String ip , long currenttime );

	/**
	 * 玩家账号注册并登陆接口（带F值传递，但可以为空）
	 * 接口功能：<br>
	 * 		提供游戏内直接注册账号的功能，如果该玩家已经注册将直接返回用户信息。
	 * @param ip 表示用户登录游戏时的客户端IP地址
	 * @param currenttime 游戏服系统时间，时间格式为YYYYMMDDHHmmss 注：该时间传的是游戏服当地时间，用于解决时区问题。
	 * @param uuid IOS快客打通中使用IOS设备号udid即可<br>注意：同一个IOS终端将只会打通成一个账号，故仅用于快速打通 <br>
	 * @param promotionCode 推广码，即F值，可选<br>
	 * @param bean		数据组汇报Bean
	 * @return
	 * 		成功：{"userid":123456789,"username":"feng.hong","wallow":"Y","infofull":"Y","cookie":"123456789012345678901234567890AB"}<br>
	 * 		失败：{"error_code":1}		签名验证失败<br>
	 *			{"error_code":2}	时间戳过期<br>
	 *			{"error_code":3}	有参数为空或格式不正确<br>
	 *			{"error_code":4}	可能为以下其中之一 活动码已发放完 <br>
	 *								充值接口被关闭 <br>
	 *								玩家充值信息查询不成功 <br>
	 *			{"error_code":999}	系统异常，操作不成功<br>
	 */
	public QuickLoginResponse quickLogin(String ip,Long currenttime,String uuid,String promotionCode,ReportForDGBean bean);
	
	/**
	 * 玩家账号注册并登陆接口（带F值传递，但可以为空）
	 * 接口功能：<br>
	 * 		提供游戏内直接注册账号的功能，如果该玩家已经注册将直接返回用户信息。
	 * @param ip 表示用户登录游戏时的客户端IP地址
	 * @param currenttime 游戏服系统时间，时间格式为YYYYMMDDHHmmss 注：该时间传的是游戏服当地时间，用于解决时区问题。
	 * @param uuid IOS快客打通中使用IOS设备号udid即可<br>注意：同一个IOS终端将只会打通成一个账号，故仅用于快速打通 <br>
	 * @param promotionCode 推广码，即F值，可选<br>
	 * @return
	 * 		成功：{"userid":123456789,"username":"feng.hong","wallow":"Y","infofull":"Y","cookie":"123456789012345678901234567890AB"}<br>
	 * 		失败：{"error_code":1}		签名验证失败<br>
	 *			{"error_code":2}	时间戳过期<br>
	 *			{"error_code":3}	有参数为空或格式不正确<br>
	 *			{"error_code":4}	可能为以下其中之一 活动码已发放完 <br>
	 *								充值接口被关闭 <br>
	 *								玩家充值信息查询不成功 <br>
	 *			{"error_code":999}	系统异常，操作不成功<br>
	 */
	public QuickLoginResponse quickLogin(String ip,Long currenttime,String uuid,String promotionCode);
	
	/**
	 * 玩家账号注册并登陆接口（无F值传递）
	 * 接口功能：<br>
	 * 		提供游戏内直接注册账号的功能，如果该玩家已经注册将直接返回用户信息。
	 * @param ip 表示用户登录游戏时的客户端IP地址
	 * @param currenttime 游戏服系统时间，时间格式为YYYYMMDDHHmmss 注：该时间传的是游戏服当地时间，用于解决时区问题。
	 * @param uuid IOS快客打通中使用IOS设备号udid即可<br>注意：同一个IOS终端将只会打通成一个账号，故仅用于快速打通 <br>
	 * @return
	 * 		成功：{"userid":123456789,"username":"feng.hong","wallow":"Y","infofull":"Y","cookie":"123456789012345678901234567890AB"}<br>
	 * 		失败：{"error_code":1}		签名验证失败<br>
	 *			{"error_code":2}	时间戳过期<br>
	 *			{"error_code":3}	有参数为空或格式不正确<br>
	 *			{"error_code":4}	可能为以下其中之一 活动码已发放完 <br>
	 *								充值接口被关闭 <br>
	 *								玩家充值信息查询不成功 <br>
	 *			{"error_code":999}	系统异常，操作不成功<br>
	 */
	public QuickLoginResponse quickLogin(String ip,Long currenttime,String uuid);

	AddWallowInfoResponse addWallowInfo(long userId, String trueName,
			String idCard, String ip, String cookie);

	/**
	 * 游戏内消耗汇报接口
	 * 提供用户在游戏内消耗平台一级货币或等值物品的汇报接口,包括直冲,IOS直冲,平台币兑换以及奖励
	 * @param userId	用户ID（userid）
	 * @param roleid	用户在游戏中的角色编号(roleid)
	 * @param ip		用户兑换游戏币时的客户端IP地址。eg：202.104.1.1
	 * @param orderid	订单号， 秒时间戳+6位随机串，例如：1270605064123456
	 * @param gamebean	获得一级游戏币数量
	 * @param chargetype	兑换类型(expend，transfer，iosexpend，largess)，只能选四种之一，全小写。直冲 expend , 平台币兑换 transfer , ios直冲 iosexpend , 额外奖励 largess
	 * @param currency	币种(全大写)，常用如下所示 ： BEAN 平台币 ， CNY 人民币 ， USD 美元 ， KRW 韩元， THB 泰元
	 * @param mount		数量(指货币的数量)
	 * @param currettime	游戏服系统时间，时间格式为YYYYMMDDHHmmss,eg:20120506170824(表示2012年5月6日17时8分24秒) 。注：该时间传的是游戏服当地时间，用于解决时区问题。
	 * @param optionalParams 可选参数
	 * 用法：创建一个Map，根据如下的可选参数，传入该方法。
	 * 举例：Map<String,String> optionalParams = new HashMap<String,String>();
	 *      optionalParams.put("itemid","999999");
	 *      optionalParams.put("itemname","套餐123");
	 *      handler.transferReport(原有必选参数,optionalParams);
	 * 以下可选参数文档仅供参考，不一定为最新，最新文档请参考wiki http://open.rrgdev.com/wiki/u.transferreport.php
	 * [addtioninfo]  varchar(127)  JSON格式扩展信息，如果确实没有扩展信息，可以不传递该参数  
     * [itemid]  varchar(63)  套餐id，如果确实没有套餐id，可以不传递该参数  
     * [itemname]  varchar(63)  套餐名，如果确实没有套餐名，可以不传递该参数  
     * [username]  varchar(63)  玩家平台用户名  
     * [rolename]  varchar(63)  玩家游戏内角色名  
     * [device]  varchar(63)  终端设备分类，全小写。 
     *   枚举为：pc，ios，android。
     * [devicetype]  varchar(63)  设备型号，例如：ipad/iphone/htc，全小写。 
     *      1、ios：通过[[UIDevice currentDevice] model]获取
     *      2、android：通过Build的Model来获取
     *      3、pc类型此项设置为-1
     * [deviceversion]  varchar(63)  操作系统版本，全小写。 
     *      1、ios：通过[[UIDevice currentDevice] systemVersion]获取
     *      2、android：通过Build的Release来获取
     *      3、pc类型此项设置为-1
     * [deviceguid]  varchar(63)  设备唯一识别id，md5( )，32位小写。 
     *      1、ios设备获取方法：md5(Mac)
     *      2、android设备获取方法：md5(serialno_deviceid_macaddress)
     *         其中各参数说明
     *          a).serialno  序列号，android2.2版本以后可以通过从android.os.SystemProperties获取ro.serialno
     *          b).deviceid  通过TelephonyManager的getDeviceId()来获取
     *          c). macaddress 无线网卡地址，通过WifiManager 的getMacAddress()来获取
     *      3、pc类型此项设置为-1
     * [channel]  varchar(64)  渠道标志  
     * [subchannel]  varchar(64)  子渠道标志  
     * [thirdpayid]  varchar(128)  第三方单号  
     * @return			
	 * 			成功：result	 如果值为success表示汇报成功，其他表示汇报失败
	 * 			失败：{"error_code":1}
	 */
	public TransferReportResponse transferReport(long userId,String roleid,String ip,String orderid,BigDecimal gamebean,enum_chargetype chargetype,	enum_currency currency,	BigDecimal mount,long currenttime,Map<String,String> optionalParams);

	/**
	 * 游戏内消耗汇报接口
	 * 提供用户在游戏内消耗平台一级货币或等值物品的汇报接口,包括直冲,IOS直冲,平台币兑换以及奖励
	 * @param param
	 * @return 
	 * 		成功：result	 如果值为success表示汇报成功，其他表示汇报失败
	 * 		失败：{"error_code":1}
	 */
	public TransferReportResponse transferReport(TransferReportParam param);
	
	/**
	 * 查询所有玩家的充值信息
	 * @return
	 * 请求返回值参数名称  类型  描述  
		ret  int  返回码。只有当ret=0时，表示接口请求正确，更详细的返回码说明请点击ret返回码说明  
		recharge  二维JSON数组  返回的直冲信息列表。最多返回1000条直冲信息。 
		如果需要获取更多的直冲信息，请先调用兑换玩家充值信息接口消耗掉本次查询的直冲信息后,再次进行查询获取更多信息。
		 
		id  string  唯一ID 
		本参数用于在兑换玩家充值信息接口中指定具体需要消耗的订单号,即使用pids字段指定具体需要消耗的订单号
		 
		user_id  string  用户Id 
		用户Id:指人人平台(也包括其他通用平台)中用户唯一标识，为平台用户的唯一标识,其他用户名,昵称均是可以修改的,绝对不能作为主键或者唯一索引
		 
		user_name  string  用户名  
		order_id  string  订单流水号  
		amount  string  金额 
		 eg:充值了1.99美元,在游戏内添加了17.3游戏币
		 则game_points=17.3,currency=USD,amount=1.99
		 
		currency  string  币种 
		 eg:充值了1.99美元,在游戏内添加了17.3游戏币
		 则game_points=17.3,currency=USD,amount=1.99
		 
		item_id  string  套餐ID 
		 web、android直冲中，套餐ID由运营添加web和android套餐表时提供
		 ios直冲中，套餐ID由生成玩家IOS充值信息接口中item_table对应的套餐信息提供（即对应套餐的id字段）
		 
		game_points  string  游戏币 
		 eg:充值了1.99美元,在游戏内添加了17.3游戏币
		 则game_points=17.3,currency=USD,amount=1.99
		 
		type  string  兑换类型(expend，ios) 
		直冲 expend 
		ios直冲 ios  
		udid  string  苹果终端号  
		device_id  string  MAC信息  
		game_code  string  游戏唯一code  
		game_domain  string  游戏唯一域名  
		game_server_domain  string  游戏服唯一域名  
		char_id  string  角色ID  
		char_name  string  角色名  
		add_time  string  添加时间 
		该订单充值完成的时间
		 
		expend_time  string  消费时间 
		该订单被玩家领取的时间
		 
		delay_time  string  延迟获取时间 
		该订单被玩家延迟领取的时间(例如部分订单由于延迟8小时付账,该时间会大于当前时间8小时)
		 
		terminal  string  终端类型  
		remark  string  备注信息  
		备注  recharge是一个二维数组，可能会有多条充值信息  

	 */
	public QueryAllRechargeResponse queryAllRecharge();
	
	/**
	 * 渠道用户注册登陆接口
	 * @param ip 表示用户登录游戏时的客户端IP地址。 eg：202.104.1.1 
	 * @param channelCode 渠道编号,目前只支持3个平台,分别如下所示 
	 *     渠道编号   渠道名称  
			 2024    91  
			 2025    dena  
			 2026           小米  
	 * @param channelUserId 渠道用户ID 
			必须是渠道平台的唯一用户标识,同一个渠道用户有且仅有一个渠道用户ID 
			本接口注册的人人账号通过channeluserid和channelcode对应渠道平台的用户ID,如果渠道平台channeluserid变更将重新注册新人人账号 
			例如:某玩家第一次通过channelcode=2024和channeluserid=uid_123456调用本接口,返回人人用户ID为12345678,
			第二次再通过channelcode=2024和channeluserid=uid_123456调用本接口,依旧返回人人用户ID为12345678,
			但是如果渠道玩家channeluserid发生变更,例如变成uid_654321调用本接口,则将重新注册人人用户ID可能为78641389(一定不为12345678)
	 * @return userid  string  玩家账号ID  
				username  string  玩家用户名  
				wallow  string  玩家是否防沉迷(Y是防沉迷，N不是防沉迷)  
				infofull  string  玩家资料是否完整(Y资料完整，N资料不完整)  
				cookie  string  玩家登录cookie  
	 */
	public ChannelUserLoginResponse channelUserLogin(String ip,String channelCode,String channelUserId);
	
	/**
	 * 渠道用户注册登陆接口
	 * @param ip 表示用户登录游戏时的客户端IP地址。 eg：202.104.1.1 
	 * @param channelCode 渠道编号,目前只支持3个平台,分别如下所示 
	 *     渠道编号   渠道名称  
			 2024    91  
			 2025    dena  
			 2026           小米  
	 * @param channelUserId 渠道用户ID 
			必须是渠道平台的唯一用户标识,同一个渠道用户有且仅有一个渠道用户ID 
			本接口注册的人人账号通过channeluserid和channelcode对应渠道平台的用户ID,如果渠道平台channeluserid变更将重新注册新人人账号 
			例如:某玩家第一次通过channelcode=2024和channeluserid=uid_123456调用本接口,返回人人用户ID为12345678,
			第二次再通过channelcode=2024和channeluserid=uid_123456调用本接口,依旧返回人人用户ID为12345678,
			但是如果渠道玩家channeluserid发生变更,例如变成uid_654321调用本接口,则将重新注册人人用户ID可能为78641389(一定不为12345678)
	 * @param promotionCode 推广码，即F值，可选 
	 * @return userid  string  玩家账号ID  
				username  string  玩家用户名  
				wallow  string  玩家是否防沉迷(Y是防沉迷，N不是防沉迷)  
				infofull  string  玩家资料是否完整(Y资料完整，N资料不完整)  
				cookie  string  玩家登录cookie  

	 */
	public ChannelUserLoginResponse channelUserLogin(String ip,String channelCode,String channelUserId,String promotionCode);
	
	/**
	 * 渠道用户注册登陆接口
	 * @param ip 表示用户登录游戏时的客户端IP地址。 eg：202.104.1.1 
	 * @param channelCode 渠道编号,目前只支持3个平台,分别如下所示 
	 *     渠道编号   渠道名称  
			 2024    91  
			 2025    dena  
			 2026           小米  
	 * @param channelUserId 渠道用户ID 
			必须是渠道平台的唯一用户标识,同一个渠道用户有且仅有一个渠道用户ID 
			本接口注册的人人账号通过channeluserid和channelcode对应渠道平台的用户ID,如果渠道平台channeluserid变更将重新注册新人人账号 
			例如:某玩家第一次通过channelcode=2024和channeluserid=uid_123456调用本接口,返回人人用户ID为12345678,
			第二次再通过channelcode=2024和channeluserid=uid_123456调用本接口,依旧返回人人用户ID为12345678,
			但是如果渠道玩家channeluserid发生变更,例如变成uid_654321调用本接口,则将重新注册人人用户ID可能为78641389(一定不为12345678)
	 * @param promotionCode 推广码，即F值，可选 
	 * @param bean		数据组汇报Bean
	 * @return userid  string  玩家账号ID  
				username  string  玩家用户名  
				wallow  string  玩家是否防沉迷(Y是防沉迷，N不是防沉迷)  
				infofull  string  玩家资料是否完整(Y资料完整，N资料不完整)  
				cookie  string  玩家登录cookie  

	 */
	public ChannelUserLoginResponse channelUserLogin(String ip,String channelCode,String channelUserId,String promotionCode,ReportForDGBean bean);
	
	/**
	 * 生成人人一卡通充值订单
	 * 功能说明
     *    人人一卡通充值渠道接口用于提供人人一卡通充值渠道订单生成的功能 
     *    提供游戏内直接使用人人一卡通账号密码生成充值订单的功能，然后通过
     *      人人渠道直冲状态查询接口进行查询，查询成功后通过(直充接口)查询玩
     *      家充值信息和(直充接口)兑换玩家充值信息继续获取。 
	 * @param userid 平台返回的用户唯一标识，目前为长整型数字。特定场景又叫passportid，passport_id，userid，user_id
	 * @param cardId 人人一卡通卡号 
	 * @param cardPwd 人人一卡通密码 
	 * @param gameOrderId 订单号， 秒时间戳+6位随机串，例如：1270605064123456。 
	 * @param userName 玩家姓名
	 * @param roleid 角色ID 
	 * @param charName 角色姓名
	 * @param deviceType 设备型号，全小写 eg:ipad/iphone/htc/-1。(注：pc类型此项设置为-1) 
	 * @param deviceVersion 操作系统版本，全小写 eg:4.0.1/5.1.1/-1。(注:pc类型此项设置为-1) 
	 * @param ip 表示用户登录游戏时的客户端IP地址。 eg：202.104.1.1 
	 * @param macInfo 终端mac地址MD5后的结果 
	 * @param udid 设备号，如果获取不到的就用和macInfo参数一样的值 
	 * @return PayChannelRRCardRespose:
	 *            boolean success : 接口调用正确时为true,接口调用失败为false
	 *            int errorCode : 错误码
	 *            String errorMsg : 错误信息
	 */
	public PayChannelRRCardRespose payChannelRRCard(long userid,String cardId,String cardPwd,String gameOrderId,
			String userName,String roleid,String charName,String deviceType,String deviceVersion,
			String ip,String macInfo,String udid,String terminal);
	
	/**
	 * 生成手机卡充值订单
	 * 功能说明
     *    人人手机卡充值渠道接口用于提供人人手机充值卡渠道订单生成的功能 
     *    提供游戏内直接使用人人手机充值卡账号密码生成充值订单的功能，然
     *      后通过人人渠道直冲状态查询接口进行查询，查询成功后通过(直充接口)
     *      查询玩家充值信息和(直充接口)兑换玩家充值信息继续获取。 
	 * @param userid 平台返回的用户唯一标识，目前为长整型数字。特定场景又叫passportid，passport_id，userid，user_id
	 * @param cardId 手机充值卡卡号
	 * @param cardPwd 手机充值卡密码 
	 * @param cardType 手机充值卡类型 1-联通 3-电信 0-移动
	 * @param amount 人人手机卡金额 
	 * @param gameOrderId 订单号， 秒时间戳+6位随机串，例如：1270605064123456。 
	 * @param userName 玩家姓名
	 * @param roleid 角色ID
	 * @param charName 角色姓名 
	 * @param deviceType 设备型号，全小写 eg:ipad/iphone/htc/-1。(注：pc类型此项设置为-1) 
	 * @param deviceVersion 操作系统版本，全小写 eg:4.0.1/5.1.1/-1。(注:pc类型此项设置为-1) 
	 * @param ip 表示用户登录游戏时的客户端IP地址。eg：202.104.1.1
	 * @param macInfo 终端mac地址MD5后的结果
	 * @param udid 设备号，如果获取不到的就用和macInfo参数一样的值 
	 * @return PayChannelMobileCardResponse
	 *            boolean success : 接口调用正确时为true,接口调用失败为false
	 *            int errorCode : 错误码
	 *            String errorMsg : 错误信息
	 */
	public PayChannelMobileCardResponse payChannelMobileCard(long userid,String cardId,String cardPwd,String cardType,
			long amount,String gameOrderId,String userName,String roleid,String charName,
			String deviceType,String deviceVersion,String ip,String macInfo,String udid,String terminal);
	
	/**
	 * 人人渠道直冲状态查询
	 * 功能说明
	 * 人人渠道直冲状态查询接口用于提供人人渠道直冲状态查询的功能
	 *      (目前仅能提供生成手机卡充值订单和生成人人一卡通充值订单的订单查询) 
     * 使用生成手机卡充值订单和生成人人一卡通充值订单充值后，然后通过本接口进行
     *       查询，查询成功后通过(直充接口)查询玩家充值信息和(直充接口)兑换玩家充值信息继续获取。
	 * @param userid 平台返回的用户唯一标识，目前为长整型数字。特定场景又叫passportid，passport_id，userid，user_id 
	 * @param ip 表示用户登录游戏时的客户端IP地址 eg：202.104.1.1
	 * @param gameOrderId 订单号， 详见人人手机卡充值渠道和人人一卡通充值渠道接口中的同名字段 
	 * @return PayChannelQueryStatusResponse
	 *            boolean success : 接口调用正确时为true,接口调用失败为false
	 *            int errorCode : 错误码
	 *            String errorMsg : 错误信息
	 */
	public PayChannelQueryStatusResponse payChannelQueryStatus(long userid,String ip,String gameOrderId);
	
	/**
	 * 生成mycard充值订单
	 * 功能说明 
	 * mycard充值卡渠道接口用于提供mycard充值卡渠道订单生成的功能
	 *    提供游戏内直接使用mycard充值卡账号密码生成充值订单的功能，
	 *    然后通过人人渠道直冲状态查询接口进行查询，查询成功后通过(直充接口)
	 *    查询玩家充值信息和(直充接口)兑换玩家充值信息继续获取。
	 * @param userid 平台返回的用户唯一标识，目前为长整型数字。特定场景又叫passportid，passport_id，userid，user_id
	 * @param cardId 手机充值卡卡号
	 * @param cardPwd 手机充值卡密码
	 * @param gameOrderId 订单号， 秒时间戳+6位随机串，例如：1270605064123456。
	 * @param userName 玩家姓名
	 * @param roleid 角色ID
	 * @param charName 角色姓名
	 * @param deviceType 设备型号，全小写 eg:ipad/iphone/htc/-1。(注：pc类型此项设置为-1)
	 * @param deviceVersion 操作系统版本，全小写 eg:4.0.1/5.1.1/-1。(注:pc类型此项设置为-1)
	 * @param ip 表示用户登录游戏时的客户端IP地址。eg：202.104.1.1
	 * @param macInfo 终端mac地址MD5后的结果
	 * @param udid 设备号，如果获取不到的就用和macInfo参数一样的值
	 * @param terminal 玩家充值终端类型
					终端类型	 说明
					pc	 电脑
					ios	 苹果
					android	 安卓
					other	 其他
	 * @return
	 */
	public PayChannelMycardResponse payChannelMyCard(long userid,String cardId,String cardPwd,String gameOrderId,
			String userName,String roleid,String charName,String deviceType,String deviceVersion,
			String ip,String macInfo,String udid,String terminal);
	
	/**
	 * 生成充值订单号接口[编辑] 功能说明生成充值订单号接口用于提供统一的平台充值订单编号功能 
	 * 该接口可以生成平台唯一的充值订单号供游戏使用 
	 * @param userid 平台返回的用户唯一标识，目前为长整型数字。特定场景又叫passportid，passport_id，userid，user_id 
	 * @param userName 玩家姓名
	 * @param roleid 角色ID
	 * @param charName 角色姓名
	 * @param deviceType 设备型号，全小写  eg:ipad/iphone/htc/-1。(注：pc类型此项设置为-1) 
	 * @param deviceVersion 操作系统版本，全小写  eg:4.0.1/5.1.1/-1。(注:pc类型此项设置为-1) 
	 * @param ip 表示用户登录游戏时的客户端IP地址。 eg：202.104.1.1 
	 * @param macInfo 终端mac地址MD5后的结果 
	 * @param udid 设备号，如果获取不到的就用和macInfo参数一样的值 
	 * @param terminal 玩家充值终端类型 终端类型  说明  
                        pc  电脑  
                        ios  苹果  
                        android  安卓  
                        other  其他  
	 * @return
	 */
	public GenerateOrderResponse generateOrder(long userid,String userName,String roleid,String charName,String deviceType,String deviceVersion,String ip,String macInfo,String udid,String terminal);
	
	/**
	 * 生成充值订单号接口[编辑] 功能说明生成充值订单号接口用于提供统一的平台充值订单编号功能 
	 * 该接口可以生成平台唯一的充值订单号供游戏使用 
	 * @param userid 平台返回的用户唯一标识，目前为长整型数字。特定场景又叫passportid，passport_id，userid，user_id 
	 * @param userName 玩家姓名
	 * @param roleid 角色ID
	 * @param charName 角色姓名
	 * @param deviceType 设备型号，全小写  eg:ipad/iphone/htc/-1。(注：pc类型此项设置为-1) 
	 * @param deviceVersion 操作系统版本，全小写  eg:4.0.1/5.1.1/-1。(注:pc类型此项设置为-1) 
	 * @param ip 表示用户登录游戏时的客户端IP地址。 eg：202.104.1.1 
	 * @param macInfo 终端mac地址MD5后的结果 
	 * @param udid 设备号，如果获取不到的就用和macInfo参数一样的值 
	 * @param terminal 玩家充值终端类型 终端类型  说明  
                        pc  电脑  
                        ios  苹果  
                        android  安卓  
                        other  其他  
     * @param channelcode  varchar(63)  特定渠道需要传递(目前是2040 2042 2045三个渠道),参见这里  
	 * @param channelext   varchar(255)  json格式,特定渠道需要传递(目前是2042 2045两个渠道)的额外参数,参见这里  
     * @param orderId 订单号
	 * @return
	 */
	public GenerateOrderResponse generateOrder(long userid,String userName,String roleid,String charName,String deviceType,String deviceVersion,String ip,String macInfo,String udid,String terminal,String channelCode,String channelExt);
	
	
	/**
	 * 发送短信激活码
	 * 功能说明
	 *   发送短信激活码用于提供向玩家手机内发送短信验证码的功能
	 *   提供游戏内直接向玩家手机内发送短信激活码的功能，然后通过验证短信激活码进行验证
	 *   本接口每个手机号每分钟最多发送一条短信(如果重复请求将提示已发送)
	 *   每个验证码的有效时间为半个小时(如果重复发送,将以最后一次发送的时间为计算起点)
	 * @param userid 平台返回的用户唯一标识，目前为长整型数字。特定场景又叫passportid，passport_id，userid，user_id
	 * @param cookie 用户cookie值
	 * @param mobile 只支持11位纯数字手机号(eg:18612345678)
	 *               注:以下均不合法
	 *                186 1234 5678 、 010-1234-4567 、 186-1234-5678 
	 *                010-18612345678 、 018612345678
	 * @param ip 表示用户登录游戏时的客户端IP地址。eg：202.104.1.1
	 * @return CaptchaSendResponse
	 */
	public CaptchaSendResponse captchaSend(long userid,String cookie,String mobile,String ip);
	
	/**
	 * 验证短信激活码
	 * 功能说明验证短信激活码用于验证向玩家手机内发送的短信验证码的功能 
	 * 提供游戏内直接验证玩家手机内发送短信激活码的功能，需要先通过发送短信激活码给玩家发送验证码 
	 * 每个手机号每分钟最多发送一条短信(如果重复请求将提示已发送) 
	 * 每个验证码的有效时间为半个小时(如果重复发送,将以最后一次发送的时间为计算起点) 
	 * @param userid 平台返回的用户唯一标识，目前为长整型数字。
	 * @param cookie 用户cookie值
	 * @param mobile 只支持11位纯数字手机号(eg:18612345678) 注:以下均不合法
     *             186 1234 5678 、 010-1234-4567 、 186-1234-5678 
     *             010-18612345678 、 018612345678 
	 * @param captchaCode 手机短信验证码 
	 * @param ip 表示用户登录游戏时的客户端IP地址。 eg：202.104.1.1 
	 * @return
	 */
	public CaptchaCheckResponse captchaCheck(long userid,String cookie,String mobile,String captchaCode,String ip);
	
	
	public void getSurvey(long userId,Map<String,String> conditionMap,ICallback callback);
	
}
