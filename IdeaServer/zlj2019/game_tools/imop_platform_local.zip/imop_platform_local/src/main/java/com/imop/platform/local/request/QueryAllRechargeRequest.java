package com.imop.platform.local.request;

import com.imop.platform.local.config.IConfig;
import com.imop.platform.local.response.IResponse;
import com.imop.platform.local.response.QueryAllRechargeResponse;

public class QueryAllRechargeRequest extends AbstractRequest {

	public QueryAllRechargeRequest(IConfig config) {
		super(config);
	}

	@Override
	public IResponse getResponse(String[] args) {
		return new QueryAllRechargeResponse(args);
	}

	@Override
	public void setParams(Object... objects) {

	}

}
