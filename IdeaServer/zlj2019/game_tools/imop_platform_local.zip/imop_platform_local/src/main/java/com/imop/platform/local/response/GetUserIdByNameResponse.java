package com.imop.platform.local.response;

/**
 * 通过用户名称获取用户id的请求结果
 * @author lu.liu
 *
 */
public class GetUserIdByNameResponse extends AbstractResponse {
	
	/**
	 * 账号ID，默认为-1
	 */
	private long userId = -1;
	
	public GetUserIdByNameResponse(String[] args){
		super(args, 2);
	}

	@Override
	public void onSuccess(String[] args) {
		userId = Long.valueOf(args[1]);
	}
	
	/**
	 * 获取账号ID
	 * @return
	 */
	public long getUserId() {
		return userId;
	}
}
