package com.imop.platform.local.response;

public class GetUserBirthdayResponse extends AbstractResponse {

	/**
	 * 玩家用户ID，默认值为 -1
	 */
	private long userId = -1;
	
	/**
	 * 玩家用户生日，默认值为空，格式：1987-01-01
	 */
	private String birthday = "";
	
	/**
	 * 获取玩家用户ID
	 * @return 玩家用户ID
	 */
	public long getUserId() {
		return userId;
	}
	/**
	 * 获取玩家用户的生日
	 * @return 玩家用户生日
	 */
	public String getBirthday() {
		return birthday;
	}

	public GetUserBirthdayResponse(String[] args) {
		super(args, 3);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void onSuccess(String[] args) {
		
		userId = Long.valueOf(args[1]);
		birthday = args[2];
		

	}

}
