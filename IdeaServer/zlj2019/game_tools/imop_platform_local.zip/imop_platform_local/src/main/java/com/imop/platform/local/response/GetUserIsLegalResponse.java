package com.imop.platform.local.response;


/**
 * 检测用户是否合法的请求结果
 * @author lu.liu
 *
 */
public class GetUserIsLegalResponse extends AbstractResponse {
	
	/**
	 * 账号ID，默认为-1
	 */
	private long userId = -1;
	
	/**
	 * 帐号名，默认为null
	 */
	private String userName = null;
	
	/**
	 * 检测用户是否合法的预留字段，默认为-1
	 */
	private int reserve = -1;
	
	public GetUserIsLegalResponse(String[] args){
		super(args,4);
	}

	@Override
	public void onSuccess(String[] args) {
		userId = Long.valueOf(args[1]);
		userName = args[2];
		reserve = Integer.valueOf(args[3]);
	}

	/**
	 * 获取账号ID
	 * @return	账号ID
	 */
	public long getUserId(){
		return userId;
	}
	
	/**
	 * 获取帐号名
	 * @return	帐号名
	 */
	public String getUserName(){
		return userName;
	}
	
	/**
	 * 获取备用值
	 * @return	备用值
	 */
	public int getReserve(){
		return reserve;
	}
}
