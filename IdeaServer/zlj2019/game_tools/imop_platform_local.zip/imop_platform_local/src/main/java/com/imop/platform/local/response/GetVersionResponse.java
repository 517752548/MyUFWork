package com.imop.platform.local.response;

/**
 * 平台版本号的请求结果
 * @author lu.liu
 *
 */
public class GetVersionResponse extends AbstractResponse {

	/**
	 * 平台版本号，默认为null
	 */
	private String version = null;
	
	/**
	 * 平台版本发布日期，默认为Null
	 */
	private String date = null;
	
	public GetVersionResponse(String[] args) {
		super(args, 3);
	}

	@Override
	public void onSuccess(String[] args) {
		version = args[1];
		if(args.length == 3){
			date = args[2];
		}
	}

	/**
	 * 获取平台版本号
	 * @return	版本号
	 */
	public String getVersion(){
		return version;
	}
	
	/**
	 * 获取版本日期
	 * @return	版本日期
	 */
	public String getDate(){
		return date;
	}
}
