package com.imop.platform.local.request;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.UUID;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;

import net.sf.json.JSONObject;

import org.apache.commons.codec.digest.DigestUtils;

import com.imop.platform.local.callback.ICallback;
import com.imop.platform.local.config.IConfig;
import com.imop.platform.local.response.IResponse;
import com.imop.platform.local.util.HttpUtil;

/**
 * 抽象的请求类，封装了请求和汇报接口的基本操作
 * @author lu.liu
 *
 */
public abstract class AbstractRequest implements IRequest {
	
	protected String domain;
	protected String page;
	protected String url;
	protected IConfig config;
	protected long beginTime;
	protected long endTime;
	
	/**
	 * 通过配置类初始化
	 * @param config
	 */
	public AbstractRequest(IConfig config) {
		this.config = config;
		this.domain = config.getRequestDomain();
	}
	
	/* (non-Javadoc)
	 * @see com.imop.platform.request.IRequest#getSign(java.lang.Object[])
	 */
	@Override
	public String getSign(Object...objects){
		String sign = null;
		StringBuilder builder = new StringBuilder();
		for(Object obj : objects){
			builder.append(obj);
		}
		builder.append(config.getGameKey());
		
		try {
			sign = DigestUtils.md5Hex(builder.toString().getBytes("UTF-8"));
		} catch (UnsupportedEncodingException e) {
			config.getRecord().recordError("#LOCAL.PLATFORM.SIGN.ERROR:", e);
		}
		
		return sign;
	}
	
	/* (non-Javadoc)
	 * @see com.imop.platform.request.IRequest#getSign(java.lang.Object[])
	 */
	@Override
	public String createSign(TreeSet<String> param_set){
		String sign = null;
		StringBuilder builder = new StringBuilder();
		for(String value: param_set){
			builder.append(value);
		}
		builder.append(config.getGameKey());
		
		try {
			sign = DigestUtils.md5Hex(builder.toString().getBytes("UTF-8"));
		} catch (UnsupportedEncodingException e) {
			config.getRecord().recordError("#LOCAL.PLATFORM.SIGN.ERROR:", e);
		}
		
		return sign;
	}
	
	/* (non-Javadoc)
	 * @see com.imop.platform.request.IRequest#generateUrl(java.lang.Object[])
	 */
	@Override
	public void generateUrl(Object...objects){
		
		int length = objects.length;
		
		for(int index=0; index<length; index++){
			objects[index] = encodeUrl(objects[index].toString());
		}
		
		this.url = String.format(domain + page, objects);
		String currenttime = this.getDateTime();
		String gamecode = config.getGamecode();
		String platformid = config.getPlatformid();
		String domain = config.getDomain();
		
		this.url += "&currenttime="+currenttime +
				"&gamecode="+gamecode +
				"&platformid="+platformid +
				"&domain="+domain;
	}
	
	@Override
	public void getUrl(Object...objects){
		
		try {
			String currenttime = this.getDateTime();
			String gamecode = config.getGamecode();
			String platformid = config.getPlatformid();
			String domain = config.getDomain();
			String requestDomain = config.getRequestDomain();
			
			int length = objects.length;
			
//			String[] param = String.format(requestDomain + page, objects).split("\\?")[1].split("&");
//			TreeSet<String> param_set = new TreeSet<String>();
//			for(int i=0;i<param.length;i++){
//				param_set.add(param[i]);
//			}
			
			Object [] objects_new = new Object[length];
			for(int i=0;i<length;i++) {
				objects_new[i] = URLEncoder.encode(""+objects[i], "UTF-8");
			}
			String[] param = String.format(requestDomain + page, objects_new).split("\\?")[1].split("&");
			TreeSet<String> param_set = new TreeSet<String>();
			for(int i=0;i<param.length;i++){
				String [] kv = param[i].split("\\=");
				String ppp = "";
				if(kv.length==1) {
					ppp = kv[0]+"=";
				} else {
					ppp = kv[0]+"="+URLDecoder.decode(kv[1], "UTF-8");
				}
				
				param_set.add(ppp);
			}
			param_set.add("currenttime="+currenttime);
			param_set.add("gamecode="+gamecode);
			param_set.add("platformid="+platformid);
			param_set.add("domain="+domain);
			String sign = this.createSign(param_set);
			
			for(int index=0; index<length; index++){
				objects[index] = encodeUrl(objects[index].toString());
			}
			this.url = String.format(requestDomain + page, objects)+"&sig="+sign;
			this.url += "&currenttime="+currenttime +
					"&gamecode="+gamecode +
					"&platformid="+platformid +
					"&domain="+domain;
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/* (non-Javadoc)
	 * @see com.imop.platform.request.IRequest#send()
	 */
	@Override
	public IResponse send() {
		try {
			return doRequest(false,false);
		} catch (Exception e) {
			config.getRecord().recordError("#LOCAL.PLATFORM.REQUEST.ERROR:" + url, e);
			return getFailResponse();
		}
	}
	
	@Override
	public IResponse send(boolean responseJson) {
		try {
			return doRequest(false,responseJson);
		} catch (Exception e) {
			config.getRecord().recordError("#LOCAL.PLATFORM.REQUEST.ERROR:" + url, e);
			return getFailResponse();
		}
	}
	
	@Override
	public IResponse sendByPost(boolean statu) {
		try {
			return doRequest(true,statu);
		} catch (Exception e) {
			config.getRecord().recordError("#LOCAL.PLATFORM.REQUEST.ERROR:" + url, e);
			return getFailResponse();
		}
	}

	/* (non-Javadoc)
	 * @see com.imop.platform.request.IRequest#asyncSend(com.imop.platform.callback.ICallback)
	 */
	@Override
	public Future<IResponse> asyncSend(final ICallback callback) {
		ExecutorService service = config.getReportService();
		return service.submit(new Callable<IResponse>(){

			@Override
			public IResponse call() throws Exception {
				
				IResponse response = doRequest(false,false);
					
					if(null != callback){
						if(response.isSuccess()){
							callback.onSuccess(response);
						}else{
							callback.onFail(response);
						}
					}
					return response;
			}
			
		});
	}
	
	@Override
	public Future<IResponse> asyncSend(final boolean responseJson,final ICallback callback) {
		ExecutorService service = config.getReportService();
		return service.submit(new Callable<IResponse>(){

			@Override
			public IResponse call() throws Exception {
				
				IResponse response = doRequest(false,responseJson);
					
					if(null != callback){
						if(response.isSuccess()){
							callback.onSuccess(response);
						}else{
							callback.onFail(response);
						}
					}
					return response;
			}
			
		});
	}

	protected String[] getParamters(String result,boolean statu){
		return null;
	}
	
	protected String[] getParamters(String result) {
		
		if(null == result){
			return null;
		}
		
		String[] args = result.split(IConfig.RESULT_SPLIT);
		
		if(null == args || args.length < IConfig.RESULT_LENGTH_MIN){
			return null;
		}
		
		return args;
		
	}
	protected IResponse doRequest(boolean POST){
		return doRequest(POST,false);
	}
	/**
	 * 发送HTTP请求
	 * @return
	 */
	protected IResponse doRequest(boolean POST,boolean responseJson){
		IResponse response = null;
		long time = 0;
		try {			
			String uuid = UUID.randomUUID().toString();
			
			recordUrl(uuid, url);
			
			beginTime = System.currentTimeMillis();
			
			String result = HttpUtil.getUrl(url, config.getTimeout(),POST);
			
			endTime = System.currentTimeMillis();
			
			time = endTime - beginTime;
			
			config.getRecord().recordInfo(uuid + "\t" + result + "\tTime:" + time + "ms");
			String[] params=null;
			
			String trimResult = result.trim();
			if(!responseJson){
				params = getParamters(trimResult);
			} else {
				if(trimResult.startsWith("fail:")) {
					params = getParamters(trimResult);
				} else {
					JSONObject jsonResult = JSONObject.fromObject(trimResult);
					if(jsonResult.has("ret")) {
						int ret = jsonResult.getInt("ret");
						if(ret==0) {
							params = new String[]{"ok",trimResult};
						} else {
							if(jsonResult.has("error_msg")) {
								params = new String[]{"fail",""+ret,jsonResult.getString("error_msg")};
							} else {
								params = new String[]{"fail",""+ret};
							}
						}
					} else {
						if(jsonResult.has("error_code")) {
							if(jsonResult.has("error_msg")) {
								params = new String[]{"fail",jsonResult.get("error_code").toString(),jsonResult.getString("error_msg")};
							} else {
								params = new String[]{"fail",jsonResult.get("error_code").toString()};
							}
							
						} else {
							params = new String[]{"ok",trimResult};
						}
					}
				}
			}
			if(null != params){
				response = getResponse(params);
			}else{
				response = getFailResponse();
			}
			
			if(response.isSuccess()){
				response.onSuccess(params);
			}
			
			if(null != response){
				response.setUseTime(time);
			}			
		} catch (Exception e) {
			config.getRecord().recordError("#PLATFORM.LOCAL.REQUEST.ERROR:", e);
			response = getFailResponse();
			
			if(null != response){
				response.setUseTime(time);
			}
		}
		
		return response;
	}
	
	protected void recordUrl(String uuid, String url){
		config.getRecord().recordInfo(uuid + "\t" + url);
	}
	
	@Override
	public abstract IResponse getResponse(String[] args);

	protected IResponse getFailResponse(){
		return getResponse(new String[]{"fail","-1"});
	}
	
	protected IResponse getFailResponse(int failCode){
		return getResponse(new String[]{"fail",failCode+""});
	}
	
	@Override
	public abstract void setParams(Object...objects);
	
	protected long getTimestamp(){
		return System.currentTimeMillis()/1000;
	}
	
	protected String getDateTime(){
		return new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
	}
	
	/**
	 * 对字符串做URL编码
	 * @param str	待编码字符串
	 * @return		编码后字符串
	 */
	protected String encodeUrl(String str){
		try {			
			return URLEncoder.encode(str, IConfig.URL_ENCODE);			
		} catch (Exception e) {
			config.getRecord().recordError("#IMOP.LOCALHANDLER.ERROR:" + str, e);
			return str;
		}
	}
	
	public void genOptinalURL(String page,Map<String,Object> params) {
		//增加公共参数
		params.put("areaid",config.getAreaId());
		params.put("serverid", config.getServerId());
		params.put("domain", config.getDomain());
		params.put("gamecode", config.getGamecode());
		params.put("platformid", config.getPlatformid());
		params.put("timestamp", getTimestamp());
		params.put("currenttime", getDateTime());
		
		String sig = getSig(params);
		StringBuilder sb = new StringBuilder(2048);
		sb.append(config.getReportDomain()+page+"?");
		
		Set<String> keySet = params.keySet();
		for(String key:keySet) {
			sb.append(key+"="+encodeUrl(""+params.get(key))+"&");
		}
		sb.append("sig="+sig);
		url = sb.toString();
	}
	
	protected String getSig(Map<String,Object> params) {
		
		StringBuilder sb = new StringBuilder(2048);
		TreeSet<String> sortedKeySet = new TreeSet<String>();
		Set<String> keySet = params.keySet();
		for(String key:keySet) {
			sortedKeySet.add(key);
		}
		for(String key:sortedKeySet) {
			sb.append(key+"="+encodeUrl(""+params.get(key)).replace("*", "%2A"));
			//sb.append(key+"="+params.get(key));
		}
		sb.append(config.getGameKey());
		String sig = null;
		try {
			sig = DigestUtils.md5Hex(sb.toString().getBytes("UTF-8"));
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
		return sig;
	}
	
}
