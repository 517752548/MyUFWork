package com.imop.platform.local.response;

/**
 * 通过人人用户id获取昵称的请求结果
 * @author lu.liu
 *
 */
public class GetNickNameResponse extends AbstractResponse {

	/**
	 * 玩家昵称，默认为null
	 */
	private String nickName = null;
	
	public GetNickNameResponse(String[] args){
		super(args, 2);
	}
	
	@Override
	public void onSuccess(String[] args) {
		nickName = args[1];
	}
	
	/**
	 * 获取玩家昵称
	 * @return	玩家昵称
	 */
	public String getNickName() {
		return nickName;
	}
}
