package com.imop.platform.local.response;

public class GetNGWordResponse extends AbstractResponse {

	public GetNGWordResponse(String[] args) {
		super(args, 2);
	}

	private int right; 
	public int getRight() {
		return right;
	}

	@Override
	public void onSuccess(String[] args) {
		right = Integer.parseInt(args[1]);
	}

}
