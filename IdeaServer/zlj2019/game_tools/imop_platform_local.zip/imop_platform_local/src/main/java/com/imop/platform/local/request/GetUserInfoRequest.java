package com.imop.platform.local.request;

import java.io.ByteArrayInputStream;

import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

import com.imop.platform.local.config.IConfig;
import com.imop.platform.local.response.GetUserInfoResponse;
import com.imop.platform.local.response.IResponse;

/**
 * 获取人人用户信息接口<br>
 * 接口功能：<br>
 * 提供获取人人用户信息功能。
 * @author lu.liu
 *
 */
public class GetUserInfoRequest extends AbstractRequest {

	public GetUserInfoRequest(IConfig config){
		super(config);
		this.page = "u.getuserinfo.php" +
				"?userid=%s" +
				"&areaid=%s" +
				"&serverid=%s" +
				"&sign=%s";
	}

	@Override
	protected String[] getParamters(String result){

		String[] args = null;
		
		if(null != result){
			try {
				
				if(result.indexOf("fail") == 0){
					args = result.split(IConfig.RESULT_SPLIT);
				}else{
				
					ByteArrayInputStream stream = new ByteArrayInputStream(result.getBytes());
					Document document = new SAXReader().read(stream);
					
					Element root = document.getRootElement();
					
					int size = root.elements().size();
					
					args = new String[size + 1];
					
					int index = 0;
					
					args[index] = "ok";
					
					for(Object obj : root.elements()){
						Element e = (Element)obj;
						args[++index] = e.getStringValue();
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		return args;
	}

	@Override
	public IResponse getResponse(String[] args) {
		return new GetUserInfoResponse(args);
	}

	@Override
	public void setParams(Object... objects) {
		int areaId = config.getAreaId();
		int serverId = config.getServerId();
		
		long userId = Long.valueOf(objects[0].toString());
		
		String sign = getSign(userId);
		String datetime = getDateTime();
		generateUrl(userId,areaId,serverId,sign,datetime);		
	}

}
