package com.imop.platform.local.request;

import com.imop.platform.local.config.IConfig;
import com.imop.platform.local.response.GetNGWordResponse;
import com.imop.platform.local.response.IResponse;

public class GetNGWordRequest extends AbstractRequest {

	public GetNGWordRequest(IConfig config) {
		super(config);
		this.page = "u.getngword.php?" +
				"timestamp=%s&" +
				"userid=%s&" +
				"ip=%s&" +
				"areaid=%s&" +
				"serverid=%s&" +
				"word=%s&" +
				"domain=%s&" +
				"currenttime=%s&" +
				"sign=%s";

	}

	@Override
	public IResponse getResponse(String[] args) {
		// TODO Auto-generated method stub
		return new GetNGWordResponse(args);
	}

	@Override
	public void setParams(Object... objects) {
		
		long timestamp = getTimestamp();
		int areaid = config.getAreaId();
		int serverid = config.getServerId();
		String domain = config.getDomain();
		
		long userId = Long.valueOf(objects[0].toString());
		String ip = objects[1].toString();
		String word = objects[2].toString();
		long currenttime = Long.valueOf(objects[3].toString());
		String sign = getSign(timestamp,userId,ip,areaid,serverid,word);
		generateUrl(timestamp,userId,ip,areaid,serverid,word,domain,currenttime,sign);
	}

}
