package com.imop.platform.local.request;

import com.imop.platform.local.config.IConfig;
import com.imop.platform.local.response.IResponse;
import com.imop.platform.local.response.PayChannelMobileCardResponse;

public class PayChannelMobileCardRequest extends AbstractRequest {

	public PayChannelMobileCardRequest(IConfig config) {
		super(config);
	}

	@Override
	public IResponse getResponse(String[] args) {
		return new PayChannelMobileCardResponse(args);
	}

	@Override
	public void setParams(Object... objects) {

	}

}
