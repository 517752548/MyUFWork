package com.imop.platform.local.callback;

import com.imop.platform.local.response.IResponse;

/**
 * 异步调用时的回调接口
 * @author lu.liu
 *
 */
public interface ICallback {

	/**
	 * 成功时的方法回调
	 * @param response	平台返回结果封装
	 */
	public void onSuccess(IResponse response);
	
	/**
	 * 失败时的方法回调
	 * @param response	平台返回结果封装
	 */
	public void onFail(IResponse response);
	
}
