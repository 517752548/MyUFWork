package com.imop.platform.local.request;

import com.imop.platform.local.config.IConfig;
import com.imop.platform.local.response.ActiveUseCodeResponse;
import com.imop.platform.local.response.IResponse;

public class ActiveUseCodeRequest extends AbstractRequest {

	/**
	 * 领奖码激活接口<br>
	 * 接口功能：<br>
	 * 提供通过领奖码在游戏中直接领奖的功能。此接口为可选接口<br><br>
	 * @author jiang.li
	 */
	public ActiveUseCodeRequest(IConfig config) {
		super(config);
		this.page = "u.activeusecode.php?" +
				"timestamp=%s" +
				"&userid=%s" +
				"&activationcode=%s" +
				"&ip=%s" +
				"&areaid=%s" +
				"&serverid=%s" +
				"&sign=%s";
	}

	@Override
	public IResponse getResponse(String[] args) {
		return new ActiveUseCodeResponse(args);
	}

	@Override
	public void setParams(Object... objects) {
		long timestamp = getTimestamp();
		int areaId = config.getAreaId();
		int serverId = config.getServerId();

		long userid = Long.valueOf(objects[0].toString());
		String activationCode = objects[1].toString();
		String ip = objects[2].toString();
		
		String sign = getSign(timestamp,userid,activationCode+ip+areaId,serverId);
		generateUrl(timestamp,userid,activationCode,ip,areaId,serverId,sign);		
	

	}

}
