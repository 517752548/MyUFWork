package com.imop.platform.local.request;

import java.math.BigDecimal;

import com.imop.platform.local.request.TransferReportRequest.enum_chargetype;
import com.imop.platform.local.request.TransferReportRequest.enum_currency;

public class TransferReportParam {
	/**
	 * 用户ID（userid）
	 */
	private long userId;
	/**
	 * 用户在游戏中的角色编号(roleid)
	 */
	private String roleid;
	/**
	 * 用户兑换游戏币时的客户端IP地址。eg：202.104.1.1
	 */
	private String ip;
	/**
	 * 订单号， 秒时间戳+6位随机串，例如：1270605064123456
	 */
	private String orderid;
	/**
	 * 获得一级游戏币数量
	 */
	private BigDecimal gamebean;
	/**
	 * 兑换类型(expend，transfer，iosexpend，largess)，只能选四种之一，全小写。直冲 expend , 平台币兑换 transfer , ios直冲 iosexpend , 额外奖励 largess
	 */
	private enum_chargetype chargetype;
	/**
	 * 币种(全大写)，常用如下所示 ： BEAN 平台币 ， CNY 人民币 ， USD 美元 ， KRW 韩元， THB 泰元
	 */
	private enum_currency currency;
	/**
	 * 数量(指货币的数量)
	 */
	private BigDecimal mount;
	/**
	 * 游戏服系统时间，时间格式为YYYYMMDDHHmmss,eg:20120506170824(表示2012年5月6日17时8分24秒) 。注：该时间传的是游戏服当地时间，用于解决时区问题。
	 */
	private long currenttime;
	/**
	 * JSON格式扩展信息，如果确实没有扩展信息，可以不传递该参数
	 */
	private String addtioninfo = null;
	/**
	 * 套餐id，如果确实没有套餐id，可以不传递该参数
	 */
	private String itemid = null;
	/**
	 * 套餐名，如果确实没有套餐名，可以不传递该参数  
	 */
	private String itemname = null;
	/**
	 * 玩家平台用户名  
	 */
	private String username = null;
	/**
	 * 玩家游戏内角色名  
	 */
	private String rolename = null;
	/**
	 * 终端设备分类，全小写。 枚举为：pc，ios，android。
	 */
	private String device = null;
	/**
	 * 设备型号，例如：ipad/iphone/htc，全小写。 
	 *      1、ios：通过[[UIDevice currentDevice] model]获取
     *      2、android：通过Build的Model来获取
     *      3、pc类型此项设置为-1
	 */
	private String devicetype = null;
	/**
	 * 操作系统版本，全小写。
	 * 	    1、ios：通过[[UIDevice currentDevice] systemVersion]获取
     *      2、android：通过Build的Release来获取
     *      3、pc类型此项设置为-1
	 */
	private String deviceversion = null;
	/**
	 * 设备唯一识别id，md5( )，32位小写。 
     *      1、ios设备获取方法：md5(Mac)
     *      2、android设备获取方法：md5(serialno_deviceid_macaddress)
     *         其中各参数说明
     *          a).serialno  序列号，android2.2版本以后可以通过从android.os.SystemProperties获取ro.serialno
     *          b).deviceid  通过TelephonyManager的getDeviceId()来获取
     *          c). macaddress 无线网卡地址，通过WifiManager 的getMacAddress()来获取
     *      3、pc类型此项设置为-1
	 */
	private String deviceguid = null;
	/**
	 * 渠道标志
	 */
	private String channel = null;
	/**
	 * 子渠道标志
	 */
	private String subchannel = null;
	/**
	 * 第三方单号  
	 */
	private String thirdpayid = null;
	
	
	public long getUserId() {
		return userId;
	}
	public void setUserId(long userId) {
		this.userId = userId;
	}
	public String getRoleid() {
		return roleid;
	}
	public void setRoleid(String roleid) {
		this.roleid = roleid;
	}
	public String getIp() {
		return ip;
	}
	public void setIp(String ip) {
		this.ip = ip;
	}
	public String getOrderid() {
		return orderid;
	}
	public void setOrderid(String orderid) {
		this.orderid = orderid;
	}
	public BigDecimal getGamebean() {
		return gamebean;
	}
	public void setGamebean(BigDecimal gamebean) {
		this.gamebean = gamebean;
	}
	public enum_chargetype getChargetype() {
		return chargetype;
	}
	public void setChargetype(enum_chargetype chargetype) {
		this.chargetype = chargetype;
	}
	public enum_currency getCurrency() {
		return currency;
	}
	public void setCurrency(enum_currency currency) {
		this.currency = currency;
	}
	public BigDecimal getMount() {
		return mount;
	}
	public void setMount(BigDecimal mount) {
		this.mount = mount;
	}
	public long getCurrenttime() {
		return currenttime;
	}
	public void setCurrenttime(long currenttime) {
		this.currenttime = currenttime;
	}
	public String getAddtioninfo() {
		return addtioninfo;
	}
	public void setAddtioninfo(String addtioninfo) {
		this.addtioninfo = addtioninfo;
	}
	public String getItemid() {
		return itemid;
	}
	public void setItemid(String itemid) {
		this.itemid = itemid;
	}
	public String getItemname() {
		return itemname;
	}
	public void setItemname(String itemname) {
		this.itemname = itemname;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getRolename() {
		return rolename;
	}
	public void setRolename(String rolename) {
		this.rolename = rolename;
	}
	public String getDevice() {
		return device;
	}
	public void setDevice(String device) {
		this.device = device;
	}
	public String getDevicetype() {
		return devicetype;
	}
	public void setDevicetype(String devicetype) {
		this.devicetype = devicetype;
	}
	public String getDeviceversion() {
		return deviceversion;
	}
	public void setDeviceversion(String deviceversion) {
		this.deviceversion = deviceversion;
	}
	public String getDeviceguid() {
		return deviceguid;
	}
	public void setDeviceguid(String deviceguid) {
		this.deviceguid = deviceguid;
	}
	public String getChannel() {
		return channel;
	}
	public void setChannel(String channel) {
		this.channel = channel;
	}
	public String getSubchannel() {
		return subchannel;
	}
	public void setSubchannel(String subchannel) {
		this.subchannel = subchannel;
	}
	public String getThirdpayid() {
		return thirdpayid;
	}
	public void setThirdpayid(String thirdpayid) {
		this.thirdpayid = thirdpayid;
	}
	
	
	
	
	
}
