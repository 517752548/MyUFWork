package com.imop.platform.local.request;

import com.imop.platform.local.config.IConfig;
import com.imop.platform.local.response.GetUserIdByChannelNameResponse;
import com.imop.platform.local.response.IResponse;
/**
 * 通过渠道用户名获取人人ID接口<br>
 * 接口功能：<br>
 * 提供通过渠道用户名和渠道编号获取用户ID的功能<br>
 * 此接口为可选接口
 * @author jiang.li
 *
 */

public class GetUserIdByChannelNameRequest extends AbstractRequest {

	public GetUserIdByChannelNameRequest(IConfig config) {
		super(config);
		this.page="u.getuseridbychannelname.php" +
				"?timestamp=%s" +
				"&channelusername=%s" +
				"&channelcode=%s" +
				"&ip=%s" +
				"&areaid=%s" +
				"&serverid=%s" +
				"&sign=%s";
	}
	
	@Override
	public IResponse getResponse(String[] args) {
		return new GetUserIdByChannelNameResponse(args);
	}

	@Override
	public void setParams(Object... objects) {
		long timestamp = getTimestamp();
		int areaid = config.getAreaId();
		int serverid = config.getServerId();
		
		String channelusername = objects[0].toString();
		String channelcode = objects[1].toString();
		String ip = objects[2].toString();
		
		String sign = getSign(timestamp,encodeUrl(channelusername),channelcode,ip,areaid,serverid);
		generateUrl(timestamp,channelusername,channelcode,ip,areaid,serverid,sign);
		

	}

}
