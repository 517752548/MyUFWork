package com.imop.platform.local.request;

import com.imop.platform.local.config.IConfig;
import com.imop.platform.local.response.IResponse;
import com.imop.platform.local.response.LoginResponse;
import com.imop.platform.local.response.QueryRechargeResponse;

public class QueryRechargeRequest extends AbstractRequest {

	public QueryRechargeRequest(IConfig config) {
		super(config);
		this.page="u.queryrecharge.php?" +
				"timestamp=%s" +
				"&userid=%s" +
				"&ip=%s" +
				"&areaid=%s" +
				"&serverid=%s" ;
	}

	@Override
	public IResponse getResponse(String[] args) {
		return new QueryRechargeResponse(args);
	}

	@Override
	public void setParams(Object... objects) {
		long timestamp = getTimestamp();
		Long userid = Long.valueOf(objects[0].toString());
		String ip = objects[1].toString();
		int areaId = config.getAreaId();
		int serverId = config.getServerId();
		getUrl(timestamp,userid,ip,areaId,serverId);
	}

}
