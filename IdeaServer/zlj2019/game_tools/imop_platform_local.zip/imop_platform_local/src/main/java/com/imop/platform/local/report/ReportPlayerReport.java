package com.imop.platform.local.report;

import com.imop.platform.local.config.IConfig;
import com.imop.platform.local.response.IResponse;
import com.imop.platform.local.response.ReportResponse;

/**
 * 举报玩家非法言论接口<br>
 * 接口功能：<br>
 * 接收玩家举报世界频道非法言论，并将其汇报至crm系统。
 * @author lu.liu
 *
 */
public class ReportPlayerReport extends AbstractReport {
	
	public ReportPlayerReport(IConfig config){
		super(config);
		this.page = "u.reportplayer.php" +
				"?timestamp=%s" +
				"&areaid=%s" +
				"&serverid=%s" +
				"&ip=%s" +
				"&reporter_uname=%s" +
				"&reporter_uid=%s" +
				"&reporter_roleid=%s" +
				"&reporter_rolename=%s" +
				"&reporter_level=%s" +
				"&reporter_time=%s" +
				"&player_uname=%s" +
				"&player_uid=%s" +
				"&player_roleid=%s" +
				"&player_rolename=%s" +
				"&player_level=%s" +
				"&channel=%s" +
				"&say_time=%s" +
				"&msgid=%s" +
				"&msg=%s" +
				"&sign=%s";
	}

	@Override
	public IResponse getResponse(String[] args) {
		return new ReportResponse(args);
	}

	@Override
	public void setParams(Object... objects) {
		long timestamp = getTimestamp();
		int areaId = config.getAreaId();
		int serverId = config.getServerId();
		
		String ip = objects[0].toString();
		String reporterUname = objects[1].toString();
		long reporterUid = Long.valueOf(objects[2].toString()); 
		long reporterRid = Long.valueOf(objects[3].toString());
		String reporterRoleName = objects[4].toString();
		int reporterLevel = Integer.valueOf(objects[5].toString());
		long reporterTime = Long.valueOf(objects[6].toString());
		String playerUname = objects[7].toString();
		long playerUid = Long.valueOf(objects[8].toString());
		long playerRoleId = Long.valueOf(objects[9].toString());
		String playerRoleName = objects[10].toString();
		int playerLevel = Integer.valueOf(objects[11].toString());
		String channel = objects[12].toString();
		String sayTime = objects[13].toString();
		String msgId = objects[14].toString();
		String msg = objects[15].toString();
		
		String sign = getSign(timestamp, areaId,serverId,reporterUid,playerUid,playerRoleId,msgId);
		generateUrl(timestamp,areaId,serverId,ip,reporterUname,reporterUid,reporterRid,reporterRoleName,reporterLevel,reporterTime,playerUname,playerUid,playerRoleId,playerRoleName,playerLevel,channel,sayTime,msgId,msg,sign);
	}
	
	
}
