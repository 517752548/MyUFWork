package com.imop.platform.local.request;

import com.imop.platform.local.config.IConfig;
import com.imop.platform.local.response.CaptchaCheckResponse;
import com.imop.platform.local.response.CaptchaSendResponse;
import com.imop.platform.local.response.IResponse;

public class CaptchaSendRequest extends AbstractRequest {

	public CaptchaSendRequest(IConfig config) {
		super(config);
	}

	@Override
	public IResponse getResponse(String[] args) {
		return new CaptchaSendResponse(args);
	}

	@Override
	public void setParams(Object... objects) {

	}

}
