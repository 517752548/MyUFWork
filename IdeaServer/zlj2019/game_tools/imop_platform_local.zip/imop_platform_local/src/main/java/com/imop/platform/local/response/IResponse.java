package com.imop.platform.local.response;

import net.sf.json.JSONObject;

/**
 * 获取平台返回结果的接口
 * @author lu.liu
 *
 */
public interface IResponse {
	
	/**
	 * 检查接口调用是否成功
	 * @return	true - 接口返回成功<br>
	 * 			false - 接口返回失败
	 */
	public boolean isSuccess();
	
	/**
	 * 获取错误码
	 * @return	错误码
	 */
	public int getErrorCode();
	

	/**
	 * 获取消耗时间
	 * @return
	 */
	public long getUseTime();
	
	/**
	 * 设置消耗时间
	 * @param time	接口消耗时间
	 */
	public void setUseTime(long time);
	
	/**
	 * 成功调用时做赋值操作
	 * @param args
	 */
	public void onSuccess(String[] args);
	
}
