package com.imop.platform.local.type;

public interface IEnumType<E extends Enum<E>> extends IType {

}
