package com.imop.platform.local.request;

import com.imop.platform.local.config.IConfig;
import com.imop.platform.local.response.GoodsInfo;
import com.imop.platform.local.response.IResponse;
import com.imop.platform.local.response.ThirdActivitiesCodeResponse;

public class ThirdActivitiesCodeRequest extends AbstractRequest {

	
	
	public ThirdActivitiesCodeRequest(IConfig config) {
		super(config);
		this.page = "u.thirdactivitiescode.php" +
				"?timestamp=%s" +
				"&userid=%s" +
				"&activitesnumbers=%s" +
				"&ip=%s" ;
	}

	@Override
	public IResponse getResponse(String[] args) {
		// TODO Auto-generated method stub
		return new ThirdActivitiesCodeResponse(args);
	}

	@Override
	public void setParams(Object... objects) {
		long timestamp = getTimestamp();
		Long userid = Long.valueOf(objects[0].toString());
		String activitiesNumbers = objects[1].toString();
		String ip =  objects[2].toString();
		getUrl(timestamp,userid,activitiesNumbers,ip);
	}

}
