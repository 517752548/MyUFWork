package com.imop.platform.local.response;

import com.imop.platform.local.response.AbstractResponse;

public class DelRoleReportResponse extends AbstractResponse {

	private String state=null;
	public DelRoleReportResponse(String[] args) {
		super(args, 2);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void onSuccess(String[] args) {
		state = args[0];

	}

	public String getState() {
		return state;
	}
	

}
