package com.imop.platform.local.report;

import com.imop.platform.local.config.IConfig;
import com.imop.platform.local.response.IResponse;
import com.imop.platform.local.response.ReportResponse;

/**
 * 领取GM奖励汇报接口<br>
 * 接口功能：<br>
 * 接收玩家领取GM后台发的奖励的相关信息。
 * @author lu.liu
 *
 */
public class ReportGmLargessReport extends AbstractReport {
	
	public ReportGmLargessReport(IConfig config){
		super(config);
		this.page = "u.reportgmlargess.php?timestamp=%s&domain=%s&areaid=%s&serverid=%s&ip=%s&activityid=%s&serialid=%s&get_time=%s&username=%s&userid=%s&rolename=%s&roleid=%s&props=%s&propnum=%s&sing=%s&currenttime=%s";
	}

	@Override
	public IResponse getResponse(String[] args) {
		return new ReportResponse(args);
	}

	@Override
	public void setParams(Object... objects) {
		long timestamp = getTimestamp();
		int areaId = config.getAreaId();
		int serverId = config.getServerId();
		String domain = config.getDomain();
		
		String ip = objects[0].toString();
		String activityId = objects[1].toString();
		String serialid = objects[2].toString();
		long getTime = Long.valueOf(objects[3].toString());
		String userName = objects[4].toString();
		long userId = Long.valueOf(objects[5].toString()); 
		String roleName = objects[6].toString();
		long roleId = Long.valueOf(objects[7].toString());
		String props = objects[8].toString();
		String propNum = objects[9].toString();
		
		String sign = getSign(timestamp,areaId,serverId,ip,activityId, serialid,userId, roleId);
		String datetime = getDateTime();
		generateUrl(timestamp,domain,areaId,serverId,ip,activityId,serialid,getTime,userName,userId,roleName,roleId,props,propNum,sign,datetime);
	}

}
