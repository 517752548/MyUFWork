package com.imop.platform.local.handler;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;

import net.sf.json.JSONObject;

import org.apache.commons.lang.StringUtils;

import com.imop.platform.local.bean.ReportForDGBean;
import com.imop.platform.local.callback.ICallback;
import com.imop.platform.local.config.LocalConfig;
import com.imop.platform.local.request.CaptchaCheckRequest;
import com.imop.platform.local.request.CaptchaSendRequest;
import com.imop.platform.local.request.ChannelUserLoginRequest;
import com.imop.platform.local.request.GenerateOrderRequest;
import com.imop.platform.local.request.IRequest;
import com.imop.platform.local.request.PayChannelMobileCardRequest;
import com.imop.platform.local.request.PayChannelMycardRequest;
import com.imop.platform.local.request.PayChannelQueryStatusRequest;
import com.imop.platform.local.request.PayChannelRRCardRequest;
import com.imop.platform.local.request.QueryAllRechargeRequest;
import com.imop.platform.local.request.RequestFactory;
import com.imop.platform.local.request.SurveyRequest;
import com.imop.platform.local.request.TransferReportParam;
import com.imop.platform.local.request.TransferReportRequest.enum_chargetype;
import com.imop.platform.local.request.TransferReportRequest.enum_currency;
import com.imop.platform.local.response.ActiveUseCodeResponse;
import com.imop.platform.local.response.AddAttentionResponse;
import com.imop.platform.local.response.AddRoleReportResponse;
import com.imop.platform.local.response.AddWallowInfoResponse;
import com.imop.platform.local.response.CaptchaCheckResponse;
import com.imop.platform.local.response.CaptchaSendResponse;
import com.imop.platform.local.response.ChannelUserLoginResponse;
import com.imop.platform.local.response.CreateIOSPaymentResponse;
import com.imop.platform.local.response.CreateLinkResponse;
import com.imop.platform.local.response.DelRoleReportResponse;
import com.imop.platform.local.response.ExchangeRechargeResponse;
import com.imop.platform.local.response.ExpendGamePointsResponse;
import com.imop.platform.local.response.ExpendIOSPaymentResponse;
import com.imop.platform.local.response.GenerateOrderResponse;
import com.imop.platform.local.response.GetFCMTimeResponse;
import com.imop.platform.local.response.GetFriendsListResponse;
import com.imop.platform.local.response.GetGameUserInfoResponse;
import com.imop.platform.local.response.GetGoodsResponse;
import com.imop.platform.local.response.GetNGWordResponse;
import com.imop.platform.local.response.GetNickNameResponse;
import com.imop.platform.local.response.GetUserBirthdayResponse;
import com.imop.platform.local.response.GetUserIdByChannelNameResponse;
import com.imop.platform.local.response.GetUserIdByNameResponse;
import com.imop.platform.local.response.GetUserIdByNickNameResponse;
import com.imop.platform.local.response.GetUserInfoResponse;
import com.imop.platform.local.response.GetUserIsLegalResponse;
import com.imop.platform.local.response.GetUserNameByIdResponse;
import com.imop.platform.local.response.GetVersionResponse;
import com.imop.platform.local.response.IOSRechargeResponse;
import com.imop.platform.local.response.IsBlackListUserResqponse;
import com.imop.platform.local.response.LoginResponse;
import com.imop.platform.local.response.LogoutResponse;
import com.imop.platform.local.response.PayChannelMobileCardResponse;
import com.imop.platform.local.response.PayChannelMycardResponse;
import com.imop.platform.local.response.PayChannelQueryStatusResponse;
import com.imop.platform.local.response.PayChannelRRCardRespose;
import com.imop.platform.local.response.QueryAllRechargeResponse;
import com.imop.platform.local.response.QueryBalanceResponse;
import com.imop.platform.local.response.QueryGoodsResponse;
import com.imop.platform.local.response.QueryOnlineTimeResponse;
import com.imop.platform.local.response.QueryRechargeResponse;
import com.imop.platform.local.response.QuickLoginResponse;
import com.imop.platform.local.response.ThirdActivitiesCodeResponse;
import com.imop.platform.local.response.TransferReportResponse;
import com.imop.platform.local.response.TransferResponse;
import com.imop.platform.local.type.IEnumType;
import com.imop.platform.local.type.LoginType;

/**
 * 平台接口处理器
 * @author lu.liu
 *
 */
public class LocalHandler implements IHandler {

	/**
	 * 接口配置
	 */
	private LocalConfig config;

	public LocalHandler(LocalConfig config){
		this.config = config;
	}

	/* (non-Javadoc)
	 * @see com.imop.platform.handler.IHandler#login(long, java.lang.String, java.lang.String, int, int, java.lang.String, int)
	 */
	@Override
	public LoginResponse login(String userName, String password, String ip,IEnumType<LoginType> loginType){
	
		IRequest request = RequestFactory.createLoginRequest(config);
		
		int getkxid = 2;

		request.setParams(userName, password, ip, loginType.getType(),getkxid,new ReportForDGBean());
		
		return (LoginResponse)request.send();			
	}
	@Override
	public LoginResponse login(String userName, String password, String ip,IEnumType<LoginType> loginType,ReportForDGBean bean){
	
		IRequest request = RequestFactory.createLoginRequest(config);
		
		int getkxid = 2;

		request.setParams(userName, password, ip, loginType.getType(),getkxid,bean);
		
		return (LoginResponse)request.send();			
	}
	@Override
	public LoginResponse login(String userName, String password, String ip,IEnumType<LoginType> loginType,int getkxid){
		
		IRequest request = RequestFactory.createLoginRequest(config);
		
		request.setParams(userName, password, ip, loginType.getType(),getkxid,new ReportForDGBean());
		
		return (LoginResponse)request.send();			
	}
	@Override
	public LoginResponse login(String userName, String password, String ip,IEnumType<LoginType> loginType,int getkxid,ReportForDGBean bean){
		
		IRequest request = RequestFactory.createLoginRequest(config);
		
		request.setParams(userName, password, ip, loginType.getType(),getkxid,bean);
		
		return (LoginResponse)request.send();			
	}
	@Override
	public GetUserIdByChannelNameResponse getUserIdByChannelName(String channelusername,String channelcode,String ip)
	{
		IRequest request = RequestFactory.createGetUserIdByChannelNameRequest(config);
		request.setParams(channelusername,channelcode,ip);
		return (GetUserIdByChannelNameResponse)request.send();
	}
	@Override
	public GetUserBirthdayResponse getUserBirthday(long userId,String ip)
	{
		IRequest request =  RequestFactory.createGetUserBirthdayRequset(config);
		request.setParams(userId,ip);
		return (GetUserBirthdayResponse)request.send();
	}
	@Override
	public LogoutResponse logout(long userId, String ip) {
		
		IRequest request = RequestFactory.createLogoutRequest(config);
		
		request.setParams(userId, ip , new ReportForDGBean());
		
		return (LogoutResponse)request.send();			
	}
	@Override
	public LogoutResponse logout(long userId,String ip,ReportForDGBean bean){
		
		IRequest request = RequestFactory.createLogoutRequest(config);
		
		request.setParams(userId, ip , bean);
		
		return (LogoutResponse)request.send();	
	}
	
	@Override
	public TransferResponse transfer(long userId, String roleId, int money, String ip) {
		
		int getOrderId = 2;
		int gettransfer = 2;
		return transfer(userId, roleId, money, ip,getOrderId);
	}

	@Override
	public TransferResponse transfer(long userId, String roleId, int money, String ip,int getOrderId) {
		
		int gettransfer = 2;
		return transfer(userId, roleId, money, ip,getOrderId , gettransfer);
	}
	
	@Override
	public TransferResponse transfer(long userId, String roleId, int money, String ip , int getOrderId , int gettransfer) {
		
		if(gettransfer == 1) getOrderId = 1;
		IRequest request = RequestFactory.createTransferRequest(config);

		request.setParams(userId, roleId, money, ip , getOrderId , gettransfer);
		
		return (TransferResponse)request.send(true);
	}

	@Override
	public QueryBalanceResponse queryBalance(long userId, String ip) {
		
		IRequest request = RequestFactory.createQueryBalanceRequest(config);

		request.setParams(userId, ip);

		return (QueryBalanceResponse)request.send();			
	}

	@Override
	public void onlineReport(int onlineNum,ICallback callback) {

		IRequest request = RequestFactory.createOnlineReport(config);
		
		request.setParams(onlineNum);

		request.asyncSend(callback);
	}
	
	@Override
	public void onlineReport(int serverId, int onlineNum,ICallback callback) {

		IRequest request = RequestFactory.createOnlineReport(config);
		
		request.setParams(onlineNum, serverId);

		request.asyncSend(callback);
	}

	@Override
	public QueryGoodsResponse queryGoods(long userId, String roleId, String ip) {
	
		IRequest request = RequestFactory.createQueryGoodsRequest(config);
		
		request.setParams(userId, roleId, ip);

		return (QueryGoodsResponse)request.send();			
	}

	@Override
	public GetGoodsResponse getGoods(long userId, String roleId, String ip, int id, int largessId) {
		
		IRequest request = RequestFactory.createGetGoodsRequest(config);
		
		request.setParams(userId, roleId, ip, id, largessId);
			
		return (GetGoodsResponse)request.send();			
	}

	@Override
	public void statusReport(String servers, String status, String extra, ICallback callback) {
		
		IRequest request = RequestFactory.createStatusReport(config);
		
		request.setParams(servers, status, extra);

		request.asyncSend(callback);
	}

	@Override
	public void transRecordReport(String orderId, long userId,String roleId, long money, String goodSid, String ip,ICallback callback) {
	
		IRequest request = RequestFactory.createTransRecordReport(config);
		
		request.setParams(orderId, userId, roleId, money, goodSid, ip);

		request.asyncSend(callback);
	}

	@Override
	public LoginResponse gmLogin(String userName, String ip, String password, IEnumType<LoginType> loginType) {
		return gmLogin( userName,  ip,  password, loginType,new ReportForDGBean());			
	}
	public LoginResponse gmLogin(String userName,String ip,String password,IEnumType<LoginType> loginType,ReportForDGBean bean){
		IRequest request = RequestFactory.createGmLoginRequest(config);

		request.setParams(userName, ip, password, loginType.getType(),bean);
		
		return (LoginResponse)request.send();	
	}
	@Override
	public GetUserNameByIdResponse getUserNameById(long userId, String ip) {

		IRequest request = RequestFactory.createGetUserNameByIdRequest(config);
		
		request.setParams(userId, ip);

		return (GetUserNameByIdResponse)request.send();			
	}

	@Override
	public GetUserIdByNameResponse getUserIdByName(String userName,String ip) {

		IRequest request = RequestFactory.createGetUserIdByNameRequest(config);

		request.setParams(userName, ip);

		return (GetUserIdByNameResponse)request.send();			
	}

	@Override
	public GetUserIsLegalResponse getUserIsLegal(String userName,String psw, String ip) {
	
		IRequest request = RequestFactory.createGetUserIsLegalRequest(config);
		
		request.setParams(userName, psw, ip);

		return (GetUserIsLegalResponse)request.send();			
	}

	@Override
	public QueryOnlineTimeResponse queryOnlineTime(long userId) {
		
		IRequest request = RequestFactory.createQueryOnlineTimeRequest(config);

		request.setParams(userId);

		return (QueryOnlineTimeResponse)request.send();			
	}

	@Override
	public void reportPlayerReport(String ip,
			String repoterUname, long repoterUid, long repoterRid,
			String repoterRoleName, int repoterLevel, long repoterTime,
			String playerUname, long playerUid, long playerRoleId,
			String playerRoleName, int playerLevel, String channel,
			String sayTime, String msgId, String msg,ICallback callback) {

		IRequest request = RequestFactory.createReportPlayerReport(config);
		
		request.setParams(ip, repoterUname, repoterUid, repoterRid, repoterRoleName, repoterLevel, repoterTime, playerUname, playerUid, playerRoleId, playerRoleName, playerLevel, channel, sayTime, msgId, msg);
		
		request.asyncSend(callback);

	}

	@Override
	public void reportGmLargessReport(String ip, String activityId, String serialid, long getTime, String userName,
			long userId, String roleName, long roleId, String props, String propNum, ICallback callback) {

			
		IRequest request = RequestFactory.createReportGmLargessReport(config);
		
		request.setParams(ip, activityId, serialid, getTime, userName, userId, roleName, roleId, props, propNum);
		
		request.asyncSend(callback);
	}

	@Override
	public void propsStatusReport(String activityId,String userName, String userId, String roleName, String roleId,
			String serialid, String gmIp, String gmer, long gmTime,	String props, String propnum, String propName, int propLock,
			String propPrice, int propAward, int status, String failure,ICallback callback) {

		IRequest request = RequestFactory.createPropsStatusReport(config);
		
		request.setParams(activityId, userName, userId, roleName, roleId, serialid, gmIp, gmer, gmTime, props, propnum, propName, propLock, propPrice, propAward, status, failure);
		
		request.asyncSend(callback);
	}

	@Override
	public GetUserInfoResponse getUserInfo(long userId) {
		IRequest request = RequestFactory.createGetUserInfoRequest(config);

		request.setParams(userId);

		return (GetUserInfoResponse)request.send();			
	}

	@Override
	public GetUserIdByNickNameResponse getUserIdByNickName(String nickName) {
		IRequest request = RequestFactory.createGetUserIdByNickNameRequest(config);

		request.setParams(nickName);

		return (GetUserIdByNickNameResponse)request.send();			
	}

	@Override
	public GetNickNameResponse getNickName(long userId) {
		IRequest request = RequestFactory.createGetNickNameRequest(config);
		
		request.setParams(userId);

		return (GetNickNameResponse)request.send();			
	}
	
	@Override
	public GetVersionResponse getVersion(){
		IRequest request = RequestFactory.createGetVersionRequest(config);
		
		request.setParams("");
		
		return (GetVersionResponse)request.send();
	}
	
	@Override
	public LocalConfig getConfig(){
		return config;
	}
	
	@Override
	public void setReportService(ExecutorService reporService) {
		config.setReportService(reporService);
	}

	@Override
	public void onlineReport(int onlineNum) {
		onlineReport(onlineNum, null);
	}
	
	@Override
	public void onlineReport(int serverId, int onlineNum) {
		onlineReport(serverId, onlineNum, null);
	}

	@Override
	public void propsStatusReport(String activityId, String userName,
			String userId, String roleName, String roleId, String serialid,
			String gmIp, String gmer, long gmTime, String props,
			String propnum, String propName, int propLock, String propPrice,
			int propAward, int status, String failure) {
		propsStatusReport(activityId, userName, userId, roleName, roleId, serialid, gmIp, gmer, gmTime, props, propnum, propName, propLock, propPrice, propAward, status, failure, null);
	}

	@Override
	public void reportGmLargessReport(String ip, String activityId,
			String serialid, long getTime, String userName, long userId,
			String roleName, long roleId, String props, String propNum) {
		reportGmLargessReport(ip, activityId, serialid, getTime, userName, userId, roleName, roleId, props, propNum, null);
	}

	@Override
	public void reportPlayerReport(String ip, String repoterUname,
			long repoterUid, long repoterRid, String repoterRoleName,
			int repoterLevel, long repoterTime, String playerUname,
			long playerUid, long playerRoleId, String playerRoleName,
			int playerLevel, String channel, String sayTime, String msgId,
			String msg) {
		reportPlayerReport(ip, repoterUname, repoterUid, repoterRid, repoterRoleName, repoterLevel, repoterTime, playerUname, playerUid, playerRoleId, playerRoleName, playerLevel, channel, sayTime, msgId, msg, null);
	}

	@Override
	public void statusReport(String servers, String status, String extra) {
		statusReport(servers, status, extra, null);
	}

	@Override
	public void transRecordReport(String orderId, long userId, String roleId,
			long money, String goodSid, String ip) {
		transRecordReport(orderId, userId, roleId, money, goodSid, ip, null);
	}

	@Override
	public AddWallowInfoResponse addWallowInfo(long userId, String trueName,
			String idCard, String ip) {
		String cookie = "";
		IRequest request = RequestFactory.createAddWallowInfoRequest(config);
		request.setParams(userId, trueName, idCard, ip,cookie);
		return (AddWallowInfoResponse)request.send();
	}
	@Override
	public AddWallowInfoResponse addWallowInfo(long userId, String trueName,
			String idCard, String ip ,String cookie) {
		IRequest request = RequestFactory.createAddWallowInfoRequest(config);
		request.setParams(userId, trueName, idCard, ip,cookie);
		return (AddWallowInfoResponse)request.send();
	}

	@Override
	public GetGameUserInfoResponse getGameUserInfo(long userId, String ip) {
		IRequest request = RequestFactory.createGetGameUserInfoRequest(config);
		request.setParams(userId, ip);
		return (GetGameUserInfoResponse)request.send();
	}

	@Override
	public GetFriendsListResponse getFriendsList(String ticket) {
		IRequest request = RequestFactory.createGetFriendsListRequest(config);
		request.setParams(ticket);
		return (GetFriendsListResponse) request.send();
	}

	@Override
	public AddAttentionResponse addattention(String ticket) {
		IRequest request = RequestFactory.createAddattentionRequest(config);
		request.setParams(ticket);
		return (AddAttentionResponse) request.send();
	}

	@Override
	public CreateLinkResponse createlink(String ticket) {
		IRequest request = RequestFactory.createCreateLinkRequest(config);
		request.setParams(ticket);
		return (CreateLinkResponse) request.send();
	}

	@Override
	public ActiveUseCodeResponse activeUseCode(long userid,
			String activationCode, String ip) {
		IRequest request = RequestFactory.createActiveUseCodeRequest(config);
		request.setParams(userid,activationCode,ip);
		return (ActiveUseCodeResponse) request.send();
	}

	@Override
	public ExpendGamePointsResponse expendGamePoints(long userId, long roleid,
			String ip, String orderid, long currenttime) {
		IRequest request = RequestFactory.createExpendGamePointsRequest(config);
		request.setParams( userId,  roleid, ip,  orderid,  getCurrentTime());
		return (ExpendGamePointsResponse) request.send();
	}
	
	@Override
	public ExpendGamePointsResponse expendGamePoints(long userId, long roleid,
			String ip, String orderid, long currenttime,int type) {
		IRequest request = RequestFactory.createExpendGamePointsRequest(config);
		request.setParams( userId,  roleid, ip,  orderid,  getCurrentTime(),type);
		return (ExpendGamePointsResponse) request.send();
	}

	@Override
	public AddRoleReportResponse addRoleReport(long userid, String roleId,
			String rolename, String ip) {
//		IRequest request = RequestFactory.createAddRoleReportRequest(config);
//		request.setParams( userid,  roleId, rolename, ip);
//		return (AddRoleReportResponse) request.send();
		
		IRequest request = RequestFactory.createAddRoleReportRequest(config);
		Map<String, Object> p = new LinkedHashMap<String, Object>();
		p.put("userid", userid);
		p.put("roleid", roleId);
		p.put("rolename", rolename);
		p.put("ip", ip);
		p.put("currenttime", getCurrentTime());
		p.put("format", "JSON");
		request.genOptinalURL("u.addrolereport.php", p);
		return (AddRoleReportResponse)request.send(true);
	}

	@Override
	public DelRoleReportResponse delRoleReport(long userid, String roleId,
			String rolename, String ip) {
		IRequest request = RequestFactory.createDelRoleReportRequest(config);
		request.setParams( userid,  roleId, rolename, ip);
		return (DelRoleReportResponse) request.send();
	}

	@Override
	public LoginResponse oauthLogin(String token, String channelcode,
			String ip) {
		IRequest request = RequestFactory.createOauthLoginRequest(config);
		request.setParams( token,  channelcode,ip);
		return (LoginResponse) request.send();
	}

	@Override
	public GetNGWordResponse getNGWord(long userId, String ip, String word,
			long currenttime) {
		IRequest request = RequestFactory.createGetNGWordRequest(config);
		request.setParams(userId, ip, word, getCurrentTime());
		return (GetNGWordResponse)request.send();
	}
	@Override
	public GetFCMTimeResponse getFCMTime(long userId, String ip,long currenttime) {
		IRequest request = RequestFactory.createGetFCMTimeRequest(config);
		request.setParams(userId, ip, getCurrentTime());
		return (GetFCMTimeResponse)request.send();
	}
	@Override
	public CreateIOSPaymentResponse createIOSPayment(long userId,String roleId,String ip,String item_table,String token,String udid,String uuid){
		return createIOSPayment(userId,roleId,ip,item_table,token,udid,uuid,uuid);
	}
	@Override
	public CreateIOSPaymentResponse createIOSPayment(long userId,String roleId,String ip,String item_table,String token,String udid,String uuid,String macinfo){
		IRequest request = RequestFactory.createCreateIOSPaymentRequest(config);
		request.setParams(userId,roleId,ip,item_table,token,udid,uuid,macinfo);
		return (CreateIOSPaymentResponse)request.send();
	}
	
	@Override
	public ExpendIOSPaymentResponse expendIOSPayment(long userId,String roleId,String ip,String udid){
		IRequest request = RequestFactory.createExpendIOSPaymentRequest(config);
		request.setParams(userId,roleId,ip,udid);
		return (ExpendIOSPaymentResponse)request.send();
	}
	@Override
	public IsBlackListUserResqponse isBlackListUser(long userId,String ip,String udid,String uuid){
		IRequest request = RequestFactory.createIsBlackListUserRequest(config);
		request.setParams(userId,ip,udid,uuid);
		return (IsBlackListUserResqponse)request.send();
	}
	
	public QueryRechargeResponse queryRecharge(long userId,String ip,long currenttime){
		IRequest request = RequestFactory.createQueryRechargeRequest(config);
		request.setParams(userId,ip,getCurrentTime());
		return (QueryRechargeResponse)request.send(true);		
	}
	
	public ExchangeRechargeResponse exchangerecharge(long userId,String pids,String ip,long currenttime){
		IRequest request = RequestFactory.createExchangeRechargeRequest(config);
		request.setParams(userId,pids,ip,getCurrentTime());
		return (ExchangeRechargeResponse)request.send(true);
	}
	
	public IOSRechargeResponse iosRecharge(long userId,String roleId,String item_table, String amount,
			String itemId,String itemName,long coin,String macInfo,String token,String ip,long currenttime,String udid,String userName,String charName,String deviceType,String deviceVersion){
		IRequest request = RequestFactory.createIOSRechargeRequest(config);
		request.setParams( userId, roleId, item_table,  amount, itemId, itemName, coin, macInfo, token, ip, getCurrentTime(), udid, userName, charName, deviceType, deviceVersion);
		return (IOSRechargeResponse)request.sendByPost(true);
	}
	
	public ThirdActivitiesCodeResponse thirdActivitiesCode(long userId , String activiesNumbers , String ip , long currenttime ){
		IRequest request = RequestFactory.createThirdActivitiesCodeRequest(config);
		request.setParams(userId , activiesNumbers , ip , getCurrentTime() );
		return (ThirdActivitiesCodeResponse)request.send(true);
	}
	
	public QuickLoginResponse quickLogin(String ip,Long currenttime,String uuid,String promotionCode,ReportForDGBean bean){
		IRequest request = RequestFactory.createQuickLogin(config);
		request.setParams( ip , getCurrentTime() , uuid , promotionCode,bean);
		return (QuickLoginResponse)request.send(true);
	}
	public QuickLoginResponse quickLogin(String ip,Long currenttime,String uuid,String promotionCode){
		return quickLogin( ip , getCurrentTime() , uuid , promotionCode ,new ReportForDGBean());
	}
	public QuickLoginResponse quickLogin(String ip,Long currenttime,String uuid){
		return quickLogin(ip , getCurrentTime() , uuid , "");
	}
	
	public TransferReportResponse transferReport(long userId,String roleid,String ip,String orderid,BigDecimal gamebean,enum_chargetype chargetype,	enum_currency currency,	BigDecimal mount,	String addtionInfo,	String itemid,	String itemname,long currenttime){
//		IRequest request = RequestFactory.createTransferReport(config);
//		request.setParams(userId,roleid,ip,orderid,gamebean,chargetype,currency,mount,addtionInfo,itemid,itemname,currenttime);
//		return (TransferReportResponse)request.send(true);
		
		Map<String, String> map = new LinkedHashMap<String, String>();
		if(addtionInfo!=null) map.put("addtioninfo", addtionInfo);
		if(itemid!=null) map.put("itemid", itemid);
		if(itemname!=null) map.put("itemname", itemname);
		return transferReport(userId, roleid, ip, orderid, gamebean, chargetype, currency, mount, getCurrentTime(), map);
		
	}
	
	public TransferReportResponse transferReport(long userId,String roleid,String ip,String orderid,BigDecimal gamebean,enum_chargetype chargetype,	enum_currency currency,	BigDecimal mount,long currenttime,Map<String,String> optionalParams){
		IRequest request = RequestFactory.createTransferReport(config);
		Map<String, Object> p = new LinkedHashMap<String, Object>();
		p.put("userid", userId);
		p.put("roleid", roleid);
		p.put("ip", ip);
		p.put("orderid", orderid);
		p.put("gamebean", gamebean);
		p.put("chargetype", chargetype);
		p.put("currency", currency);
		p.put("mount", mount);
		p.put("currenttime", getCurrentTime());
		Set<String> keySet = optionalParams.keySet();
		for(String key:keySet) {
			p.put(key, optionalParams.get(key));
		}
		request.genOptinalURL("u.transferreport.php", p);
		return (TransferReportResponse)request.send(true);
	}
	
	private static long getCurrentTime() {
		String s = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
		return Long.parseLong(s);
	}

	@Override
	public TransferReportResponse transferReport(TransferReportParam param) {
		IRequest request = RequestFactory.createTransferReport(config);
		Map<String, Object> p = new LinkedHashMap<String, Object>();
		p.put("userid", param.getUserId());
		p.put("roleid", param.getRoleid());
		p.put("ip", param.getIp());
		p.put("orderid", param.getOrderid());
		p.put("gamebean", param.getGamebean());
		p.put("chargetype", param.getChargetype());
		p.put("currency", param.getCurrency());
		p.put("mount", param.getMount());
		p.put("currenttime", param.getCurrenttime());
		
		if(param.getAddtioninfo()!=null) p.put("addtioninfo", param.getAddtioninfo());
		if(param.getItemid()!=null) p.put("itemid", param.getItemid());
		if(param.getItemname()!=null) p.put("itemname", param.getItemname());
		if(param.getUsername()!=null) p.put("username", param.getUsername());
		if(param.getRolename()!=null) p.put("rolename", param.getRolename());
		if(param.getDevice()!=null) p.put("device", param.getDevice());
		if(param.getDevicetype()!=null) p.put("devicetype", param.getDevicetype());
		if(param.getDeviceversion()!=null) p.put("deviceversion", param.getDeviceversion());
		if(param.getDeviceguid()!=null) p.put("deviceguid", param.getDeviceguid());
		if(param.getChannel()!=null) p.put("channel", param.getChannel());
		if(param.getSubchannel()!=null) p.put("subchannel", param.getSubchannel());
		if(param.getThirdpayid()!=null) p.put("thirdpayid", param.getThirdpayid());
		
		request.genOptinalURL("u.transferreport.php", p);
		return (TransferReportResponse)request.send(true);
	}
	
	public QueryAllRechargeResponse queryAllRecharge() {
		QueryAllRechargeRequest request = new QueryAllRechargeRequest(config);
		Map<String, Object> p = new LinkedHashMap<String, Object>();
		p.put("currenttime", getCurrentTime());
		p.put("format", "JSON");
		
		request.genOptinalURL("u.queryallrecharge.php", p);
		return (QueryAllRechargeResponse)request.send(true);
		
	}

	@Override
	public ChannelUserLoginResponse channelUserLogin(String ip,
			String channelCode, String channelUserId) {
		return channelUserLogin(ip, channelCode, channelUserId, null,new ReportForDGBean());
	}

	@Override
	public ChannelUserLoginResponse channelUserLogin(String ip,
			String channelCode, String channelUserId, String promotionCode) {
		return channelUserLogin(ip, channelCode, channelUserId, promotionCode,new ReportForDGBean());
	}
	
	public ChannelUserLoginResponse channelUserLogin(String ip,String channelCode,String channelUserId,String promotionCode,ReportForDGBean bean){
		ChannelUserLoginRequest request = new ChannelUserLoginRequest(config);
		Map<String, Object> p = new LinkedHashMap<String, Object>();
		p.put("currenttime", getCurrentTime());
		p.put("format", "JSON");
		p.put("ip", ip);
		p.put("channelcode", channelCode);
		p.put("channeluserid", channelUserId);
		if(StringUtils.isNotBlank(promotionCode)) {
			p.put("promotionCode", promotionCode);
		}
		long date= System.currentTimeMillis()/1000;
		//System.out.println(date);
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		java.util.Calendar cal = java.util.Calendar.getInstance();   
	    cal.setTime(new Date(date*1000));
		int zoneOffset = cal.get(java.util.Calendar.ZONE_OFFSET);   
		int dstOffset = cal.get(java.util.Calendar.DST_OFFSET);    
		cal.add(java.util.Calendar.MILLISECOND, -(zoneOffset + dstOffset)); 
		String nowTime = df.format(new Date(date*1000));
		String utcTime = df.format(cal.getTime());
		int areaId = config.getAreaId();
		int serverId = config.getServerId();
		bean.complement(date*1000, utcTime, nowTime, config.getGamecode(), config.getPlatformid(), ""+areaId,""+serverId, config.getDomain());
		
		p.put("dataext", JSONObject.fromObject(bean).toString());
		
		request.genOptinalURL("u.channeluserlogin.php", p);
		
		return (ChannelUserLoginResponse)request.send(true);
	}

	@Override
	public PayChannelRRCardRespose payChannelRRCard(long userid, String cardId,
			String cardPwd, String gameOrderId, String userName, String roleid,
			String charName, String deviceType, String deviceVersion,
			String ip, String macInfo, String udid,String terminal) {
		
		PayChannelRRCardRequest request = new PayChannelRRCardRequest(config);
		Map<String, Object> p = new LinkedHashMap<String, Object>();
		p.put("currenttime", getCurrentTime());
		p.put("format", "JSON");
		p.put("userid", userid);
		p.put("cardId", cardId);
		p.put("cardPwd", cardPwd);
		p.put("gameOrderId", gameOrderId);
		p.put("userName", userName);
		p.put("roleid", roleid);
		p.put("charName", charName);
		p.put("deviceType", deviceType);
		p.put("deviceVersion", deviceVersion);
		p.put("ip", ip);
		p.put("macInfo", macInfo);
		p.put("udid", udid);
		p.put("terminal", terminal);
		request.genOptinalURL("u.paychannelrrcard.php", p);
		
		return (PayChannelRRCardRespose)request.send(true);
	}

	@Override
	public PayChannelMobileCardResponse payChannelMobileCard(long userid,
			String cardId, String cardPwd, String cardType, long amount,
			String gameOrderId, String userName, String roleid,
			String charName, String deviceType, String deviceVersion,
			String ip, String macInfo, String udid,String terminal) {
		
		PayChannelMobileCardRequest request = new PayChannelMobileCardRequest(config);
		Map<String, Object> p = new LinkedHashMap<String, Object>();
		p.put("currenttime", getCurrentTime());
		p.put("format", "JSON");
		p.put("userid", userid);
		p.put("cardId", cardId);
		p.put("cardPwd", cardPwd);
		p.put("cardType",cardType);
		p.put("amount",amount);
		p.put("gameOrderId",gameOrderId);
		p.put("userName",userName);
		p.put("roleid",roleid);
		p.put("charName",charName);
		p.put("deviceType",deviceType);
		p.put("deviceVersion",deviceVersion);
		p.put("ip",ip);
		p.put("macInfo",macInfo);
		p.put("udid",udid);
		p.put("terminal", terminal);
		request.genOptinalURL("u.paychannelmobilecard.php", p);
		
		return (PayChannelMobileCardResponse)request.send(true);
	}

	@Override
	public PayChannelQueryStatusResponse payChannelQueryStatus(long userid,
			String ip, String gameOrderId) {
		
		PayChannelQueryStatusRequest request = new PayChannelQueryStatusRequest(config);
		Map<String, Object> p = new LinkedHashMap<String, Object>();
		p.put("currenttime", getCurrentTime());
		p.put("format", "JSON");
		p.put("userid", userid);
		p.put("ip", ip);
		p.put("gameOrderId", gameOrderId);
		
		request.genOptinalURL("u.paychannelquerystatus.php", p);
		
		return (PayChannelQueryStatusResponse)request.send(true);
	}
	
	@Override
	public PayChannelMycardResponse payChannelMyCard(long userid,
			String cardId, String cardPwd, String gameOrderId, String userName,
			String roleid, String charName, String deviceType,
			String deviceVersion, String ip, String macInfo, String udid,
			String terminal) {
		
		PayChannelMycardRequest request = new PayChannelMycardRequest(config);
		Map<String,Object> p = new LinkedHashMap<String, Object>();
		p.put("currenttime", getCurrentTime());
		p.put("format", "JSON");
		p.put("ip", ip);
		p.put("userid", userid);
		p.put("cardId", cardId);
		p.put("cardPwd", cardPwd);
		p.put("gameOrderId", gameOrderId);
		p.put("userName", userName);
		p.put("roleid", roleid);
		p.put("charName", charName);
		p.put("deviceType", deviceType);
		p.put("deviceVersion", deviceVersion);
		p.put("macInfo", macInfo);
		p.put("udid", udid);
		p.put("terminal", terminal);
		request.genOptinalURL("u.paychannelmycard.php", p);
		return (PayChannelMycardResponse)request.send(true);
	}

	@Override
	public GenerateOrderResponse generateOrder(long userid, String userName,
			String roleid, String charName, String deviceType,
			String deviceVersion, String ip, String macInfo, String udid,
			String terminal) {
		
		GenerateOrderRequest request = new GenerateOrderRequest(config);
		Map<String,Object> p = new LinkedHashMap<String, Object>();
		p.put("currenttime", getCurrentTime());
		p.put("format", "JSON");
		p.put("userid", userid);
		p.put("userName", userName);
		p.put("roleid", roleid);
		p.put("charName", charName);
		p.put("deviceType", deviceType);
		p.put("deviceVersion", deviceVersion);
		p.put("ip", ip);
		p.put("macInfo", macInfo);
		p.put("udid", udid);
		p.put("terminal", terminal);		
		
		request.genOptinalURL("u.generateorder.php", p);
		
		return (GenerateOrderResponse) request.send(true);
	}
	
	@Override
	public GenerateOrderResponse generateOrder(long userid, String userName,
			String roleid, String charName, String deviceType,
			String deviceVersion, String ip, String macInfo, String udid,
			String terminal,String channelCode,String channelExt) {
		
		GenerateOrderRequest request = new GenerateOrderRequest(config);
		Map<String,Object> p = new LinkedHashMap<String, Object>();
		p.put("currenttime", getCurrentTime());
		p.put("format", "JSON");
		p.put("userid", userid);
		p.put("userName", userName);
		p.put("roleid", roleid);
		p.put("charName", charName);
		p.put("deviceType", deviceType);
		p.put("deviceVersion", deviceVersion);
		p.put("ip", ip);
		p.put("macInfo", macInfo);
		p.put("udid", udid);
		p.put("terminal", terminal);
		p.put("channelcode", channelCode);
		if(channelExt!=null) p.put("channelext", channelExt);
		
		request.genOptinalURL("u.generateorder.php", p);
		
		return (GenerateOrderResponse) request.send(true);
	}

	@Override
	public CaptchaSendResponse captchaSend(long userid, String cookie,String mobile, String ip) {
		
		CaptchaSendRequest request = new CaptchaSendRequest(config);
		Map<String,Object> p = new LinkedHashMap<String, Object>();
		p.put("userid", userid);
		p.put("cookie", cookie);
		p.put("mobile", mobile);
		p.put("ip", ip);
		p.put("format","JSON");
		
		request.genOptinalURL("u.captchasend.php", p);
		
		return (CaptchaSendResponse) request.send(true);
	}

	@Override
	public CaptchaCheckResponse captchaCheck(long userid, String cookie,String mobile, String captchacode, String ip) {
		
		CaptchaCheckRequest request = new CaptchaCheckRequest(config);
		Map<String,Object> p = new LinkedHashMap<String, Object>();
		p.put("userid", userid);
		p.put("cookie", cookie);
		p.put("captchacode",captchacode);
		p.put("mobile", mobile);
		p.put("ip", ip);
		p.put("format","JSON");
		
		request.genOptinalURL("u.captchacheck.php", p);
		
		return (CaptchaCheckResponse) request.send(true);
		
	}

	@Override
	public void getSurvey(long userId, Map<String, String> conditionMap,ICallback callback) {
		SurveyRequest request = new SurveyRequest(config);
		Map<String,Object> p = new LinkedHashMap<String, Object>();
		p.put("userid", userId);
		if(conditionMap!=null) p.putAll(conditionMap);
		
		request.genOptinalURL("u.getsurvey.php", p);
		request.asyncSend(true,callback);
	}


	
}
