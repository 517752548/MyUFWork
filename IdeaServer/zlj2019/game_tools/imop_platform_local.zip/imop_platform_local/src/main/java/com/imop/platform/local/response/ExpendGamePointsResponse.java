package com.imop.platform.local.response;

public class ExpendGamePointsResponse extends AbstractResponse {



	public ExpendGamePointsResponse(String[] args) {
		super(args, 5);
	}
	@Override
	public void onSuccess(String[] args) {
		orderid = args[1];
		userId = Long.valueOf(args[2]);
		money = Integer.valueOf(args[3]);
		if(args.length==5)
			type =args[4];
	}

	/**
	 * 接口调用方生成的订单流水号，默认为-1
	 */
	private String orderid = "-1";

	/**
	 * 玩家账号ID，默认为-1
	 */
	private long userId = -1;
	/**
	 * 充值成功金额，默认为0
	 */
	private long money = 0;
	
	/**
	 * 终端类型
	 */
	private String type="unknown";
	
	public String getOrderid() {
		return orderid;
	}
	
	public long getUserId() {
		return userId;
	}
	
	public long getMoney() {
		return money;
	}
	
	public String getType() {
		return type;
	}
}
