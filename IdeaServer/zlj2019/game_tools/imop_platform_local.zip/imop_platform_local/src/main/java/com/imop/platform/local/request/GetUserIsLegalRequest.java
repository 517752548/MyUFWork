package com.imop.platform.local.request;

import com.imop.platform.local.config.IConfig;
import com.imop.platform.local.response.GetUserIsLegalResponse;
import com.imop.platform.local.response.IResponse;

/**
 * 检测用户是否合法接口<br>
 * 接口功能：<br>
 * 提供检测用户是否合法功能。此接口为可选接口。
 * @author lu.liu
 *
 */
public class GetUserIsLegalRequest extends AbstractRequest {
	
	public GetUserIsLegalRequest(IConfig config){
		super(config);
		this.page = "u.getuserislegal.php" +
				"?timestamp=%s" +
				"&username=%s" +
				"&psw=%s&ip=%s" +
				"&areaid=%s" +
				"&serverid=%s" +
				"&sign=%s";
	}

	@Override
	public IResponse getResponse(String[] args) {
		return new GetUserIsLegalResponse(args);
	}
	@Override
	public void recordUrl(String uuid, String url){
		StringBuffer sb = new StringBuffer(url);
		sb.replace(sb.indexOf("psw=")+4, sb.indexOf("&", sb.indexOf("psw=")+4), "******");
		config.getRecord().recordInfo(uuid + "\t" + sb.toString());
	}

	@Override
	public void setParams(Object... objects) {
		long timestamp = getTimestamp();
		int areaId = config.getAreaId();
		int serverId = config.getServerId();
	
		String userName = objects[0].toString();
		String psw = objects[1].toString();
		String ip = objects[2].toString();
	
		String sign = getSign(timestamp,encodeUrl(userName),psw,ip,areaId,serverId);
		generateUrl(timestamp,userName,psw,ip,areaId,serverId,sign);
	}


}
