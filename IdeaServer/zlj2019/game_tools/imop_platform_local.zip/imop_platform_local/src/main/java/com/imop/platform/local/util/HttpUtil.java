package com.imop.platform.local.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.Proxy.Type;
import java.net.URL;

import com.imop.platform.local.config.IConfig;
import com.imop.platform.local.config.LocalConfig;

public class HttpUtil {
	
	private static final String CHARSET = "charset=";
	
	/**
	 * 获取指定地址的内容,如果能够从URLConnection中可以解析出编码则使用解析出的编码;否则就使用GBK编码
	 * 
	 * @param requestUrl
	 * @return
	 * @throws IOException
	 */
	public static String getUrl(String requestUrl,int timeout,boolean POST) throws IOException {
		BufferedReader reader = null;
		HttpURLConnection urlConnection = null;
		try {
			InputStream urlStream;
			String theURL = requestUrl;
			String params = "";
			if(POST) {
				int qIndex = requestUrl.indexOf("?");
				if(qIndex!=-1) {
					theURL = requestUrl.substring(0,qIndex);
					params = requestUrl.substring(qIndex+1,requestUrl.length());
				}
			}
			
			URL url = new URL(theURL);
			
//			Proxy proxy = new Proxy(Type.HTTP,new InetSocketAddress("127.0.0.1", 8888));
//			urlConnection = (HttpURLConnection) url.openConnection(proxy);
			urlConnection = (HttpURLConnection) url.openConnection();
			urlConnection.setConnectTimeout(timeout*1000);
			urlConnection.setReadTimeout(timeout*1000);
			urlConnection.addRequestProperty("LocalJarVersion", LocalConfig.getLocalJarVersion()==null?"Unknown":LocalConfig.getLocalJarVersion());
			
			if(POST) {
				urlConnection.setRequestMethod("POST");
				urlConnection.setDoOutput(true);
				OutputStream out = urlConnection.getOutputStream();
				out.write(params.getBytes("UTF-8"));
				out.flush();
			}
			urlConnection.connect();
			urlStream = urlConnection.getInputStream();
			reader = new BufferedReader(new InputStreamReader(urlStream,
					parseEncoding(urlConnection)));
			char[] _buff = new char[128];
			StringBuilder temp = new StringBuilder();
			int _len = -1;
			while ((_len = reader.read(_buff)) != -1) {
				temp.append(_buff, 0, _len);
			}
			return temp.toString();
		} catch (IOException e) {
			
			//判断出错信息，如果是login的URL请求，将密码隐掉
			String msg = e.getMessage();
			if(msg!=null) {
				msg = replacePSW(msg);
			}
			
			e.printStackTrace();
			throw e;
		} finally {
			try {
				if (reader != null) {
					reader.close();
				}
				urlConnection.disconnect();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	
	public static String replacePSW(String msg) {
		try {
			String pswstr = "&psw=";
			int pswIndex = msg.indexOf(pswstr);
			if(pswIndex==-1) {
				pswstr = "?psw=";
				pswIndex = msg.indexOf(pswstr);
			}
			if(pswIndex>0) {
				pswIndex += pswstr.length();
				int pswEnd = msg.indexOf("&",pswIndex);
				if(pswEnd==-1) {
					pswEnd = msg.length();
				}
				StringBuilder msg0 = new StringBuilder(msg.length()); 
				msg0.append(msg.substring(0,pswIndex));
				for(int i=0;i<(pswEnd-pswIndex);i++) {
					msg0.append("*");
				}
				msg0.append(msg.subSequence(pswEnd, msg.length()));
				msg = msg0.toString();
			}
			return msg;
		} catch (Exception e) {
			return msg;
		}
		
	}
	
//	public static void main(String [] args) {
//		try {
//			String page = getUrl("http://monitor/local/query2?gamecode=whsj&schemaid=2&duration=10000&rate=0&schemaname=bbbb&group1=gamecode&group2=api&ct=0.08666689260896487", 60, true);
//			System.out.println(page);
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//	}
	
	/**
	 * 尝试解析Http请求的编码格式,如果没有解析到则使用GBK编码(主要考虑到Local平台的返回编码是gb2312的)
	 * 
	 * @param urlConnection
	 * @return
	 */
	static String parseEncoding(HttpURLConnection urlConnection) {
		String _encoding = urlConnection.getContentEncoding();
		if (_encoding != null) {
			return _encoding;
		}
		String _contentType = urlConnection.getContentType();
		if (_contentType != null) {
			int _index = _contentType.toLowerCase().indexOf(CHARSET);
			if (_index > 0) {
				_encoding = _contentType.substring(_index + CHARSET.length());
			}
		}
		if (_encoding != null) {
			return _encoding;
		} else {
			return IConfig.URL_ENCODE;
		}
	}

}
