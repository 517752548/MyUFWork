package com.imop.platform.local.report;

import com.imop.platform.local.config.IConfig;
import com.imop.platform.local.request.AbstractRequest;

public abstract class AbstractReport extends AbstractRequest {

	public AbstractReport(IConfig config) {
		super(config);
		this.domain = config.getReportDomain();
	}

}
