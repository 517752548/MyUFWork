package com.imop.platform.local.response;

/**
 * 奖品领取扩展的请求结果
 * @author lu.liu
 *
 */
public class GetGoodsResponse extends AbstractResponse {

	/**
	 * 奖品ID，默认为-1
	 */
	private int prizeId = -1;

	public GetGoodsResponse(String[] args){
		super(args,2);
	}

	@Override
	public void onSuccess(String[] args) {
		prizeId = Integer.valueOf(args[1]);
	}
	
	/**
	 * 获取奖品ID
	 * @return	奖品ID
	 */
	public int getPrizeId() {
		return prizeId;
	}
	
}
