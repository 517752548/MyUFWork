package com.imop.platform.local.report;

import com.imop.platform.local.config.IConfig;
import com.imop.platform.local.response.IResponse;
import com.imop.platform.local.response.ReportResponse;

/**
 * 记录游戏贵重物品消耗接口<br>
 * 接口功能：<br>
 * 提供游戏中贵重物品消耗记录功能。贵重物品为与金钱相关的物品
 * @author lu.liu
 *
 */
public class TransRecordReport extends AbstractReport {
	
	public TransRecordReport(IConfig config){
		super(config);
		this.page = "u.transrecord.php" +
				"?timestamp=%s" +
				"&orderid=%s" +
				"&userid=%s" +
				"&roleid=%s" +
				"&money=%s" +
				"&goodsid=%s" +
				"&ip=%s" +
				"&areaid=%s" +
				"&serverid=%s" +
				"&sign=%s";
	}

	@Override
	public IResponse getResponse(String[] args) {
		return new ReportResponse(args);
	}

	@Override
	public void setParams(Object... objects) {
		long timestamp = getTimestamp();
		int areaId = config.getAreaId();
		int serverId = config.getServerId();
		
		String orderId = objects[0].toString();
		long userId = Long.valueOf(objects[1].toString());
		String roleId = objects[2].toString();
		int money = Integer.valueOf(objects[3].toString());
		String goodsId = objects[4].toString();
		String ip = objects[5].toString();
		
		String sign = getSign(timestamp,orderId,userId,roleId,money,goodsId,ip,areaId,serverId);
		generateUrl(timestamp,orderId,userId,roleId,money,goodsId,ip,areaId,serverId,sign);
	}

}
