package com.imop.platform.local.response;

/**
 * 获取人人用户信息的请求结果
 * @author lu.liu
 *
 */
public class GetUserInfoResponse extends AbstractResponse {

	/**
	 * 账号ID，默认为-1
	 */
	private long userId = -1;
	
	/**
	 * 帐号名，默认为null
	 */
	private String userName = null;
	
	/**
	 * 性别，默认为null
	 */
	private String gender = null;
	
	/**
	 * 教育背景，默认为null
	 */
	private String university = null;
	
	/**
	 * 住址，默认为null
	 */
	private String city = null;
	
	/**
	 * 小头像，默认为null
	 */
	private String tinyHeadUrl = null;
	
	/**
	 * 大头像，默认为null
	 */
	private String largeHeadUrl = null;
	
	/**
	 * 生日，默认为null
	 */
	private String birthday = null;
	
	public GetUserInfoResponse(String[] args) {
		super(args, 9);
	}

	@Override
	public void onSuccess(String[] args) {
		userId = Long.valueOf(args[1]);
		userName = args[2];
		gender = args[3];
		university = args[4];
		city = args[5];
		tinyHeadUrl = args[6];
		largeHeadUrl = args[7];
		birthday = args[8];
	}
	
	/**
	 * 获取账号ID
	 * @return	账号ID
	 */
	public long getUserId() {
		return userId;
	}
	
	/**
	 * 获取账号名
	 * @return	帐号名
	 */
	public String getUserName(){
		return userName;
	}
	
	/**
	 * 获取玩家性别
	 * @return	玩家性别
	 */
	public String getGender(){
		return gender;
	}
	
	/**
	 * 获取教育背景
	 * @return	教育背景
	 */
	public String getUniversity(){
		return university;
	}
	
	/**
	 * 获取所在城市
	 * @return	所在城市
	 */
	public String getCity(){
		return city;
	}
	
	/**
	 * 获取小头像
	 * @return	小头像
	 */
	public String getTinyHeadUrl(){
		return tinyHeadUrl;
	}
	
	/**
	 * 获取大头像
	 * @return	大头像
	 */
	public String getLargeHeadUrl(){
		return largeHeadUrl;
	}
	
	/**
	 * 获取玩家生日
	 * @return	玩家生日
	 */
	public String getBirthday(){
		return birthday;
	}

}
