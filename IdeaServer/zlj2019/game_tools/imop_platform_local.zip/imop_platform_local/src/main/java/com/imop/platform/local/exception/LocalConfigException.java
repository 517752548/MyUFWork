package com.imop.platform.local.exception;

public class LocalConfigException extends LocalException {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public LocalConfigException(String msg) {
		super("IMOP LOCAL 配置异常：" + msg);
	}
	
}
