package com.imop.platform.local.request;

import com.imop.platform.local.config.IConfig;
import com.imop.platform.local.response.IResponse;
import com.imop.platform.local.response.QueryBalanceResponse;

/**
 * 游戏世界余额查询接口<br>
 * 接口功能：<br>
 * 提供给游戏在平台内查询玩家账户余额的功能。
 * @author lu.liu
 *
 */
public class QueryBalanceRequest extends AbstractRequest {

	public QueryBalanceRequest(IConfig config){
		super(config);
		this.page = "u.querybalance.php" +
				"?timestamp=%s" +
				"&userid=%s" +
				"&ip=%s" +
				"&areaid=%s" +
				"&serverid=%s" +
				"&sign=%s" ;
	}

	@Override
	public IResponse getResponse(String[] args) {
		return new QueryBalanceResponse(args);
	}

	@Override
	public void setParams(Object... objects) {
		long timestamp = getTimestamp();
		int areaId = config.getAreaId();
		int serverId = config.getServerId();
		
		long userId = Long.valueOf(objects[0].toString());
		String ip = objects[1].toString();
		
		String sign = getSign(timestamp,userId,ip);
		generateUrl(timestamp,userId,ip,areaId,serverId,sign);
		
	}

}
