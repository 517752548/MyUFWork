package com.imop.platform.local.response;

import net.sf.json.JSONObject;

public class IOSRechargeResponse extends AbstractResponse {

	private int status;
	private String transaction_id;
	private String product_id;

	
	public IOSRechargeResponse(String[] args) {
		super(args, 2);
	}

	@Override
	public void onSuccess(String[] args) {
		String json_str = args[1].toString();
		JSONObject json_temp = JSONObject.fromObject(json_str);		
		this.status = Integer.parseInt(getJsonValue(json_temp, "status"));
		this.transaction_id = getJsonValue(json_temp, "transaction_id");
		this.product_id = getJsonValue(json_temp, "product_id");
	}

	public int getStatus() {
		return status;
	}

	public String getTransaction_id() {
		return transaction_id;
	}

	public String getProduct_id() {
		return product_id;
	}
	

}
