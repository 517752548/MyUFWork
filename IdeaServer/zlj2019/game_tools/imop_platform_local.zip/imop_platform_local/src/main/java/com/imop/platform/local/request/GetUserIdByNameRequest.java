package com.imop.platform.local.request;

import com.imop.platform.local.config.IConfig;
import com.imop.platform.local.response.GetUserIdByNameResponse;
import com.imop.platform.local.response.IResponse;

/**
 * 通过用户名称获取用户id接口<br>
 * 接口功能：<br>
 * 提供通过用户的名称获取用户id的功能。此接口为可选接口。
 * @author lu.liu
 *
 */
public class GetUserIdByNameRequest extends AbstractRequest {
	
	public GetUserIdByNameRequest(IConfig config){
		super(config);
		this.page = "u.getuseridbyname.php" +
				"?timestamp=%s" +
				"&username=%s" +
				"&ip=%s" +
				"&areaid=%s" +
				"&serverid=%s" +
				"&sign=%s";
	}

	@Override
	public IResponse getResponse(String[] args) {
		return new GetUserIdByNameResponse(args);
	}

	@Override
	public void setParams(Object... objects) {
		long timestamp = getTimestamp();
		int areaId = config.getAreaId();
		int serverId = config.getServerId();
		
		String userName = objects[0].toString();
		String ip = objects[1].toString();
		
		String sign = getSign(timestamp,encodeUrl(userName),ip,areaId,serverId);
		generateUrl(timestamp,userName,ip,areaId,serverId,sign);
	}

}
