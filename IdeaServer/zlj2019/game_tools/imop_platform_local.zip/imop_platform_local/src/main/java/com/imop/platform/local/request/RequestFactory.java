package com.imop.platform.local.request;

import com.imop.platform.local.config.IConfig;
import com.imop.platform.local.config.LocalConfig;
import com.imop.platform.local.report.OnlineReport;
import com.imop.platform.local.report.PropsStatusReport;
import com.imop.platform.local.report.ReportGmLargessReport;
import com.imop.platform.local.report.ReportPlayerReport;
import com.imop.platform.local.report.StatusReport;
import com.imop.platform.local.report.TransRecordReport;

public class RequestFactory {

	public static IRequest createAddRoleReportRequest(IConfig config){
		return new AddRoleReportRequest(config);
	}
	
	public static IRequest createOauthLoginRequest(IConfig config){
		return new OauthLoginRequest(config);
	}
	
	public static IRequest createDelRoleReportRequest(IConfig config){
		return new DelRoleReportRequset(config);
	}
	
	public static IRequest createLoginRequest(IConfig config){
		return new LoginRequest(config);
	}
	public static IRequest createGetUserIdByChannelNameRequest(IConfig config)
	{
		return new GetUserIdByChannelNameRequest(config);
	}
	
	public static IRequest createLogoutRequest(IConfig config){
		return new LogoutRequest(config);
	}
	public static IRequest createActiveUseCodeRequest(IConfig config){
		return new ActiveUseCodeRequest(config);
	}
	public static IRequest createTransferRequest(IConfig config){
		return new TransferRequest(config);
	}
	
	public static IRequest createQueryBalanceRequest(IConfig config){
		return new QueryBalanceRequest(config);
	}
	
	public static IRequest createOnlineReport(IConfig config){
		return new OnlineReport(config);
	}
	
	public static IRequest createQueryGoodsRequest(IConfig config){
		return new QueryGoodsRequest(config);
	}
	
	public static IRequest createGetGoodsRequest(IConfig config){
		return new GetGoodsRequest(config);
	}
	
	public static IRequest createStatusReport(IConfig config){
		return new StatusReport(config);
	}
	
	public static IRequest createTransRecordReport(IConfig config){
		return new TransRecordReport(config);
	}
	
	public static IRequest createGmLoginRequest(IConfig config){
		return new GmLoginRequest(config);
	}
	
	public static IRequest createGetUserNameByIdRequest(IConfig config){
		return new GetUserNameByIdRequest(config);
	}
	
	public static IRequest createGetUserIdByNameRequest(IConfig config){
		return new GetUserIdByNameRequest(config);
	}
	
	public static IRequest createGetUserIsLegalRequest(IConfig config){
		return new GetUserIsLegalRequest(config);
	}
	
	public static IRequest createQueryOnlineTimeRequest(IConfig config){
		return new QueryOnlineTimeRequest(config);
	}
	
	public static IRequest createReportPlayerReport(IConfig config){
		return new ReportPlayerReport(config);
	}
	
	public static IRequest createReportGmLargessReport(IConfig config){
		return new ReportGmLargessReport(config);
	}
	
	public static IRequest createPropsStatusReport(IConfig config){
		return new PropsStatusReport(config);
	}
	
	public static IRequest createGetUserInfoRequest(IConfig config){
		return new GetUserInfoRequest(config);
	}
	
	public static IRequest createGetUserIdByNickNameRequest(IConfig config){
		return new GetUserIdByNickNameRequest(config);
	}
	
	public static IRequest createGetNickNameRequest(IConfig config){
		return new GetNickNameRequest(config);
	}
	
	public static IRequest createGetVersionRequest(IConfig config){
		return new GetVersionRequest(config);
	}
	
	public static IRequest createAddWallowInfoRequest(IConfig config){
		return new AddWallowInfoRequest(config);
	}
	
	public static IRequest createGetGameUserInfoRequest(IConfig config){
		return new GetGameUserInfoRequest(config);
	}
	
	public static IRequest createGetFriendsListRequest(IConfig config){
		return new GetFriendsListRequest(config);
	}
	
	public static IRequest createAddattentionRequest(IConfig config){
		return new AddAttentionRequest(config);
	}
	
	public static IRequest createCreateLinkRequest(IConfig config){
		return new CreateLinkRequest(config);
	}
	public static IRequest createGetUserBirthdayRequset(LocalConfig config) {
		// TODO Auto-generated method stub
		return new GetUserBirthdayRequest(config);
	}
	public static IRequest createExpendGamePointsRequest(LocalConfig config) {
		// TODO Auto-generated method stub
		return new ExpendGamePointsRequest(config);
	}
	public static IRequest createGetNGWordRequest(LocalConfig config) {
		// TODO Auto-generated method stub
		return new GetNGWordRequest(config);
	}
	public static IRequest createGetFCMTimeRequest(LocalConfig config) {
		// TODO Auto-generated method stub
		return new GetFCMTimeRequest(config);
	}
	public static IRequest createCreateIOSPaymentRequest(LocalConfig config) {
		// TODO Auto-generated method stub
		return new CreateIOSPaymentRequest(config);
	}
	public static IRequest createExpendIOSPaymentRequest(LocalConfig config) {
		// TODO Auto-generated method stub
		return new ExpendIOSPaymentRequest(config);
	}
	public static IRequest createIsBlackListUserRequest(LocalConfig config) {
		// TODO Auto-generated method stub
		return new IsBlackListUserRequest(config);
	}
	
	public static IRequest createExchangeRechargeRequest(LocalConfig config) {
		// TODO Auto-generated method stub
		return new ExchangeRechargeRequest(config);
	}
	
	public static IRequest createQueryRechargeRequest(LocalConfig config) {
		// TODO Auto-generated method stub
		return new QueryRechargeRequest(config);
	}
	public static IRequest createIOSRechargeRequest(LocalConfig config) {
		// TODO Auto-generated method stub
		return new IOSRechargeRequest(config);
	}
	public static IRequest createThirdActivitiesCodeRequest(LocalConfig config) {
		// TODO Auto-generated method stub
		return new ThirdActivitiesCodeRequest(config);
	}
	public static IRequest createQuickLogin(LocalConfig config) {
		// TODO Auto-generated method stub
		return new QuickLoginRequest(config);
	}
	public static IRequest createTransferReport(LocalConfig config) {
		// TODO Auto-generated method stub
		return new TransferReportRequest(config);
	}
}
