package com.imop.platform.local.config;

import java.util.concurrent.ExecutorService;

import com.imop.platform.local.exception.LocalException;
import com.imop.platform.local.record.IRecord;

/**
 * 系统配置接口
 * @author lu.liu
 *
 */
public interface IConfig {
	
	/**
	 * 配置文件名
	 */
	String LOCAL_CFG_FILE = "local_cfg.xml";
	
	/**
	 * 平台接口内部实现的slf4j日志记录工具名字
	 */
	String LOCAL_LOGGER_NAME = "local";
	
	/**
	 * 配置文件游戏配置节点
	 */
	String LOCAL_GAMEINFO_ELEMENT = "game_info";
	
	/**
	 * 超时时间配置
	 */
	String LOCAL_CONFIG_TIMEOUT = "timeout";
	
	/**
	 * 线程池大小配置
	 */
	String LOCAL_CONFIG_THREADNUM = "thread_num";
	
	/**
	 * 游戏唯一key配置
	 */
	String LOCAL_CONFIG_GAMEKEY = "game_key";
	
	/**
	 * 请求域名配置
	 */
	String LOCAL_CONFIG_REQUESTDOMAIN = "request_domain";
	
	/**
	 * 汇报域名配置
	 */
	String LOCAL_CONFIG_REPORTDOMAIN = "report_domain";
	
	/**
	 * 平台返回"ok"
	 */
	String OK = "ok";
	
	/**
	 * 平台返回"fail"
	 */
	String FAIL = "fail";
	
	/**
	 * ":"分隔符
	 */
	String RESULT_SPLIT = ":";
	
	/**
	 * 返回值最短长度
	 */
	int RESULT_LENGTH_MIN = 2;
	
	/**
	 * URL编码
	 */
	String URL_ENCODE = "UTF-8";
	
	/**
	 * "|"分隔符
	 */
	String SPLIT_VERTICAL = "\\|";
	
	/**
	 * "-"分隔符
	 */
	String SPLIT_STRIPING = "-";

	/**
	 * 系统初始化
	 * @throws LocalException
	 */
	public void initlize() throws LocalException;
	
	/**
	 * 获取日志记录类
	 * @return	日志记录器
	 */
	public IRecord getRecord();
	
	/**
	 * 获取异步线程池
	 * @return	线程池
	 */
	public ExecutorService getReportService();
	
	/**
	 * 获取请求域名
	 * @return	请求域名
	 */
	public String getRequestDomain();
	
	/**
	 * 获取汇报域名
	 * @return	汇报域名
	 */
	public String getReportDomain();
	
	/**
	 * 获取游戏唯一KEY
	 * @return	游戏唯一KEY
	 */
	public String getGameKey();
	
	/**
	 * 获取超时时间
	 * @return	超时时间
	 */
	public int getTimeout();
	
	/**
	 * 设置异步线程池
	 * @param reportService	线程池
	 */
	public void setReportService(ExecutorService reportService);
	
	/**
	 * 获取大区ID
	 * @return	大区ID
	 */
	public int getAreaId();
	
	/**
	 * 获取服务器ID
	 * @return	服务器ID
	 */
	public int getServerId();
	
	/**
	 * 获取游戏域名
	 * @return	游戏域名
	 */
	public String getDomain();
	
	/**
	 * 设置游戏code
	 * @param code	游戏code
	 */
	public String getGamecode();

	/**
	 * 设置游戏的Platformid
	 * @param  Platformid	游戏的Platformid
	 */
	public String getPlatformid();
	
}
