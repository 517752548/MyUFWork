package com.imop.platform.local.request;

import com.imop.platform.local.config.IConfig;
import com.imop.platform.local.response.IOSRechargeResponse;
import com.imop.platform.local.response.IResponse;

public class IOSRechargeRequest extends AbstractRequest {

	public IOSRechargeRequest(IConfig config) {
		super(config);
		this.page="u.iosrecharge.php?" +
				"timestamp=%s" +
				"&userid=%s" +
				"&roleid=%s" +
				"&item_table=%s" +
				"&token=%s" +
				"&ip=%s" +
				"&areaid=%s" +
				"&serverid=%s" +
				"&udid=%s" +
				"&amount=%s" + 
				"&itemId=%s" +
				"&itemName=%s" +
				"&coin=%s" +
				"&macInfo=%s" +
				"&userName=%s" +
				"&charName=%s" +
				"&deviceType=%s"+
				"&deviceVersion=%s";		
	}

	@Override
	public IResponse getResponse(String[] args) {
		// TODO Auto-generated method stub
		return new IOSRechargeResponse(args);
	}

	@Override
	public void setParams(Object... objects) {
		long timestamp = getTimestamp();
		Long userid = Long.valueOf(objects[0].toString());
		String roleId = objects[1].toString();
		String item_table = objects[2].toString();
		String token = objects[8].toString();	
		String ip = objects[9].toString();
		int areaId = config.getAreaId();
		int serverId = config.getServerId();
		String udid = objects[11].toString();
		String amount=objects[3].toString();
		String itemId=objects[4].toString();
		String itemName=objects[5].toString();
		long coin=Long.valueOf(objects[6].toString());
		String macInfo=objects[7].toString();
		String userName=objects[12].toString();
		String charName=objects[13].toString();
		String deviceType=objects[14].toString();
		String deviceVersion=objects[15].toString();
		getUrl(timestamp,userid,roleId,item_table,token,ip,areaId,serverId,udid,amount,itemId,itemName,coin,macInfo,userName,charName,deviceType,deviceVersion);

	}

}
