package com.imop.platform.local.response;

public class GetGameUserInfoResponse extends AbstractResponse {
	
	private boolean wallowFill;

	public GetGameUserInfoResponse(String[] args) {
		super(args, 2);
	}

	@Override
	public void onSuccess(String[] args) {
		wallowFill = (Integer.valueOf(args[1]) == 1);
	}
	
	public boolean isWallowFill() {
		return wallowFill;
	}
	
	public void setWallowFill(boolean wallowFill) {
		this.wallowFill = wallowFill;
	}

}
