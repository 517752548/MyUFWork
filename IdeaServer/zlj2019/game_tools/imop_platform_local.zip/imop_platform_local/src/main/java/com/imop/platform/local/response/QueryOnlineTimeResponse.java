package com.imop.platform.local.response;

/**
 * 获取用户登录千橡游戏累计时间的请求结果
 * @author lu.liu
 *
 */
public class QueryOnlineTimeResponse extends AbstractResponse {
	
	/**
	 * 账号ID，默认为-1
	 */
	private long userId = -1;
	
	/**
	 * 在线时长，默认为-1
	 */
	private long onlineTime = -1;
	
	public QueryOnlineTimeResponse(String[] args){
		super(args, 3);
	}

	@Override
	public void onSuccess(String[] args) {
		userId = Long.valueOf(args[1]);
		onlineTime =  Long.valueOf(args[2]);
	}
	
	/**
	 * 获取账号ID
	 * @return	账号ID
	 */
	public long getUserId(){
		return userId;
	}
	
	/**
	 * 获取在线时间
	 * @return	在线时间
	 */
	public long getOnlineTime(){
		return onlineTime;
	}
	
}
