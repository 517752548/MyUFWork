package com.imop.platform.local.request;

import java.text.SimpleDateFormat;
import java.util.Date;

import net.sf.json.JSONObject;

import com.imop.platform.local.bean.ReportForDGBean;
import com.imop.platform.local.config.IConfig;
import com.imop.platform.local.response.IResponse;
import com.imop.platform.local.response.QuickLoginResponse;

public class QuickLoginRequest extends AbstractRequest {

	public QuickLoginRequest(IConfig config) {
		super(config);
		this.page="u.quicklogin.php" +
				"?timestamp=%s" +
				"&ip=%s" +
				"&areaid=%s" +
				"&serverid=%s" +
				"&uuid=%s" +
				"&promotionCode=%s" +
				"&dataext=%s";
	}

	@Override
	public IResponse getResponse(String[] args) {
		return new QuickLoginResponse(args);
	}

	@Override
	public void setParams(Object... objects) {
		long timestamp = getTimestamp();
		String ip =  objects[0].toString();
		int areaid = config.getAreaId();
		int serverid = config.getServerId();
		String uuid = objects[2].toString();
		String promotionCode = objects[3].toString();
		
		ReportForDGBean bean = (ReportForDGBean) objects[4];
		long date= System.currentTimeMillis()/1000;
		//System.out.println(date);
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		java.util.Calendar cal = java.util.Calendar.getInstance();   
	    cal.setTime(new Date(date*1000));
		int zoneOffset = cal.get(java.util.Calendar.ZONE_OFFSET);   
		int dstOffset = cal.get(java.util.Calendar.DST_OFFSET);    
		cal.add(java.util.Calendar.MILLISECOND, -(zoneOffset + dstOffset)); 
		String nowTime = df.format(new Date(date*1000));
		String utcTime = df.format(cal.getTime());
		bean.complement(timestamp*1000, utcTime, nowTime, config.getGamecode(), config.getPlatformid(), ""+areaid,""+serverid, config.getDomain());
		
		getUrl(timestamp,ip,areaid,serverid,uuid,promotionCode,JSONObject.fromObject(bean).toString());
	}

}
