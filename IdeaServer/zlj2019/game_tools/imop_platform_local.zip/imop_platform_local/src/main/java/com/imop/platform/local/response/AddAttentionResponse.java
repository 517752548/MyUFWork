package com.imop.platform.local.response;

public class AddAttentionResponse extends AbstractResponse {
	
	private int result;

	public AddAttentionResponse(String[] args) {
		super(args, 2);
	}

	@Override
	public void onSuccess(String[] args) {
		result = Integer.valueOf(args[1]);
	}

	public int getResult(){
		return result;
	}
}
