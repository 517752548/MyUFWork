﻿//---------------------------------------
// Copyright (c) 2011-2018 Peter Schraut
// http://console-dev.de
//---------------------------------------

using System;
using UnityEditor;
using EditorFramework;

namespace TextureOverview
{
    public static class Globals
    {
        #region ProductVersionNumber
        /// <summary>
        /// The product version number, eg "24".
        /// </summary>
        public static int ProductVersionNumber
        {
            get
            {
                return 47;
            }
        }

        public static bool IsBeta
        {
            get
            {
                return false;
            }
        }
        #endregion

        #region MinimumVersion
        /// <summary>
        /// Gets the minimum required Unity version to run this plugin.
        /// </summary>
        public static int MinimumMajorVersion
        {
            get
            {
#if UNITY_2018_OR_NEWER
                return 2018;
#elif UNITY_2017_OR_NEWER
                return 2017;
#elif UNITY_5_OR_NEWER
                return 5;
#else
                return 4;
#endif
            }
        }

        /// <summary>
        /// Gets the minimum required Unity version to run this plugin.
        /// </summary>
        public static int MinimumMinorVersion
        {
            get
            {
#if UNITY_2018_2_OR_NEWER
                return 2;
#elif UNITY_2018_OR_NEWER
                return 1;
#elif UNITY_2017_3_OR_NEWER
                return 3;
#elif UNITY_2017_2_OR_NEWER
                return 2;
#elif UNITY_2017_OR_NEWER
                return 1;
#elif UNITY_5_6_OR_NEWER
                return 6;
#elif UNITY_5_5_OR_NEWER
                return 5;
#elif UNITY_5_OR_NEWER
                return 0;
#else
                if (EditorApplication2.MajorVersion == 5)
                    return 0;

                // 4.3
                return 3;
#endif
            }
        }
        #endregion

        #region ProductTitle
        /// <summary>
        /// The title of the product, eg "Texture Overview 2.4"
        /// </summary>
        public static string ProductTitle
        {
            get;
            private set;
        }
        #endregion

        #region ProductName
        /// <summary>
        /// The name of the product, without version information.
        /// </summary>
        public static string ProductName
        {
            get
            {
                return "Texture Overview";
            }
        }
        #endregion

        #region ProductId
        /// <summary>
        /// A code-friendly name of the product. Used as key to store settings to EditorPrefs for example.
        /// </summary>
        public static string ProductId
        {
            get
            {
#if UNITY_5_5_OR_NEWER
                return "TextureOverview_v2";
#else
                return "TextureOverview";
#endif
            }
        }
        #endregion

        #region ProductAssetStoreUrl
        /// <summary>
        /// The link to the product in the Unity asset store.
        /// </summary>
        public static string ProductAssetStoreUrl
        {
            get
            {
                if (IsPro)
                    return "https://www.assetstore.unity3d.com/#/content/10832";

                return "https://www.assetstore.unity3d.com/en/#!/content/16937";
            }
        }
        #endregion

        #region ProductFeedbackUrl
        /// <summary>
        /// The URL to the texture overview forum thread.
        /// </summary>
        public static string ProductFeedbackUrl
        {
            get
            {
                return "http://forum.unity3d.com/threads/197707-Released-Texture-Overview-Plugin";
            }
        }
        #endregion

        #region GpuExpandRgb24ToRgba32
        static int _gpuExpandRgb24ToRgba32 = -1; // -1=uninitialized, 0=false, 1=true

        /// <summary>
        /// Gets whether GPU memory calculations for RGB24 should be handled as those texture were RGBA32.
        /// </summary>
        /// <remarks>
        /// This is actually how any/most GPUs work.
        /// 
        /// See R8G8B8 column here (not supported at all):
        /// http://zp.amsnet.pl/cdragan/query.php?dxversion=9&feature=formats&featuregroup=all&adaptergroup=all&resource=TEXTURE&usage=PLAIN&orientation=horizontal
        /// 
        /// Also see RGB24 vs RGB32 memory usage thread:
        /// https://groups.google.com/forum/#!topic/unity-beta-testing/IFth1v8_vIE
        /// </remarks>
        public static bool GpuExpandRgb24ToRgba32
        {
            get
            {
                if (_gpuExpandRgb24ToRgba32 == -1)
                    _gpuExpandRgb24ToRgba32 = EditorPrefs.GetBool(string.Format("{0}.GpuExpandRgb24ToRgba32", Globals.ProductId), true) ? 1 : 0;
                return _gpuExpandRgb24ToRgba32 > 0;
            }
            set
            {
                var ivalue = value ? 1 : 0;
                if (ivalue != _gpuExpandRgb24ToRgba32)
                {
                    _gpuExpandRgb24ToRgba32 = ivalue;
                    EditorPrefs.SetBool(string.Format("{0}.GpuExpandRgb24ToRgba32", Globals.ProductId), value);
                }
            }
        }
        #endregion

        #region CountRenderer
        static int _countRenderer = -1;

        /// <summary>
        /// Gets whether Texture Overview should count how often a
        /// texture is referenced by a Renderer when being in Scene mode.
        /// </summary>
        public static bool CountRendererInSceneMode
        {
            get
            {
                if (_countRenderer == -1)
                    _countRenderer = EditorPrefs.GetBool(string.Format("{0}.CountRenderer", Globals.ProductId), true) ? 1 : 0;

                return _countRenderer > 0;
            }
            set
            {
                var ivalue = value ? 1 : 0;
                if (ivalue != _countRenderer)
                {
                    _countRenderer = ivalue;
                    EditorPrefs.SetBool(string.Format("{0}.CountRenderer", Globals.ProductId), value);
                }
            }
        }
        #endregion

        #region CountRenderer
        static int _showEditorAssets = -1;

        /// <summary>
        /// Gets whether Texture Overview should show textures that are located in an editor directory.
        /// </summary>
        public static bool ShowEditorAssets
        {
            get
            {
                if (_showEditorAssets == -1)
                    _showEditorAssets = EditorPrefs.GetBool(string.Format("{0}.ShowEditorAssets", Globals.ProductId), false) ? 1 : 0;

                return _showEditorAssets > 0;
            }
            set
            {
                var ivalue = value ? 1 : 0;
                if (ivalue != _showEditorAssets)
                {
                    _showEditorAssets = ivalue;
                    EditorPrefs.SetBool(string.Format("{0}.ShowEditorAssets", Globals.ProductId), value);
                }
            }
        }

        static int _showPackageAssets = -1;
        public static bool ShowPackageAssets
        {
            get
            {
                if (_showPackageAssets == -1)
                    _showPackageAssets = EditorPrefs.GetBool(string.Format("{0}.ShowPackageAssets", Globals.ProductId), true) ? 1 : 0;

                return _showPackageAssets > 0;
            }
            set
            {
                var ivalue = value ? 1 : 0;
                if (ivalue != _showPackageAssets)
                {
                    _showPackageAssets = ivalue;
                    EditorPrefs.SetBool(string.Format("{0}.ShowPackageAssets", Globals.ProductId), value);
                }
            }
        }
        #endregion

        #region IsPro
        static int _IsPro = -1;

        public static bool IsPro
        {
            get
            {
                if (_IsPro == -1)
                {
                    var path = EditorApplication2.CombinePluginPath("TextureOverviewSource.zip");
                    _IsPro = System.IO.File.Exists(path) ? 1 : 0;
                }

                return _IsPro > 0;
            }
        }
        #endregion

        #region cctor
        static Globals()
        {
            ProductTitle = string.Format("{0} {1:F1}{2}", ProductName, ProductVersionNumber / 10.0f, IsBeta ? " beta":"");
        }
        #endregion
    }
}
