﻿//---------------------------------------
// Copyright (c) 2011-2014 Peter Schraut
// http://console-dev.de
//---------------------------------------

using System;
using System.Reflection;
using UnityEngine;
using UnityEditor;

namespace EditorFramework
{
    /// <summary>
    /// BuildPipeline2 provides helper methods to get information about build pipeline specifics.
    /// </summary>
    /// <remarks>
    /// Most BuildPipeline2 methods are actually available in UnityEditor.BuildPipeline, but
    /// they are not public in there. BuildPipeline2 is basically a wrapper to get access to those hidden methods.
    /// </remarks>
    public static class BuildPipeline2
    {
        #region Private Fields
        static MethodInfo _getBuildTargetGroup;
        static MethodInfo _getBuildTargetGroupName;
        static MethodInfo _getBuildTargetGroupDisplayName;
        #endregion

        #region ctor
        static BuildPipeline2()
        {
            _getBuildTargetGroup = typeof(BuildPipeline).GetMethod("GetBuildTargetGroup", BindingFlags.Static | BindingFlags.NonPublic | BindingFlags.Public, null, new[] { typeof(BuildTarget) }, null);
            _getBuildTargetGroupName = typeof(BuildPipeline).GetMethod("GetBuildTargetGroupName", BindingFlags.Static | BindingFlags.NonPublic, null, new[] { typeof(BuildTarget) }, null);
            _getBuildTargetGroupDisplayName = typeof(BuildPipeline).GetMethod("GetBuildTargetGroupDisplayName", BindingFlags.Static | BindingFlags.NonPublic, null, new[] { typeof(BuildTargetGroup) }, null);

            if (null == _getBuildTargetGroup)
                Debug.LogWarning("Could not find method 'UnityEditor.BuildPipeline.GetBuildTargetGroup(BuildTarget)'.");

            if (null == _getBuildTargetGroupName)
                Debug.LogWarning("Could not find method 'UnityEditor.BuildPipeline.GetBuildTargetGroupName(BuildTarget)'.");

            if (null == _getBuildTargetGroupDisplayName)
                Debug.LogWarning("Could not find method 'UnityEditor.BuildPipeline.GetBuildTargetGroupDisplayName(BuildTargetGroup)'.");
        }
        #endregion

        #region GetBuildTargetGroup
        /// <summary>
        /// Gets the BuildTargetGroup of the specified buildtarget.
        /// </summary>
        /// <example>
        /// For example, BuildTarget.StandaloneWindows and BuildTarget.StandaloneLinux are
        /// both in the BuildTargetGroup.Standalone build target group.
        /// </example>
        /// <param name="buildtarget">The BuildTarget.</param>
        /// <returns>The BuildTargetGroup on success, BuildTargetGroup.Unknown otherwise.</returns>
        public static BuildTargetGroup GetBuildTargetGroup(BuildTarget buildtarget)
        {
            if (null == _getBuildTargetGroup)
                return BuildTargetGroup.Unknown;

            var args = new object[] { buildtarget };
            return (BuildTargetGroup)_getBuildTargetGroup.Invoke(null, args);
        }
        #endregion

        #region GetBuildTargetGroupName
        /// <summary>
        /// Gets the build target group name of the specifid buildtarget.
        /// </summary>
        /// <param name="buildtarget">The BuildTarget.</param>
        /// <returns>The name of the build target group on success, an empty string otherwise.</returns>
        public static string GetBuildTargetGroupName(BuildTarget buildtarget)
        {
            if (null == _getBuildTargetGroupName)
                return "";

            var args = new object[] { buildtarget };
            return _getBuildTargetGroupName.Invoke(null, args) as string ?? "";
        }
        #endregion

        #region GetBuildTargetGroupDisplayName
        /// <summary>
        /// Gets the display name of the specified build target group.
        /// These are the names displayed in the unity build settings window, eg 'PC, Mac & Linux Standalone'.
        /// </summary>
        /// <param name="group">The group.</param>
        /// <returns>The name on success, an empty string otherwise.</returns>
        public static string GetBuildTargetGroupDisplayName(BuildTargetGroup group)
        {
            if (null == _getBuildTargetGroupDisplayName)
                return "";

            if (group == BuildTargetGroup.Unknown)
                return "Default";

            var args = new object[] { group };
            return _getBuildTargetGroupDisplayName.Invoke(null, args) as string ?? "";
        }
        #endregion

        #region GetBuildTargetGroupImage
        /// <summary>
        /// Gets the icon for the specified build target group.
        /// These are the icons displayed in the unity build settings window.
        /// </summary>
        /// <param name="group">The group.</param>
        /// <returns>The texture on success, null otherwise.</returns>
        public static Texture GetBuildTargetGroupImage(BuildTargetGroup group)
        {
            var platforms = BuildPlayerWindow2.GetValidPlatforms();
            foreach (var platform in platforms)
            {
                if (platform.TargetGroup == group)
                    return platform.Image;
            }
            return null;
        }
        #endregion
    }
}
