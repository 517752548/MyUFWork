﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using UnityEngine;

[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Peter Schraut")]
[assembly: AssemblyProduct("TextureOverview")]
[assembly: AssemblyCopyright("Copyright 2011-2018 Peter Schraut")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: AssemblyVersion("1.0.*")]

#if UNITY_2018_2_OR_NEWER
[assembly: AssemblyTitle("Texture Overview for Unity 2018.2")]
[assembly: Guid("1aee4996-3920-45f8-9198-126b1d3ca627")]
[assembly: AssemblyIsEditorAssembly]
#elif UNITY_2018_1_OR_NEWER
[assembly: AssemblyTitle("Texture Overview for Unity 2018.1")]
[assembly: Guid("aa5f1201-1879-401e-b7dd-5405b7d9714a")]
[assembly: AssemblyIsEditorAssembly]
#elif UNITY_2017_3_OR_NEWER
[assembly: AssemblyTitle("Texture Overview for Unity 2017.3")]
[assembly: Guid("0c437882-71e8-4655-8c06-2b21109cf58a")]
[assembly: AssemblyIsEditorAssembly]
#elif UNITY_2017_2_OR_NEWER
[assembly: AssemblyTitle("Texture Overview for Unity 2017.2")]
[assembly: Guid("057f0bf9-0570-448d-8e72-d043aaf107b3")]
[assembly: AssemblyIsEditorAssembly]
#elif UNITY_2017_OR_NEWER
[assembly: AssemblyTitle("Texture Overview for Unity 2017.1")]
[assembly: Guid("b3fa38e0-4cf1-420b-a65a-e14e7edb8ec0")]
[assembly: AssemblyIsEditorAssembly]
#elif UNITY_5_6_OR_NEWER
[assembly: AssemblyTitle("Texture Overview for Unity 5.6")]
[assembly: Guid("072a2a0e-dece-429a-a5f7-591091e15390")]
[assembly: AssemblyIsEditorAssembly]
#elif UNITY_5_5_OR_NEWER
[assembly: AssemblyTitle("Texture Overview for Unity 5.5")]
[assembly: Guid("0f642f7f-a1d3-4a4b-8b14-2f8e9447d3fa")]
[assembly: AssemblyIsEditorAssembly]
#elif UNITY_5
[assembly: AssemblyTitle("Texture Overview for Unity 5.0")]
[assembly: Guid("ab4681f7-37ea-44f2-9a7e-7572fa544cec")]
[assembly: AssemblyIsEditorAssembly]
#else
[assembly: AssemblyTitle("TextureOverview for Unity 4.3")]
[assembly: Guid("eec47972-a007-472a-9f94-ee246a92b692")]
#endif
