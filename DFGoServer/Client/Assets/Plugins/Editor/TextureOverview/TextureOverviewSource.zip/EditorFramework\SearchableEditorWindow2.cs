﻿//---------------------------------------
// Copyright (c) 2014 Peter Schraut
// http://console-dev.de
//---------------------------------------

using System.Reflection;
using UnityEngine;
using UnityEditor;

namespace EditorFramework
{
    /// <summary>
    /// SearchableEditorWindow2 provides helper methods to access non-public methods in SearchableEditorWindow.
    /// </summary>
    /// <remarks>
    public static class SearchableEditorWindow2
    {
        #region Private Fields
        static FieldInfo _m_HierarchyType; // HierarchyType m_HierarchyType
        static FieldInfo _m_HasSearchFilterFocus; // bool m_HasSearchFilterFocus
        static FieldInfo _searchableWindows; // List<SearchableEditorWindow>
        static MethodInfo _setSearchFilter; // internal virtual void SetSearchFilter(string searchFilter, SearchMode searchMode, bool setAll);
        #endregion

        #region ctor
        static SearchableEditorWindow2()
        {
            _searchableWindows = typeof(SearchableEditorWindow).GetField("searchableWindows", BindingFlags.Static | BindingFlags.NonPublic);
            _setSearchFilter = typeof(SearchableEditorWindow).GetMethod("SetSearchFilter", BindingFlags.Instance | BindingFlags.NonPublic, null, new[]{typeof(string), typeof(SearchableEditorWindow.SearchMode), typeof(bool)}, null);
            _m_HierarchyType = typeof(SearchableEditorWindow).GetField("m_HierarchyType", BindingFlags.Instance | BindingFlags.NonPublic);
            _m_HasSearchFilterFocus = typeof(SearchableEditorWindow).GetField("m_HasSearchFilterFocus", BindingFlags.Instance | BindingFlags.NonPublic);

            if (null == _searchableWindows)
                Debug.LogWarning("Could not find field 'UnityEditor.SearchableEditorWindow.searchableWindows'.");

            if (null == _setSearchFilter)
                Debug.LogWarning("Could not find method 'UnityEditor.SearchableEditorWindow.SetSearchFilter(string, SearchMode, bool)'.");

            if (null == _m_HierarchyType)
                Debug.LogWarning("Could not find field 'UnityEditor.SearchableEditorWindow.m_HierarchyType'.");

            if (null == _m_HasSearchFilterFocus)
                Debug.LogWarning("Could not find field 'UnityEditor.SearchableEditorWindow.m_HasSearchFilterFocus'.");
        }
        #endregion

        #region SetHierarySearchFilter
        /// <summary>
        /// Sets the specified search text and mode in all Hierachy windows.
        /// </summary>
        /// <param name="filter">The search text</param>
        /// <param name="mode">The search mode</param>
        public static void SetHierarchySearchFilter(string filter, SearchableEditorWindow.SearchMode mode)
        {
            if (_searchableWindows == null || _setSearchFilter == null || _m_HierarchyType == null || _m_HasSearchFilterFocus == null)
            {
                Debug.LogWarning("Could not execute 'SetHierarySearchFilter' because some of the required fields are missing.");
                return;
            }

            // get the windows list
            var enumerable = _searchableWindows.GetValue(null) as System.Collections.IEnumerable;
            if (enumerable == null)
                return;

            // for every window in the list
            foreach (var e in enumerable)
            {
                var window = e as SearchableEditorWindow;
                if (window == null)
                    continue;

                // make sure it's to search for gameobjects
                var hierarchyType = (HierarchyType)_m_HierarchyType.GetValue(window);
                if (hierarchyType != HierarchyType.GameObjects)
                    continue;

                // apply the search filter (this makes the objects in the scene to be highlighted)
                var args = new object[] { filter, mode, false };
                _setSearchFilter.Invoke(window, args);

                // now set the filter focus
                // this makes that the text appears in the searchfield
                _m_HasSearchFilterFocus.SetValue(window, true);

                // and refresh
                window.Repaint();
            }
        }
        #endregion
    }
}
