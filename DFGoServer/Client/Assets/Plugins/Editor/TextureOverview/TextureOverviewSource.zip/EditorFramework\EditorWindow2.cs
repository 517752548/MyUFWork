﻿//---------------------------------------
// Copyright (c) 2011-2018 Peter Schraut
// http://console-dev.de
//---------------------------------------

using System;
using UnityEngine;
using UnityEditor;

namespace EditorFramework
{
    /// <summary>
    /// EditorWindow2 handles some common tasks and pitfalls that occcur when using EditorWindow.
    /// </summary>
    /// <remarks>
    /// Issues EditorWindow2 solves:
    /// 1) When initializing the window takes a good amount of time, it usually causes the window to be rendered just white or ghosted.
    /// EditorWindow2 works around this issue by providing custom initialization routines that are called in a special order,
    /// to ensure the base-window stuff is initialized quickly and is ready to render and actually rendered once before it continues.
    /// 2) Handling common shortcuts, such as Ctrl+F (find). You usually want to give a certain control the focus when this shortcut is being triggered.
    /// 3) When creating UI between layout and paint, Unity usually displays the error "Getting control 0's position in a group with only 0 controls when doing Repaint".
    /// EditorWindow2 ensures to call __OnInit during layout to work around this issue.
    /// 
    /// The execution order is:
    /// * __OnCheckCompatibility()
    /// * __OnCreate()
    /// * __OnResize()
    /// * __OnInit()
    /// * __OnGUI()
    /// * __OnDestroy()
    /// </remarks>
    public abstract class EditorWindow2 : EditorWindow
    {
        #region Private Fields
        int _initphase;
        bool _enabled = false;
        bool _waitforlayout = true;
        Rect _lastposition;
        #endregion

        /// <summary>
        /// Indicates whether the window has been completely initialized.
        /// </summary>
        public bool IsInited
        {
            get
            {
                return _initphase >= 4;
            }
        }

        protected void SetTitle(string name)
        {
#if UNITY_2017_OR_NEWER || UNITY_5_6_OR_NEWER || UNITY_5_5_OR_NEWER || UNITY_5_1_OR_NEWER
            this.titleContent = new GUIContent(name);
#else
            this.title = name;
#endif
        }

        /// <summary>
        /// Called before the window gets created.
        /// Checks if the plugin is compatible with the Unity version it is running in.
        /// </summary>
        protected virtual bool __OnCheckCompatibility()
        {
            return true;
        }

        /// <summary>
        /// Called when the window should create its controls.
        /// </summary>
        /// <remarks>
        /// This method should be kept fast. If the method takes long(er) to complete,
        /// the window might appear ghosted and it might look like it's not responding.
        /// To performance heavy stuff during __OnInit() instead.
        /// </remarks>
        protected abstract void __OnCreate();

        /// <summary>
        /// Called when the window should initialize its stuff.
        /// </summary>
        /// <remarks>
        /// This method should be kept fast. If the method takes long(er) to complete,
        /// the window might appear ghosted and it might look like it's not responding.
        /// To performance heavy stuff during __OnInit() instead.
        /// </remarks>
        protected abstract void __OnInit();

        /// <summary>
        /// Derived classes must implement this method to draw and handle the GUI.
        /// </summary>
        protected abstract void __OnGUI();

        /// <summary>
        /// Called when the window size changed.
        /// Derived classes can override this method to repsond to this event..
        /// </summary>
        protected virtual void __OnResize()
        {
        }

        /// <summary>
        /// Call this to trigger a resize event during the next OnGUI. 
        /// </summary>
        bool _TriggerResize;
        public void TriggerResize()
        {
            if (!_TriggerResize)
            {
                _TriggerResize = true;
                Repaint();
            }
        }

        /// <summary>
        /// Called when the user invoked the find command (Ctrl+F).
        /// Derived classes can override this method to repsond to this command, eg to focus their default search control.
        /// </summary>
        protected virtual void __OnFindCommand()
        {
        }

        /// <summary>
        /// Called when the editor is about to change to game playback.
        /// </summary>
        protected virtual void __OnEnterPlayMode()
        {
        }

        /// <summary>
        /// Called when the editor is about to leave game playback.
        /// </summary>
        protected virtual void __OnLeavePlayMode()
        {
        }

        /// <summary>
        /// Called when the window is about to get destroyed.
        /// Derived classes must implement this method to free allocated resources.
        /// </summary>
        protected abstract void __OnDestroy();

        /// <summary>
        /// Method called by Unity to draw and handle the GUI.
        /// </summary>
        void OnGUI()
        {
            try
            {
                GUI.matrix = Matrix4x4.identity;

                // The very first call to our gui must take place during the repaint event,
                // otherwise we get the following unity error: "Getting control 0's position in a group with only 0 controls when doing Repaint"
                if (_waitforlayout && Event.current.type != EventType.Layout)
                {
                    Repaint();
                    return;
                }

                _waitforlayout = false;

                // check if we can init the window now
                if (_initphase == 1)
                {
                    if (!__OnCheckCompatibility())
                    {
                        Close();
                        return;
                    }

                    __OnCreate();
                    __OnResize();
                    _initphase = 2;
                    _waitforlayout = true;
                    Repaint();
                    return;
                }

                // check if we inited the window and ran OnGUI once
                // this is where the window is shown in all its glory
                // and we can do some blocking long operations without
                // looking too ugly
                if (_initphase == 3)
                {
                    _initphase = 4;
                    __OnInit();
//#if false && UNITY_2017_OR_NEWER
//#else
//                    EditorUserBuildSettings.activeBuildTargetChanged += __OnActiveBuildTargetChanged;
//#endif

#if UNITY_2017_2_OR_NEWER
                    EditorApplication.playModeStateChanged += OnPlayModeStateChanged;
#else
                    EditorApplication.playmodeStateChanged += OnPlayModeStateChanged;
#endif
                }

                if (_enabled)
                {
                    if (Event.current.type == EventType.Layout && (_TriggerResize || Mathf.Abs(position.width - _lastposition.width) > 1 || Mathf.Abs(position.height - _lastposition.height) > 1))
                    {
                        __OnResize();
                        Repaint();
                        _lastposition = position;
                        _TriggerResize = false;
                    }

                    GUIColors.Update();
                    __OnGUI();

                    if (_initphase > 3)
                        DoHandleCommands();
                }

                if (_initphase == 2 && Event.current.type == EventType.Repaint)
                {
                    _initphase = 3;
                    _waitforlayout = true;
                    Repaint();
                    return;
                }
            }
            catch (Exception e)
            {
                if (IsCriticalException(e))
                {
                    Debug.LogException(e);

                    var appTitle="<Title>";
                    var pluginCompiledFor = "Any";

                #if UNITY_2018_2_OR_NEWER
                    pluginCompiledFor = "Unity 2018.2";
                #elif UNITY_2018_OR_NEWER
                    pluginCompiledFor = "Unity 2018";
                #elif UNITY_2017_3_OR_NEWER
                    pluginCompiledFor = "Unity 2017.3";
                #elif UNITY_2017_2_OR_NEWER
                    pluginCompiledFor = "Unity 2017.2";
                #elif UNITY_2017_OR_NEWER
                    pluginCompiledFor = "Unity 2017";
                #elif UNITY_5_6_OR_NEWER
                    pluginCompiledFor = "Unity 5.6";
                #elif UNITY_5_5_OR_NEWER
                    pluginCompiledFor = "Unity 5.5";
                #elif UNITY_5_1_OR_NEWER
                    pluginCompiledFor = "Unity 5.1";
                #elif UNITY_5_OR_NEWER
                    pluginCompiledFor = "Unity 5";
                #else
                    pluginCompiledFor = "Unity 4";
                #endif

                #if UNITY_5_1_OR_NEWER
                    appTitle = titleContent.text;
                #else
                    appTitle = title;
                #endif

                    if (!EditorUtility.DisplayDialog("ka-booom!!!", string.Format("An unhandled error occurred in {0}.\n\nPlease include a screenshot of this message and a description how to reproduce the error if you send a bug-report to the {0} developer (see Unity AssetStore for contact details).\n\n{1}\n\nUnity={2}, Platform={3}, BuildTarget={4}, PluginCreatedWith={5}", appTitle, e, Application.unityVersion, Application.platform, EditorUserBuildSettings.activeBuildTarget, pluginCompiledFor), "Ignore", string.Format("Close {0}", appTitle)))
                    {
                        this.Close();
                        return;
                    }
                }
                else
                {
                    throw e;
                }
            }
        }

        /// <summary>
        /// Handles common commands aka shortcuts and calls a particular method to notify the window.
        /// </summary>
        void DoHandleCommands()
        {
            if (Event.current.type != EventType.ValidateCommand && Event.current.type != EventType.ExecuteCommand)
                return;

            #region Find Hotkey
            if (string.Equals(Event.current.commandName, "Find", StringComparison.OrdinalIgnoreCase))
            {
                if (Event.current.type == EventType.ExecuteCommand)
                    __OnFindCommand();

                Event.current.Use();
            }
            #endregion
        }

        /// <summary>
        /// Called by Unity when the window is loaded.
        /// </summary>
        void OnEnable()
        {
            _waitforlayout = true;
            _initphase = 1;
            _enabled = true;
            Repaint();
        }

        /// <summary>
        /// Called by Unity when the window goes out of scope.
        /// </summary>
        void OnDisable()
        {
            _initphase = 0;
            _enabled = false;
            _waitforlayout = false;
#if UNITY_2017_2_OR_NEWER
            EditorApplication.playModeStateChanged -= OnPlayModeStateChanged;
#else
            EditorApplication.playmodeStateChanged -= OnPlayModeStateChanged;
#endif
            __OnDestroy();
        }

        /// <summary>
        /// Called by Unity when the window will be destroyed.
        /// </summary>
        void OnDestroy()
        {
            _initphase = 0;
            _enabled = false;
//#if false && UNITY_2017_OR_NEWER
//#else
//            EditorUserBuildSettings.activeBuildTargetChanged -= __OnActiveBuildTargetChanged;
//#endif

#if UNITY_2017_2_OR_NEWER
            EditorApplication.playModeStateChanged -= OnPlayModeStateChanged;
#else
            EditorApplication.playmodeStateChanged -= OnPlayModeStateChanged;
#endif
            EditorApplication2.OnPluginDestroy();
        }

        //protected virtual void __OnActiveBuildTargetChanged()
        //{
        //}

#if UNITY_2017_2_OR_NEWER
        void OnPlayModeStateChanged(PlayModeStateChange value)
        {
            if (value == PlayModeStateChange.ExitingEditMode)
                __OnEnterPlayMode();

            if (value == PlayModeStateChange.ExitingPlayMode)
                __OnLeavePlayMode();
        }
#else
        void OnPlayModeStateChanged()
        {
            if (!EditorApplication.isPlaying && EditorApplication.isPlayingOrWillChangePlaymode)
                __OnEnterPlayMode();

            if (EditorApplication.isPlaying && !EditorApplication.isPlayingOrWillChangePlaymode)
                __OnLeavePlayMode();
        }
#endif

        /// <summary>
        /// Gets whether the specified exception is critical and an error should be displayed.
        /// </summary>
        /// <param name="e">The exception.</param>
        /// <returns>true when it is a critical exception, false otherwise.</returns>
        /// <remarks>
        /// Not all exceptions are critical, for example 'ExitGUIException' is fine.
        /// </remarks>
        bool IsCriticalException(Exception e)
        {
            if (e is ExitGUIException)
                return false;

            // Figure out if the problem seems to be in unity or the plugin code.
            // This is to ignore unity gui layout errors that appear every now and then for whatever reason.
            if (!string.IsNullOrEmpty(e.StackTrace))
            {
                var unityProblem = false;
                var lines = e.StackTrace.Split(new[] { '\n' }, StringSplitOptions.RemoveEmptyEntries);
                for (var n=lines.Length-1; n>=0; --n)
                {
                    var line = lines[n].Replace("\\", "/");

                    if (line.IndexOf("in c:/buildslave/unity/", StringComparison.OrdinalIgnoreCase) != -1)
                        unityProblem = true;

                    if (line.IndexOf("in c:/users/crash/", StringComparison.OrdinalIgnoreCase) != -1)
                        unityProblem = false;
                }
                if (unityProblem)
                    return false;
            }

            if (e is ArgumentException && !string.IsNullOrEmpty(e.Message))
            {
                // Getting control 0's position in a group with only 0 controls when doing a repaint
                if (e.Message.IndexOf("Getting control", StringComparison.OrdinalIgnoreCase) != -1 &&
                    e.Message.IndexOf("position in a group with only", StringComparison.OrdinalIgnoreCase) != -1)
                    return false;
            }

            return true;
        }
    }
}
