﻿//---------------------------------------
// Copyright (c) 2013-2016 Peter Schraut
// http://console-dev.de
//---------------------------------------

using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

namespace EditorFramework
{
    public interface ICacheFileEntry
    {
        /// <summary>
        /// Gets the asset guid of the cache entry.
        /// </summary>
        /// <returns></returns>
        string GetAssetGuid();

        /// <summary>
        /// Gets the asset timestamp of the cache entry.
        /// </summary>
        string GetAssetHash();

        /// <summary>
        /// Serializes/deserializes the cache entry to the specified BinarySerializer.
        /// </summary>
        /// <param name="data">The BinarySerializer</param>
        void Serialize(BinarySerializer data);
    }

    /// <summary>
    /// The cache file stores asset settings, so that future requests for
    /// that data can be served faster to the application.
    /// </summary>
    /// <typeparam name="T">The type of a cached file entry. Must implement the ICacheFileEntry interface.</typeparam>
    /// <remarks>
    /// One example is the 'Texture Overview' plugin that needs reads texture settings (such as width, height, etc)
    /// but to do so, the actual texture must be read and this is a very slow operation. So improve this performance-wise,
    /// these settings are stored in a cache file. The next time the application requests this data, it can first check
    /// if is it available in the cache file and this can bypass the expensive operation to load the texture.
    /// </remarks>
    public class CacheFile<T> where T : ICacheFileEntry, new()
    {
        #region Private Fields
        const UInt32 FileMagic = 0x1337affe;
        UInt32 _fileVersion;
        string _appTitle;
        string _cachePath;
        Dictionary<string, T> _lut = new Dictionary<string, T>();
        bool _isDirty;
        #endregion

        #region IsEmpty
        /// <summary>
        /// Gets whether the cache file is empty.
        /// </summary>
        public bool IsEmpty
        {
            get
            {
                return _lut.Count==0;
            }
        }
        #endregion

        #region ctor
        /// <summary>
        /// Initializes a new instance of a CacheFile.
        /// </summary>
        /// <param name="fileVersion">The expected version of the cache file.</param>
        /// <param name="appTitle">The application title that is displayed in error messages.</param>
        /// <param name="cacheFileName">The filename without file-extension of the cache file.</param>
        public CacheFile(UInt32 fileVersion, string appTitle, string cacheFileName)
        {
            _fileVersion = fileVersion;
            _appTitle = appTitle;

            // automatically move cache file from old location to new location
            MoveCacheFileToLibrary(cacheFileName);

            // we assume the cache-file is located in the same directory as the
            // plugin dll (which is executing this code)
            _cachePath = System.IO.Path.Combine(EditorApplication2.LibraryPath, cacheFileName + ".cache");
        }
        #endregion

        #region Read
        /// <summary>
        /// Reads the cache file.
        /// </summary>
        public void Read()
        {
            _isDirty = false;
            _lut = new Dictionary<string, T>();
            try
            {
                if (!FileUtil2.Exists(_cachePath))
                    return;

                if (FileUtil2.IsReadOnly(_cachePath))
                    ShowCacheFileReadOnlyMessage(false);


                using (var stream = new System.IO.MemoryStream(System.IO.File.ReadAllBytes(_cachePath)))
                {
                    using (var reader = new System.IO.BinaryReader(stream))
                    {
                        var magic = reader.ReadUInt32();
                        if (magic != FileMagic)
                        {
                            UnityEngine.Debug.Log(string.Format("{0}: Cache file '{1}' contains an invalid header magic.", _appTitle, _cachePath));
                            return;
                        }

                        var version = reader.ReadInt32();
                        if (version != _fileVersion)
                        {
                            UnityEngine.Debug.Log(string.Format("{0}: Incompatible cache file detected, generating new one. ('{1}').\nThe most likely reason is you upgraded the plugin to a newer version. Existing cache file version is '{2}', required version is '{3}'.", _appTitle, _cachePath, version, _fileVersion));
                            return;
                        }

                        var serializer = new BinarySerializer(reader);
                        var count = reader.ReadInt32();
                        for (var n = 0; n < count; ++n)
                        {
                            var model = new T();
                            model.Serialize(serializer);

                            var guid = model.GetAssetGuid();
                            _lut[guid] = model;
                        }
                    }
                }
            }
            catch (Exception e)
            {
                UnityEngine.Debug.LogError(string.Format("{0}: Could not read cache file '{1}'.\n{2}", _appTitle, _cachePath, e.ToString()));
            }
        }
        #endregion

        public bool Delete()
        {
            // remove read only attr in order to be able to overwrite the file
            if (System.IO.File.Exists(_cachePath))
            {
                var newinfo = new System.IO.FileInfo(_cachePath);
                newinfo.IsReadOnly = false;
                newinfo.Delete();
                Debug.Log(string.Format("{0}: Deleted cache file '{1}'.", _appTitle, _cachePath));
                return true;
            }
            return false;
        }

        #region Write
        public void Write()
        {
            Write(false);
        }

        /// <summary>
        /// Writes the cached data to a file.
        /// </summary>
        public void Write(bool writeAlways)
        {
            if (!writeAlways)
            {
                if (!_isDirty)
                    return;
            }

            if (FileUtil2.Exists(_cachePath))
            {
                if (FileUtil2.IsReadOnly(_cachePath))
                    ShowCacheFileReadOnlyMessage(true);

                if (FileUtil2.IsReadOnly(_cachePath)) // maybe user didn't remove read-only while dialog is open
                    return;
            }


            using (var stream = new System.IO.MemoryStream(1024 * 1024))
            {
                using (var writer = new System.IO.BinaryWriter(stream))
                {
                    writer.Write(FileMagic);
                    writer.Write(_fileVersion);

                    // Sort all entries using the guid to make the file stable for diffs
                    var list = new List<T>(_lut.Values);
                    //list.Sort(delegate(T a, T b) { return string.Compare(a.GetAssetGuid(), b.GetAssetGuid()); });

                    writer.Write((Int32)list.Count); // number of cache entries

                    // Write each model to the stream
                    var serializer = new BinarySerializer(writer);
                    foreach (var model in list)
                        model.Serialize(serializer);
                }

                System.IO.File.WriteAllBytes(_cachePath, stream.ToArray());
                _isDirty = false;
            }
        }
        #endregion

        #region TryGetEntry
        /// <summary>
        /// Gets the cache entry for the specified assetguid and platform.
        /// </summary>
        /// <param name="assetguid">The guid of the asset to get the cache entry for.</param>
        /// <param name="model">The output entry</param>
        /// <returns>true when the entry has been found and is valid, false otherwise.</returns>
        public bool TryGetEntry(string assetguid, out T model)
        {
            return TryGetEntry(assetguid, out model, true);
        }

        /// <summary>
        /// Gets the cache entry for the specified assetguid and platform.
        /// </summary>
        /// <param name="assetguid">The guid of the asset to get the cache entry for.</param>
        /// <param name="model">The output entry</param>
        /// <param name="checkTimeStamp">Whether to compare the cached timestamp with the corresponding importer timestamp.</param>
        /// <returns>true when the entry has been found and is valid, false otherwise.</returns>
        public bool TryGetEntry(string assetguid, out T model, bool checkTimeStamp)
        {
            // try to get the model from the lookup table
            model = default(T);
            if (!_lut.TryGetValue(assetguid, out model))
                return false; // does not exist in the cache

            if (checkTimeStamp)
            {
                var path = AssetDatabase.GUIDToAssetPath(assetguid);
                var hash = AssetDatabase.GetAssetDependencyHash(path);
                var modelHash = Hash128.Parse(model.GetAssetHash());

                // check if the timestamp matches the one of the model
                // if it's different, we remove it from the lut (doing somewhat of a cleanup)
                if (hash != modelHash)
                {
                    _lut.Remove(assetguid);
                    return false;
                }
            }

            return true;
        }
        #endregion

        #region UpdateEntry
        /// <summary>
        /// Updates an entry in the cache.
        /// </summary>
        /// <param name="model">The entry to update.</param>
        public void UpdateEntry(T model)
        {
            var guid = model.GetAssetGuid();
            _lut[guid] = model;
            _isDirty = true;
        }
        #endregion

        void ShowCacheFileReadOnlyMessage(bool messagebox)
        {
            var text = string.Format("Cache file is not writable ({0}).\n\nThe cache file stores data to improve the plugin performance, especially the startup time.\n\nDo not add this file to revision control software like SVN, Perforce or Git.", AssetDatabase2.GetRelativeAssetPath(_cachePath));
            if (messagebox)
            {
                if (UnityEditor.EditorUtility.DisplayDialog(_appTitle, text, "Make writable and save", "Ignore"))
                {
                    var info = new System.IO.FileInfo(_cachePath);
                    info.IsReadOnly = false;
                    UnityEngine.Debug.Log(string.Format("{0}: Sucessfully removed read-only attribute of '{1}'.", _appTitle, AssetDatabase2.GetRelativeAssetPath(_cachePath)));
                }
            }
            else
                UnityEngine.Debug.LogWarning(string.Format("{0}: {1}", _appTitle, text));
        }

        #region MoveCacheFileToLibrary
        /// <summary>
        /// Earlier versions stored the .cache file in the same directory where
        /// the plugin DLL is located. Unity forum user imtrobin suggested to move
        /// the file to the library folder instead. So, that's what we're doing here.
        /// </summary>
        void MoveCacheFileToLibrary(string cacheFileName)
        {
            // we assume the cache-file is located in the same directory as the
            // plugin dll (which is executing this code)
            var asm = System.Reflection.Assembly.GetExecutingAssembly();
            var folder = System.IO.Path.GetDirectoryName(asm.Location);
            var oldpath = System.IO.Path.Combine(folder, cacheFileName + ".cache");

            // if the file is still located at the old path, move it to the new location
            if (System.IO.File.Exists(oldpath))
            {
                var newpath = System.IO.Path.Combine(EditorApplication2.LibraryPath, cacheFileName + ".cache");

                // remove read only attr in order to be able to overwrite the file
                if (System.IO.File.Exists(newpath))
                {
                    var newinfo = new System.IO.FileInfo(newpath);
                    newinfo.IsReadOnly = false;
                }

                // copy .cache file
                System.IO.File.Copy(oldpath, newpath, true);

                // remove old file
                var oldinfo = new System.IO.FileInfo(oldpath);
                oldinfo.IsReadOnly = false;
                oldinfo.Delete();

                // refresh database to remove the existing .cache.meta file
                AssetDatabase.Refresh();
            }
        }
        #endregion
    }
}
