﻿//---------------------------------------
// Copyright (c) 2014 Peter Schraut
// http://console-dev.de
//---------------------------------------

using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

namespace EditorFramework
{
    using Model = FindAssetUsage.AssetProxy;

    /// <summary>
    /// The FindAssetUsage class provides the ability to search for
    /// which assets use an other asset. For example, it can find
    /// which materials use a certain texture, or what prefabs use a particular autio clip.
    /// </summary>
    public static class FindAssetUsage
    {
        #region class AssetProxy
        /// <summary>
        /// The AssetProxy provides the ability to represent an asset either by its path or by a reference to the asset.
        /// </summary>
        [Serializable]
        public class AssetProxy
        {
            #region Name
            /// <summary>
            /// Gets the asset name.
            /// </summary>
            string _name;
            public string Name
            {
                get
                {
                    if (_name == null)
                    {
                        if (Asset != null)
                            _name = Asset.name;

                        if (AssetPath != null)
                            _name = FileUtil2.GetFileNameWithoutExtension(AssetPath);
                    }

                    return _name ?? "<unnamed>";
                }
            }
            #endregion

            #region Asset
            /// <summary>
            /// The asset or null.
            /// null if the asset is located in the project, not null when it's a builtin asset such as the Unity Diffuse shader
            /// </summary>
            [SerializeField]
            public UnityEngine.Object Asset;

            /// <summary>
            /// The asset path if the asset exists in the project, otherwise null.
            /// </summary>
            [SerializeField]
            public string AssetPath;

            [SerializeField]
            public Type AssetType;
            #endregion

            #region LoadAsset
            /// <summary>
            /// Loads the asset.
            /// </summary>
            /// <returns>The asset on success, null otherwise.</returns>
            public UnityEngine.Object LoadAsset()
            {
                if (Asset != null)
                    return Asset;

                if (AssetPath != null)
                    return AssetDatabase.LoadMainAssetAtPath(AssetPath);

                return null;
            }
            #endregion
        }
        #endregion

        #region class ResultEntry
        [Serializable]
        public class ResultEntry : AssetProxy
        {
            /// <summary>
            /// The assets that use the asset specified by 'SearchFor'.
            /// </summary>
            [SerializeField]
            public List<AssetProxy> Findings = new List<AssetProxy>();

            /// <summary>
            /// Adds an item to the Findings.
            /// </summary>
            public void Add(string path)
            {
                var proxy = new AssetProxy();
                proxy.AssetPath = path;
                Findings.Add(proxy);
            }

            /// <summary>
            /// Adds an item to the Findings.
            /// </summary>
            public void Add(UnityEngine.Object obj)
            {
                var proxy = new AssetProxy();
                proxy.Asset = obj;
                Findings.Add(proxy);
            }
        }
        #endregion

        #region class Result
        /// <summary>
        /// The Result provides the result of a FindUsages operation.
        /// </summary>
        [Serializable]
        public class Result
        {
            [SerializeField]
            public List<ResultEntry> Entries = new List<ResultEntry>();
        }
        #endregion

        #region Find asset usages in project
        /// <summary>
        /// Finds assets that depend on the specified findpaths.
        /// </summary>
        public static Result InProject(IEnumerable<string> findpaths, IEnumerable<Type> findtypes)
        {
            // free some memory
            EditorUtility2.UnloadUnusedAssetsImmediate();

            // a lookup table to map from 'findpath' to a list of assets that use 'findpath'
            // key = findpath, value = list of assets that use findpath
            var lookupdict = new Dictionary<string, Dictionary<string, string>>();
            foreach (var p in findpaths)
            {
                if (!string.IsNullOrEmpty(p) && !lookupdict.ContainsKey(p))
                    lookupdict.Add(p, new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase));
            }

            // build a text that contains all search types
            var typenames = "";
            foreach (var t in findtypes)
            {
                if (!string.IsNullOrEmpty(typenames))
                    typenames += ", ";
                typenames += t.Name;
            }

            using (var progressbar = new EditorGUI2.ModalProgressBar(string.Format("Searching {0} assets...", typenames), true))
            {
                // get all assets in the project of the specified types
                var assetpaths = AssetDatabase2.GetPathsByType(findtypes);

                // check if any of these assets is using one of the findpaths we're looking for
                for (var n = 0; n < assetpaths.Count; ++n)
                {
                    var path = assetpaths[n];

                    // display progress in 100ms intervals
                    if (progressbar.TotalElapsedTime > 1.0f && progressbar.ElapsedTime > 0.1f)
                    {
                        var progress = n / (float)assetpaths.Count;
                        var text = string.Format("[{1} remaining] {0}", FileUtil2.GetFileNameWithoutExtension(path), assetpaths.Count - n - 1);
                        if (progressbar.Update(text, progress))
                            break;
                    }

                    // get dependency of current asset and check if any dependency
                    // is using an asset we are looking for.
                    var dependencies = AssetDatabase.GetDependencies(new[] { path });
                    foreach (var d in dependencies)
                    {
                        if (string.Equals(d, path, StringComparison.OrdinalIgnoreCase))
                            continue;

                        // check if the dependency is an asset we're looking for and if so, add it to our list
                        Dictionary<string, string> list;
                        if (lookupdict.TryGetValue(d, out list))
                            list[path] = path;
                    }
                }
            }

            // build the result structure
            var result = new Result();
            foreach (var find in lookupdict)
            {
                var report = new ResultEntry();
                report.AssetPath = find.Key;

                foreach (var consumer in find.Value)
                    report.Add(consumer.Key);

                result.Entries.Add(report);
            }

            return result;
        }


        /// <summary>
        /// Finds assets that depend on the specified findobjs.
        /// Please note this method is much much slower than the other InProject that expects findpaths instead.
        /// The reason why this method is slow is because to find objects, such as builtin shaders, it needs
        /// to load assets into memory and collect their dependencies.
        /// </summary>
        public static Result InProject(IEnumerable<UnityEngine.Object> findobjs, IEnumerable<Type> findtypes)
        {
            // free some memory
            EditorUtility2.UnloadUnusedAssetsImmediate();

            // a lookup table to map from 'findpath' to a list of assets that use 'findpath'
            // key = findpath, value = list of assets that use findpath
            var lookupdict = new Dictionary<UnityEngine.Object, Dictionary<string, string>>();
            foreach (var p in findobjs)
            {
                if (p != null && !lookupdict.ContainsKey(p))
                    lookupdict.Add(p, new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase));
            }

            // build a text that contains all search types
            var typenames = "";
            foreach (var t in findtypes)
            {
                if (!string.IsNullOrEmpty(typenames))
                    typenames += ", ";
                typenames += t.Name;
            }

            using (var progressbar = new EditorGUI2.ModalProgressBar(string.Format("Searching {0} assets...", typenames), true))
            {
                // get all assets in the project of the specified types
                var assetpaths = AssetDatabase2.GetPathsByType(findtypes);

                // check if any of these assets is using one of the findpaths we're looking for
                for (var n = 0; n < assetpaths.Count; ++n)
                {
                    var path = assetpaths[n];

                    // display progress in 100ms intervals
                    if (progressbar.TotalElapsedTime > 1.0f && progressbar.ElapsedTime > 0.1f)
                    {
                        var progress = n / (float)assetpaths.Count;
                        var text = string.Format("[{1} remaining] {0}", FileUtil2.GetFileNameWithoutExtension(path), assetpaths.Count - n - 1);
                        if (progressbar.Update(text, progress))
                            break;
                    }
                    
                    // get dependency of current asset and check if any dependency
                    // is using an asset we are looking for.
                    var assets = AssetDatabase.LoadMainAssetAtPath(path);
                    var dependencies = EditorUtility.CollectDependencies(new[]{assets});
                    foreach (var d in dependencies)
                    {
                        if (d == null)
                            continue;

                        // check if the dependency is an asset we're looking for and if so, add it to our list
                        Dictionary<string, string> list;
                        if (lookupdict.TryGetValue(d, out list))
                            list[path] = path;
                    }
                    
                    // cleanup memory every N assets
                    // this is a magic number to prevent the editor to crash with an out-of-memory error when loading assets
                    if ((n%25) == 0)
                        EditorUtility2.UnloadUnusedAssetsImmediate();
                }
            }

            // build the result structure
            var result = new Result();
            foreach (var find in lookupdict)
            {
                var report = new ResultEntry();
                report.Asset = find.Key;
                   
                foreach (var consumer in find.Value)
                    report.Add(consumer.Key);

                result.Entries.Add(report);
            }

            return result;
        }

        /// <summary>
        /// Finds assets that depend on the specified findobjs.
        /// Please note this method is much much slower than the other InProject that expects findpaths instead.
        /// The reason why this method is slow is because to find objects, such as builtin shaders, it needs
        /// to load assets into memory and collect their dependencies.
        /// </summary>
        public static Result InProject(IEnumerable<Type> findobjs, IEnumerable<Type> findtypes)
        {
            // free some memory
            EditorUtility2.UnloadUnusedAssetsImmediate();

            // a lookup table to map from 'findpath' to a list of assets that use 'findpath'
            // key = findpath, value = list of assets that use findpath
            var lookupdict = new Dictionary<Type, Dictionary<string, string>>();
            foreach (var p in findobjs)
            {
                if (p != null && !lookupdict.ContainsKey(p))
                    lookupdict.Add(p, new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase));
            }

            // build a text that contains all search types
            var typenames = "";
            foreach (var t in findtypes)
            {
                if (!string.IsNullOrEmpty(typenames))
                    typenames += ", ";
                typenames += t.Name;
            }

            using (var progressbar = new EditorGUI2.ModalProgressBar(string.Format("Searching {0} assets...", typenames), true))
            {
                // get all assets in the project of the specified types
                var assetpaths = AssetDatabase2.GetPathsByType(findtypes);

                // check if any of these assets is using one of the findpaths we're looking for
                for (var n = 0; n < assetpaths.Count; ++n)
                {
                    var path = assetpaths[n];

                    // display progress in 100ms intervals
                    if (progressbar.TotalElapsedTime > 1.0f && progressbar.ElapsedTime > 0.1f)
                    {
                        var progress = n / (float)assetpaths.Count;
                        var text = string.Format("[{1} remaining] {0}", FileUtil2.GetFileNameWithoutExtension(path), assetpaths.Count - n - 1);
                        if (progressbar.Update(text, progress))
                            break;
                    }

                    // get dependency of current asset and check if any dependency
                    // is using an asset we are looking for.
                    var assets = AssetDatabase.LoadMainAssetAtPath(path);
                    var dependencies = EditorUtility.CollectDependencies(new[] { assets });
                    foreach (var d in dependencies)
                    {
                        if (d == null)
                            continue;

                        // check if the dependency is an asset we're looking for and if so, add it to our list
                        Dictionary<string, string> list;
                        if (lookupdict.TryGetValue(d.GetType(), out list))
                            list[path] = path;
                    }

                    // cleanup memory every N assets
                    // this is a magic number to prevent the editor to crash with an out-of-memory error when loading assets
                    if ((n % 25) == 0)
                        EditorUtility2.UnloadUnusedAssetsImmediate();
                }
            }

            // build the result structure
            var result = new Result();
            foreach (var find in lookupdict)
            {
                var report = new ResultEntry();
                report.AssetType = find.Key;
                report.AssetPath = find.Key.Name;//.FullName.Replace('.', '/');

                foreach (var consumer in find.Value)
                    report.Add(consumer.Key);

                result.Entries.Add(report);
            }

            return result;
        }
        #endregion
    }

    /// <summary>
    /// The FindAssetUsageWindow class represents the window that displays
    /// the find results of a 'FindAssetUsage' operation.
    /// </summary>
    [Serializable]
    public class FindAssetUsageWindow : EditorWindow
    {
        #region class Listbox
        /// <summary>
        /// Represents the control that displays the search results in a list-view.
        /// </summary>
        class Listbox : GUIListView
        {
            #region class Column
            protected class Column : GUIListViewColumn
            {
                public delegate void ColumnDrawer(Model model, GUIListViewDrawItemArgs args);

                public ColumnDrawer DrawFunc;

                public Column(string id, string title, int width, GUIListViewColumn.CompareDelelgate comparer, ColumnDrawer drawer)
                    : base(title, "", null, width, comparer)
                {
                    base.SerializeName = id;
                    DrawFunc = drawer;
                }
            }
            #endregion

            #region Private Fields
            List<Model> _items;
            #endregion

            #region ctor
            public Listbox(EditorWindow editor, GUIControl parent)
                : base(editor, parent)
            {
                _items = new List<Model>();
                Mode = GUIListViewMode.Details;
                FullRowSelect = true;
                HeaderStyle = GUIListViewHeaderStyle.ClickablePopup;
                MultiSelect = true;
            }
            #endregion

            #region Draw/Compare AssetName
            protected void OnDrawAssetName(Model model, GUIListViewDrawItemArgs args)
            {
                EditorGUI2.PathLabel(args.ItemRect, model.Name, args.Selected);
            }

            protected int OnCompareAssetName(object x, object y)
            {
                var xx = x as Model;
                var yy = y as Model;
                return string.Compare(xx.Name, yy.Name, StringComparison.OrdinalIgnoreCase);
            }
            #endregion

            #region Draw/Compare AssetPath
            protected void OnDrawAssetPath(Model model, GUIListViewDrawItemArgs args)
            {
                EditorGUI2.PathLabel(args.ItemRect, model.AssetPath ?? "<no path available>", args.Selected);
            }

            protected int OnCompareAssetPath(object x, object y)
            {
                var xx = x as Model;
                var yy = y as Model;
                return string.Compare(xx.AssetPath, yy.AssetPath, StringComparison.OrdinalIgnoreCase);
            }
            #endregion

            #region SelectItem
            /// <summary>
            /// Selects the item with the specified index.
            /// </summary>
            public void SelectItem(int index)
            {
                var model = OnGetItem(index) as Model;
                SelectedItems = new[] { model };
            }
            #endregion

            #region SetItems
            /// <summary>
            /// Adds the specified items to the list.
            /// </summary>
            /// <param name="items"></param>
            public void SetItems(IEnumerable<Model> items)
            {
                _items = new List<Model>();
                foreach (var item in items)
                    _items.Add(item);

                Sort();
                Editor.Repaint();
            }
            #endregion

            #region Sorting
            /// <summary>
            /// Occurs when the user requests to sort the list.
            /// </summary>
            /// <returns>Returns the array of items to sort.</returns>
            protected override object[] OnBeforeSortItems()
            {
                return _items.ToArray();
            }

            /// <summary>
            /// Occurs after sorting completed.
            /// </summary>
            /// <param name="models">The sorted data. This is the data returned by OnBeforeSortItems(), but sorted.</param>
            protected override void OnAfterSortItems(object[] models)
            {
                _items = new List<Model>((Model[])models);
            }
            #endregion

            #region OnItemDoubleClick
            /// <summary>
            /// Occurs when the user double clicks an item.
            /// </summary>
            /// <param name="index">The index of the item.</param>
            protected override void OnItemDoubleClick(GUIListViewItemDoubleClickArgs args)
            {
                OnContextMenuSelect();
            }
            #endregion

            #region OnItemKeyDown
            /// <summary>
            /// Occurs when the user presses a key.
            /// </summary>
            protected override void OnItemKeyDown(ref GUIListViewItemKeyDownArgs args)
            {
                if (SelectedItemsCount < 1)
                    return;

                switch (Event.current.keyCode)
                {
                    // we want the Return key to be used to assign the item to the inspector
                    case KeyCode.Return:
                        if (Event.current.control) // Ctrl+Return opens selected textures in the default application
                        {
                            OnContextMenuOpenWithDefaultApp();
                            args.Handled = true;
                            GUIUtility.ExitGUI(); // without this line Unity displays an exception and I have no idea why
                        }
                        else
                        {
                            OnContextMenuSelect();
                            args.Handled = true;
                        }
                        break;
                }
            }
            #endregion

            #region OnGetItem
            /// <summary>
            /// Gets the model-item at the specified index.
            /// </summary>
            protected override object OnGetItem(int index)
            {
                if (index < 0 || index >= _items.Count)
                    return null;

                return _items[index];
            }
            #endregion

            #region OnGetItemCount
            /// <summary>
            /// Gets the count of items in the list.
            /// </summary>
            protected override int OnGetItemCount()
            {
                return _items.Count;
            }
            #endregion

            #region OnDrawItem
            /// <summary>
            /// Occurs when a list item is requested to draw.
            /// </summary>
            /// <param name="args">The data containing all the information needed to draw the item.</param>
            protected override void OnDrawItem(GUIListViewDrawItemArgs args)
            {
                var model = args.Model as Model;
                if (model == null)
                    return;

                // if this is the first column, draw an icon to make it appear nicer
                if (args.Column.IsPrimaryColumn)
                {
                    // get an icon for the asset's type
                    Texture icon = null;
                    if (model.Asset != null)
                        icon = AssetPreview.GetMiniTypeThumbnail(model.Asset.GetType());
                    else if (model.AssetType != null)
                        icon = AssetPreview.GetMiniTypeThumbnail(model.AssetType);
                    else if (!string.IsNullOrEmpty(model.AssetPath))
                        icon = AssetPreview.GetMiniTypeThumbnail(AssetDatabase2.GetAssetType(model.AssetPath));
                    
                    // if no icon could be found, fallback to the TextAsset icon
                    if (icon == null)
                        icon = AssetPreview.GetMiniTypeThumbnail(typeof(TextAsset));

                    // draw the icon
                    DrawItemImageHelper(ref args.ItemRect, icon, new Vector2(16, 16));
                }

                // center text vertically
                args.ItemRect.y += 3;
                args.ItemRect.height -= 3;

                // draw item in column
                var column = args.Column as Column;
                column.DrawFunc(model, args);
            }
            #endregion

            #region ContextMenu
            protected override void OnItemContextMenu(GUIListViewContextMenuArgs args)
            {
                base.OnItemContextMenu(args);

                if (SelectedItemsCount < 1)
                    return; // no item selected, do not open a context menu

                var model = args.Model as Model;
                var existsondisk = FileUtil2.Exists(model.AssetPath);
                
                var menu = new GenericMenu();
                menu.AddItem(new GUIContent(Application.platform == RuntimePlatform.OSXEditor ? "Reveal in Finder" : "Show in Explorer"), false, existsondisk ? OnContextMenuShowInExplorer : (GenericMenu.MenuFunction)null);
                menu.AddItem(new GUIContent("Open %enter"), false, FileUtil2.Exists(model.AssetPath) ? OnContextMenuOpenWithDefaultApp : (GenericMenu.MenuFunction)null);
                menu.AddItem(new GUIContent(string.Empty), false, null);
                menu.AddItem(new GUIContent("Select in Project _enter"), false, existsondisk ? OnContextMenuSelect : (GenericMenu.MenuFunction)null);
                menu.AddItem(new GUIContent("Find References in Scene"), false, (SelectedItemsCount == 1) ? OnContextMenuFindReferencesInScene : (GenericMenu.MenuFunction)null);
                menu.AddItem(new GUIContent(string.Empty), false, null);
                menu.AddItem(new GUIContent("Copy Full Path"), false, existsondisk ? OnContextMenuCopyFullPath : (GenericMenu.MenuFunction)null);

                // display the context menu. make sure to use the provided args.MenuLocation position
                // rather than 'Event.current.mousePosition', because the user could have been pressed
                // the context-menu key as well, thus mousePosition would be most likely wrong.
                menu.DropDown(new Rect(args.MenuLocation.x, args.MenuLocation.y, 0, 0));
                Event.current.Use();
                Editor.Repaint();
            }

            void OnContextMenuShowInExplorer()
            {
                var paths = GetSelectedPaths();
                EditorApplication2.ShowInExplorer(paths.ToArray());
            }

            void OnContextMenuOpenWithDefaultApp()
            {
                var paths = GetSelectedPaths();
                EditorApplication2.OpenAssets(paths.ToArray());
            }

            void OnContextMenuFindReferencesInScene()
            {
                var objects = GetSelectedAssets();
                if (objects.Count > 0)
                    EditorApplication2.FindReferencesInScene(objects[0]);
            }

            void OnContextMenuCopyFullPath()
            {
                var paths = GetSelectedPaths();
                ClipboardUtil.CopyPaths(paths);
            }

            void OnContextMenuSelect()
            {
                var clips = GetSelectedAssets();

                // assign to unity inspector.
                // this can cause a huge editor freeze
                Selection.objects = clips.ToArray();
            }
            #endregion

            #region Helper methods to get selected paths/models/assets
            /// <summary>
            /// Gets paths of all items that are currently selected in the list.
            /// </summary>
            List<string> GetSelectedPaths()
            {
                var paths = new List<string>();
                var selection = SelectedItems;

                for (var n = 0; n < selection.Length; ++n)
                {
                    var model = selection[n] as Model;
                    if (model == null)
                        continue;

                    var path = model.AssetPath;
                    if (model.Asset != null)
                        path = AssetDatabase.GetAssetPath(model.Asset);

                    if (!string.IsNullOrEmpty(path))
                        paths.Add(path);
                }

                return paths;
            }

            /// <summary>
            /// Gets assets of all items that are currently selected in the list.
            /// </summary>
            List<UnityEngine.Object> GetSelectedAssets()
            {
                var assets = new List<UnityEngine.Object>();
                var selection = SelectedItems;

                // getting asset means to load them. this is an expensive operation,
                // so we display a progressbar. it might also cause an out-of-memory
                // error in the editor, but nothing we can do about that.
                using (var progressbar = new EditorGUI2.ModalProgressBar("Loading assets...", true))
                {
                    for (var n = 0; n < selection.Length; ++n)
                    {
                        var model = selection[n] as Model;
                        if (model == null)
                            continue;

                        // display progress in 100ms intervals
                        if (progressbar.TotalElapsedTime > 1.0f && progressbar.ElapsedTime > 0.1f)
                        {
                            var progress = n / (float)selection.Length;
                            var text = string.Format("[{1} remaining] {0}", model.Name, selection.Length - n - 1);
                            if (progressbar.Update(text, progress))
                                break;
                        }

                        // load the asset
                        var asset = model.LoadAsset();
                        if (asset != null)
                            assets.Add(asset);
                    }

                    return assets;
                }
            }
            #endregion
        }
        #endregion

        /// <summary>
        /// The listbox at the left side. Contains the
        /// assets to find usages of.
        /// </summary>
        class LeftListbox : Listbox
        {
            #region ctor
            public LeftListbox(EditorWindow editor, GUIControl parent)
                : base(editor, parent)
            {
                var nameColumn = new Column("Name", "Name", 200, OnCompareAssetName, OnDrawAssetName);
                Columns.Add(nameColumn);

                var countColumn = new Column("Results", "Results", 60, OnCompareFindingsCount, OnDrawFindingsCount);
                Columns.Add(countColumn);

                MultiSelect = false;
            }
            #endregion

            #region Draw/Compare Number of results
            protected void OnDrawFindingsCount(Model m, GUIListViewDrawItemArgs args)
            {
                var model = m as FindAssetUsage.ResultEntry;
                GUI.Label(args.ItemRect, model.Findings.Count.ToString(), args.Selected ? EditorStyles.whiteLabel : EditorStyles.label);
            }

            protected int OnCompareFindingsCount(object x, object y)
            {
                var xx = x as FindAssetUsage.ResultEntry;
                var yy = y as FindAssetUsage.ResultEntry;
                return xx.Findings.Count.CompareTo(yy.Findings.Count);
            }
            #endregion
        }

        /// <summary>
        /// The listbox at the right side. Contains the
        /// results where assets are used.
        /// </summary>
        class RightListbox : Listbox
        {
            #region ctor
            public RightListbox(EditorWindow editor, GUIControl parent)
                : base(editor, parent)
            {
                EmptyText = "No assets found";

                Columns.Add(new Column("Name", "Name", 200, OnCompareAssetName, OnDrawAssetName));
                Columns.Add(new Column("Path", "Path", 400, OnCompareAssetPath, OnDrawAssetPath));
            }
            #endregion
        }

        #region Private Fields
        [SerializeField] FindAssetUsage.Result _result;
        [SerializeField] string _productId;
        [SerializeField] string _productTitle;
        Listbox _searchfor; // listbox at left side
        Listbox _searchresult; // listbox at right side
        float _splitterWidth; // the width of the space for the left listview
        #endregion

        #region FindUsageInProject
        /// <summary>
        /// Finds usages of the specified findpaths in assets of the specified findtypes.
        /// </summary>
        /// <param name="producttitle">The plugin title</param>
        /// <param name="findpaths">The paths of assets to find</param>
        /// <param name="findtypes">The types of assets to search in</param>
        public static void FindUsageInProject(string productid, string producttitle, IEnumerable<string> findpaths, IEnumerable<Type> findtypes)
        {
            var usages = FindAssetUsage.InProject(findpaths, findtypes);
            Show(productid, producttitle, usages);
        }

        /// <summary>
        /// Finds usages of the specified findpaths in assets of the specified findtypes.
        /// </summary>
        /// <param name="producttitle">The plugin title</param>
        /// <param name="findobjs">The assets to find</param>
        /// <param name="findtypes">The types of assets to search in</param>
        public static void FindUsageInProject(string productid, string producttitle, IEnumerable<UnityEngine.Object> findobjs, IEnumerable<Type> findtypes)
        {
            var usages = FindAssetUsage.InProject(findobjs, findtypes);
            Show(productid, producttitle, usages);
        }

        public static void FindUsageInProject(string productid, string producttitle, IEnumerable<Type> findobjs, IEnumerable<Type> findtypes)
        {
            var usages = FindAssetUsage.InProject(findobjs, findtypes);
            Show(productid, producttitle, usages);
        }
        #endregion

        #region Show
        /// <summary>
        /// Shows the usage results window.
        /// </summary>
        public static void Show(string productid, string producttitle, FindAssetUsage.Result result)
        {
            var wnd = FindAssetUsageWindow.GetWindow<FindAssetUsageWindow>(true, producttitle + " - Find Usage Results", true);
            wnd.ShowUtility();

            wnd.RebuildUI();
            wnd._result = result;
            wnd._productId = productid;
            wnd._productTitle = producttitle;
        }
        #endregion

        #region RebuildUI
        /// <summary>
        /// Causes the window to rebuild its UI on the next OnGUI. 
        /// </summary>
        void RebuildUI()
        {
            _searchresult = null;
            _searchfor = null;
            Repaint();
        }
        #endregion

        #region Init
        /// <summary>
        /// Initializes the UI.
        /// </summary>
        void Init()
        {
            if (_result == null)
                _result = new FindAssetUsage.Result();

            // listbox at left side
            _searchfor = new LeftListbox(this, null);
            if (!string.IsNullOrEmpty(_productId))
            {
                _searchfor.EditorPrefsPath = string.Format("{0}.FindAssetUsage.ListView1", _productId);
                _searchfor.LoadPrefs();
            }

            // add search items to the listbox
            var searchees = new List<Model>();
            foreach (var entry in _result.Entries)
                searchees.Add(entry);
            _searchfor.SetItems(searchees);

            // if an item gets selected in the listbox on the left side,
            // display its contents in the listbox on the right side.
            _searchfor.SelectionChange = delegate(GUIListView sender)
            {
                var dict = new Dictionary<Model, Model>();
                var selection = _searchfor.SelectedItems;
                for (var n = 0; n < selection.Length; ++n)
                {
                    var sel = selection[n];
                    foreach (var a in _result.Entries)
                    {
                        if (ReferenceEquals(a, sel))
                        {
                            foreach (var f in a.Findings)
                                dict[f] = f;
                        }
                    }
                }

                var items = new Model[dict.Keys.Count];
                var result = new object[dict.Keys.Count];
                dict.Keys.CopyTo(items, 0);

                _searchresult.SetItems(items);
            };

            // listbox at right side
            _searchresult = new RightListbox(this, null);
            if (!string.IsNullOrEmpty(_productId))
            {
                _searchresult.EditorPrefsPath = string.Format("{0}.FindAssetUsage.ListView2", _productId);
                _searchresult.LoadPrefs();
            }

            // read recent splitter value
            _splitterWidth = EditorPrefs.GetFloat(string.Format("{0}.FindAssetUsage.SplitterWidth", _productId), 300);

            // automatically select the first item
            if (_result.Entries.Count > 0)
                _searchfor.SelectItem(0);
        }
        #endregion

        #region OnDestroy
        /// <summary>
        /// Called by Unity when the window will be destroyed.
        /// </summary>
        void OnDestroy()
        {
            if (_searchfor != null)
                _searchfor.SavePrefs();

            if (_searchresult != null)
                _searchresult.SavePrefs();
        }
        #endregion

        #region OnGUI
        /// <summary>
        /// Called by Unity to draw the UI
        /// </summary>
        void OnGUI()
        {
            // check if we need to rebuild the ui
            if (_result == null || _searchresult == null || _searchfor == null)
                Init();

            EditorGUILayout.BeginHorizontal();

            // left listview
            EditorGUILayout.BeginHorizontal(GUILayout.Width(_splitterWidth));
            _searchfor.OnGUI();
            EditorGUILayout.EndHorizontal();

            // splitter
            if (EditorGUILayout2.HorizontalSplitter(ref _splitterWidth))
                EditorPrefs.SetFloat(string.Format("{0}.FindAssetUsage.SplitterWidth", _productId), _splitterWidth);
            _splitterWidth = Mathf.Clamp(_splitterWidth, Mathf.Max(64, position.width * 0.05f), Mathf.Min(position.width - 64, position.width * 0.95f));

            // right listview
            _searchresult.OnGUI();
            EditorGUILayout.EndHorizontal();
        }
        #endregion
    }
}
