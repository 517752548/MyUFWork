﻿//---------------------------------------
// Copyright (c) 2013-2017 Peter Schraut
// http://console-dev.de
//---------------------------------------
using UnityEngine;
using UnityEditor;
using System.Collections.Generic;

namespace EditorFramework
{
    public static class ProfilerUtility
    {
        [System.Diagnostics.Conditional("ENABLE_PROFILER")]
        public static void BeginSample(string name)
        {
#if UNITY_5_5_OR_NEWER
            UnityEngine.Profiling.Profiler.BeginSample(name);
#else
            UnityEngine.Profiler.BeginSample(name);
#endif
        }

        [System.Diagnostics.Conditional("ENABLE_PROFILER")]
        public static void EndSample()
        {
#if UNITY_5_5_OR_NEWER
            UnityEngine.Profiling.Profiler.EndSample();
#else
            UnityEngine.Profiler.EndSample();
#endif
        }

        public static long GetRuntimeMemorySize(UnityEngine.Object o)
        {
            long v = 0;

#if UNITY_5_6_OR_NEWER
            v = UnityEngine.Profiling.Profiler.GetRuntimeMemorySizeLong(o);
#elif UNITY_5_5_OR_NEWER
            v = UnityEngine.Profiling.Profiler.GetRuntimeMemorySize(o);
#else
            v = UnityEngine.Profiler.GetRuntimeMemorySize(o);
#endif
            return v;
        }
    }
}
