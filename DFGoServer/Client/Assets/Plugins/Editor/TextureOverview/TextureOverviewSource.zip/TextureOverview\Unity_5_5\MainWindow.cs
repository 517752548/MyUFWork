﻿//---------------------------------------
// Copyright (c) 2011-2017 Peter Schraut
// http://console-dev.de
//---------------------------------------

using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;
using UnityEditor;
using EditorFramework;

namespace TextureOverview
{
    /// <summary>
    /// MainWindow represents the main application window of the plugin.
    /// </summary>
    public class MainWindow : EditorWindow2
    {
        #region Private Fields
        enum PickMode
        {
            Selection,
            Project,
            Scene,
            AssetBundleManifest
        }

        GUIToolbar _menu; // top toolbar menu
        GUIToolbar _bottommenu; // bottom toolbar menu
        Listbox _listview; // the actual list where all texture settings are displayed
        PickMode _pickmode = PickMode.Project;
        GUIToolbarLabel _searchlabel; // displays information about the current search/filter (eg 10 / 1000 textures displayed)
        GUIToolbarLabel _statslabel; // displays info about the current list selection
        GUIToolbarMenu _typeMenu; // the 'Filter by Type' popup menu
        GUIToolbarButton _lockbutton; // in PickMode.Selection a buttton to lock the list content
        GUIToolbarSearchField _searchfield; // the control to enter a search text
        bool _locked; // whether the list content is locked
        TextureMemoryUsageOverlay _memoryUsage; // a reference to the memory usage overlay window
        AssetBundleManifestUI _manifestGUI;
        #endregion

        #region CreateWindow
        /// <summary>
        /// Called from TextureOverviewMenuItem.cs to create the window.
        /// This method checks if the plugin runs in the minimum required Unity version
        /// and displays a message in case it is not.
        /// </summary>
        public static EditorWindow CreateWindow()
        {
            var wnd = EditorWindow.GetWindow(typeof(MainWindow));
            wnd.titleContent = new GUIContent(Globals.ProductTitle);
            wnd.minSize = new Vector2(500, 150);
            return wnd;
        }
        #endregion

        #region OnCheckCompatibility
        /// <summary>
        /// Called before the window gets created.
        /// Checks if the plugin is compatible with the Unity version it is running in.
        /// </summary>
        protected override bool __OnCheckCompatibility()
        {
            if (!InstallerWindow.ValidateVersion(Globals.MinimumMajorVersion, Globals.MinimumMinorVersion,
                Globals.ProductTitle, Globals.ProductName, Globals.ProductFeedbackUrl))
                return false;

            return base.__OnCheckCompatibility();
        }
        #endregion

        #region OnCreate
        /// <summary>
        /// Called when the window gets created.
        /// This method creates all the controls.
        /// </summary>
        /// <remarks>
        /// Creation must be kept fast, otherwise the window gets displayed entirely white for a short moment.
        /// </remarks>
        protected override void __OnCreate()
        {
            var selectedPlatform = (BuildTargetGroup)EditorPrefs.GetInt(string.Format("{0}.Platform", Globals.ProductId), (int)BuildTargetGroup.Unknown);

            // create the listview control
            _listview = new Listbox(this, null);
            _listview.EditorPrefsPath = string.Format("{0}.ListView", Globals.ProductId);
            _listview.LoadPrefs();
            _listview.EmptyText = "Loading texture importer settings. Please wait...";
            _listview.SetPlatform(selectedPlatform);

            // create a toolbar control
            _menu = new GUIToolbar(this, null);

            // create tools submenu
            var toolsmenu = _menu.AddMenu("Tools", "", null);
            toolsmenu.Add(new GUIToolbarMenuItem("Export as CSV...", OnToolsExportCsvExecute));
            toolsmenu.Add(new GUIToolbarMenuItem("Memory Usage", OnToolsMemoryUsageExecute, OnToolsMemoryUsageQuery));
            toolsmenu.Add(GUIToolbarMenuItem.Separator);
            toolsmenu.Add(new GUIToolbarMenuItem("Advanced/Show assets from Editor directories", OnToolsShowEditorAssetsExecute, OnToolsShowEditorAssetsQuery));
#if UNITY_2017_3_OR_NEWER
            toolsmenu.Add(new GUIToolbarMenuItem("Advanced/Show assets from Packages", OnToolsShowPackageAssetsExecute, OnToolsShowPackageAssetsQuery));
#endif
            toolsmenu.Add(new GUIToolbarMenuItem("Advanced/Count Renderer (Scene mode only, EXPERIMENTAL)", OnToolsCountRendererExecute, OnToolsCountRendererQuery));
            toolsmenu.Add(new GUIToolbarMenuItem("Advanced/Handle RGB24 as RGBA32 on GPU", OnToolsGpuExpandRgb24ToRgba32Execute, OnToolsGpuExpandRgb24ToRgba32Query));
            toolsmenu.Add(new GUIToolbarMenuItem("Advanced/Rebuild Texture Overview Cache...", OnToolsRebuildCacheExecute));
            toolsmenu.Add(GUIToolbarMenuItem.Separator);
            toolsmenu.Add(new GUIToolbarMenuItem("About", OnToolsAbout));

            // add the 'Pickmode' popup control to the toolbar
            _pickmode = (PickMode)EditorPrefs.GetInt(string.Format("{0}.PickMode", Globals.ProductId), (int)_pickmode);
            var pickmodePopup = _menu.AddPopup("", "Select from where to list textures.", OnPickModeChange);
            pickmodePopup.Items = new[] { 
                new GUIToolbarPopupItem("Project", PickMode.Project),
                new GUIToolbarPopupItem("Scene", PickMode.Scene),
                new GUIToolbarPopupItem("Selection", PickMode.Selection),
                new GUIToolbarPopupItem("AssetBundle Manifest", PickMode.AssetBundleManifest)
            };
            pickmodePopup.SelectTag(_pickmode);

            // add the lock button which is only visible when pickmode is set to Selection.
            _lockbutton = _menu.AddButton("", "Selection changes within the Unity Project or Hierachy window have no impact on the list when it is locked.", null, OnLockToggle, OnQueryLockToggle);
            _lockbutton.ImageSize = new Vector2(13, 13);
            SetLock(false);

            var refreshbutton = _menu.AddButton("Refresh", "Get new snapshot of all textures used by GameObjects at this moment.", Images.Refresh16x16, OnRefreshScene, OnQueryRefreshScene);
            refreshbutton.ImageSize = new Vector2(13, 13);

            // add the search field to the right side of the window
            _menu.AddSpace(8);
            _menu.AddFlexibleSpace();
            _searchfield = _menu.AddSearchField("", null, OnSearchChange, null);
            _searchfield.SearchModes = new[] { "Search in All", "Search in Name", "Search in Path", "Search in Sprite Packing Tag" };
            _searchfield.SearchMode = EditorPrefs.GetInt(string.Format("{0}.TextFilterMode", Globals.ProductId), 0);
            _searchfield.LayoutOptions = new[] { GUILayout.MinWidth(50), GUILayout.MaxWidth(5000), GUILayout.ExpandWidth(true) };
            _searchfield.AcceptDrop = true;

            // Add type filer dropdown, use same sorting as in Unity Inspector.
            _typeMenu = _menu.AddMenu("", "Filter by Type", null);
            foreach (var entry in new[] {
                new Listbox.TypeFilter("Default", TextureImporterType.Default, TextureImporterShape.Texture2D),
                new Listbox.TypeFilter("Normal map", TextureImporterType.NormalMap, TextureImporterShape.Texture2D),
                new Listbox.TypeFilter("Editor GUI & Legacy UI", TextureImporterType.GUI, TextureImporterShape.Texture2D),
                new Listbox.TypeFilter("Sprite (2D & UI)", TextureImporterType.Sprite, TextureImporterShape.Texture2D),
                new Listbox.TypeFilter("Cubemap", TextureImporterType.Default, TextureImporterShape.TextureCube),
                new Listbox.TypeFilter("Cursor", TextureImporterType.Cursor, TextureImporterShape.Texture2D),
                new Listbox.TypeFilter("Cookie", TextureImporterType.Cookie, TextureImporterShape.Texture2D),
                new Listbox.TypeFilter("Lightmap", TextureImporterType.Lightmap, TextureImporterShape.Texture2D),
                new Listbox.TypeFilter("Single Channel", TextureImporterType.SingleChannel, TextureImporterShape.Texture2D) })
            {
                var item = new GUIToolbarMenuItem(entry.Name.Replace("&", "and"), OnTypeFilterExecute, OnQueryTypeFilter);
                item.Tag = entry;
                _typeMenu.Add(item);
            }

            _typeMenu.Add(GUIToolbarMenuItem.Separator); // separator
            _typeMenu.Add(new GUIToolbarMenuItem("Reset Type Filter", OnTypeFilterResetExecute) { Tag = 1 });
            _typeMenu.Image = EditorGUIUtility.FindTexture("FilterByType");
            if (_typeMenu.Image != null)
                _typeMenu.ImageSize = new Vector2(_typeMenu.Image.width, _typeMenu.Image.height);


            _menu.AddSpace(8);
            // unity 5 features per-platform audio settings.
            // therefore we add a platform selection radio button group to the
            // toolbar where the user can pick from which platform he wants to edit the settings.
            var radioGroup = _menu.AddRadioGroup();
            var radioDefaultButton = radioGroup.AddButton("Default", "Default settings", null, OnPlatformChange);
            radioDefaultButton.Tag = BuildTargetGroup.Unknown;
            var radioactivebutton = radioDefaultButton;
            var validplatforms = BuildPlayerWindow2.GetValidPlatforms();

            foreach (var platform in validplatforms)
            {
                var button = radioGroup.AddButton("", platform.DisplayName + " settings", platform.SmallIcon as Texture2D, OnPlatformChange);
                button.Tag = platform.TargetGroup;

                if (platform.TargetGroup == selectedPlatform)
                    radioactivebutton = button;
            }
            radioGroup.OnCheckedControl(radioactivebutton);



            // add the button info bar
            _bottommenu = new GUIToolbar(this, null);

            _statslabel = _bottommenu.AddLabel();
            _bottommenu.AddFlexibleSpace();
            _searchlabel = _bottommenu.AddLabel();
            
            // add some space at the right for the buttom menu.
            // this is especially important for OSX, where the window resize grabber is in the lower right corner of the window.
            // in order to prevent it to overlap with the info button, we simply add some space.
            _bottommenu.AddSpace(9);

            _memoryUsage = new TextureMemoryUsageOverlay();

            _manifestGUI = new AssetBundleManifestUI();
            _manifestGUI.EditorPrefsPath = string.Format("{0}.AssetBundleManifest", Globals.ProductId);
            _manifestGUI.Init(this);
            _manifestGUI.SelectionChange = OnShowAssetBundleManifestContent;
        }
        #endregion

        #region OnDestroy
        /// <summary>
        /// Called when the window gets destroyed
        /// </summary>
        protected override void __OnDestroy()
        {
            if (_manifestGUI != null)
            {
                _manifestGUI.SelectionChange -= OnShowAssetBundleManifestContent;
                _manifestGUI.Destroy();
                _manifestGUI = null;
            }

            if (null != _listview)
            {
                _listview.Changed -= OnListboxChanged;
                _listview.TextureChanged -= OnListboxTextureChanged;
                _listview.SavePrefs();
                _listview.Dispose();
                _listview = null;
            }

            Images.OnDestroy();
            UnityEditorInternal.InternalEditorUtility.RepaintAllViews();
        }
        #endregion

        #region OnInit
        /// <summary>
        /// Called after OnCreate and intented to initialize the plugin. This function is allowed to take longer.
        /// </summary>
        protected override void __OnInit()
        {
            _listview.ReadCacheFile();

            _listview.EmptyText = "The list is empty.";
            _listview.Changed += OnListboxChanged;
            _listview.TextureChanged += OnListboxTextureChanged;
            DoPickModeChange(_pickmode, true);

            if (_memoryUsage.Visible)
                UpdateMemoryUsage();
        }
        #endregion

        #region OnGUI
        /// <summary>
        /// Called periodically to handle and draw the UI.
        /// </summary>
        protected override void __OnGUI()
        {
            BeginWindows();

            EditorGUILayout.BeginVertical();
            {
                _menu.OnGUI();

                _typeMenu.Text = "";
                _typeMenu.Tint = null;
                if (_listview.GetTypeFilterCount() > 0)
                {
                    _typeMenu.Text = "!";
                    _typeMenu.Tint = new Color32(204, 194, 16, 128);
                }

                EditorGUILayout.BeginHorizontal();
                {
                    if (_manifestGUI != null && _pickmode == PickMode.AssetBundleManifest)
                        _manifestGUI.OnGUI();

                    EditorGUILayout.BeginVertical();
                    {
                        _listview.OnGUI();
                    }
                    EditorGUILayout.EndVertical();
                }
                EditorGUILayout.EndHorizontal();

                _bottommenu.OnGUI();
            }
            EditorGUILayout.EndVertical();

            if (_memoryUsage != null && _listview.Platform != BuildTargetGroup.Unknown)
                _memoryUsage.OnGUI(this);

            EndWindows();
        }
        #endregion

        #region OnFindCommand
        /// <summary>
        /// Called when the user invoked the find command (Ctrl+F).
        /// </summary>
        protected override void __OnFindCommand()
        {
            _searchfield.Focus();
        }
        #endregion

        #region OnLockToggle
        /// <summary>
        /// Called when the user clicked the Lock button.
        /// </summary>
        /// <remarks>The Lock button is available in Selection PickMode only.</remarks>
        void OnLockToggle(GUIControl sender)
        {
            SetLock(!_locked);
            Repaint();
        }

        /// <summary>
        /// Gets the UI status of the Lock button.
        /// </summary>
        GUIControlStatus OnQueryLockToggle(GUIControl sender)
        {
            var status = GUIControlStatus.None;
            if (_pickmode == PickMode.Selection)
                status |= GUIControlStatus.Visible | GUIControlStatus.Enable;

            return status;
        }

        /// <summary>
        /// Locks/Unlocks the Selection PickMode.
        /// </summary>
        /// <param name="locked">true to lock, false to unlock.</param>
        void SetLock(bool locked)
        {
            if (locked)
            {
                _lockbutton.Image = Images.Lock16x16;
                _lockbutton.Text = "Unlock";
            }
            else
            {
                _lockbutton.Image = Images.Unlock16x16;
                _lockbutton.Text = "Lock";
            }

            _locked = locked;
        }
        #endregion

        #region OnRefreshScene
        /// <summary>
        /// Called when the user pressed the Refresh button.
        /// </summary>
        /// <remarks>The Refresh button is available in Scene PickMode only.</remarks>
        void OnRefreshScene(GUIControl sender)
        {
            DoPickModeChange(PickMode.Scene, true);
            Repaint();
        }

        /// <summary>
        /// Gets the UI status of the Refresh button.
        /// </summary>
        GUIControlStatus OnQueryRefreshScene(GUIControl sender)
        {
            var status = GUIControlStatus.None;
            if (_pickmode == PickMode.Scene)
                status |= GUIControlStatus.Visible | GUIControlStatus.Enable;

            return status;
        }
        #endregion

        #region OnPlatformChange
        /// <summary>
        /// Called when the user switches the platform in the toolbar platform selection menu.
        /// </summary>
        void OnPlatformChange(GUIControl sender)
        {
            var platform = (BuildTargetGroup)sender.Tag;
            _listview.SetPlatform(platform);

            EditorPrefs.SetInt(string.Format("{0}.Platform", Globals.ProductId), (int)platform);
            Repaint();
        }
        #endregion

        #region OnToolsExportCsv
        /// <summary>
        /// Exports the listbox content as CSV.
        /// </summary>
        void OnToolsExportCsvExecute(GUIToolbarMenuItem sender)
        {
            _listview.SaveCsv();
        }
        #endregion

        #region OnToolsMemoryUsage
        /// <summary>
        /// Opens the Memory Usage window.
        /// </summary>
        void OnToolsMemoryUsageExecute(GUIToolbarMenuItem sender)
        {
            _memoryUsage.Visible = !_memoryUsage.Visible;
            if (_memoryUsage.Visible)
                UpdateMemoryUsage();
        }

        GUIControlStatus OnToolsMemoryUsageQuery(GUIToolbarMenuItem sender)
        {
            var result = GUIControlStatus.Visible;
            if (_listview.Platform != BuildTargetGroup.Unknown)
                result |= GUIControlStatus.Enable;

            if (_memoryUsage.Visible)
                result |= GUIControlStatus.Checked;
            return result;
        } 
        #endregion

        void OnToolsRebuildCacheExecute(GUIToolbarMenuItem sender)
        {
            var text = "Rebuilding the Texture Overview Cache often helps if Texture Overview displays invalid/non-sense data, that could occur when switching between different Unity versions or installing/uninstalling Platform modules.\n\nRebuilding the Cache might take a while to complete, but can be canceled and resumed at any time.\n\nDo you want to continue?";
            if (!EditorUtility.DisplayDialog(Globals.ProductTitle, text, "Rebuild", "Cancel"))
                return;

            _listview.DeleteCacheFile();
            _listview.ReadCacheFile();
            DoPickModeChange(_pickmode, true);
        }

        void OnToolsAbout(GUIToolbarMenuItem sender)
        {
            var wnd = AboutWindow.GetWindow<AboutWindow>(true, "About " + Globals.ProductTitle, true);
            wnd.ProductName = Globals.ProductName;
            wnd.FeedbackUrl = Globals.ProductFeedbackUrl;
            wnd.AssetStoreUrl = Globals.ProductAssetStoreUrl;
            wnd.Show();
        }

        #region OnToolsGpuExpandRgb24ToRgba32
        /// <summary>
        /// Toggle the GpuExpandRgb24ToRgba32 option.
        /// </summary>
        void OnToolsGpuExpandRgb24ToRgba32Execute(GUIToolbarMenuItem sender)
        {
            Globals.GpuExpandRgb24ToRgba32 = !Globals.GpuExpandRgb24ToRgba32;           
            _listview.RefreshModels();
        }

        GUIControlStatus OnToolsGpuExpandRgb24ToRgba32Query(GUIToolbarMenuItem sender)
        {
            var result = GUIControlStatus.Visible | GUIControlStatus.Enable;
            if (Globals.GpuExpandRgb24ToRgba32)
                result |= GUIControlStatus.Checked;
            return result;
        }
        #endregion

        #region OnToolsCountRenderer
        void OnToolsCountRendererExecute(GUIToolbarMenuItem sender)
        {
            Globals.CountRendererInSceneMode = !Globals.CountRendererInSceneMode;           
        }

        GUIControlStatus OnToolsCountRendererQuery(GUIToolbarMenuItem sender)
        {
            var result = GUIControlStatus.Visible | GUIControlStatus.Enable;
            if (Globals.CountRendererInSceneMode)
                result |= GUIControlStatus.Checked;
            return result;
        }
        #endregion

        #region OnToolsShowEditorAssets
        void OnToolsShowEditorAssetsExecute(GUIToolbarMenuItem sender)
        {
            Globals.ShowEditorAssets = !Globals.ShowEditorAssets;
            DoPickModeChange(_pickmode, false);
        }

        GUIControlStatus OnToolsShowEditorAssetsQuery(GUIToolbarMenuItem sender)
        {
            var result = GUIControlStatus.Visible | GUIControlStatus.Enable;
            if (Globals.ShowEditorAssets)
                result |= GUIControlStatus.Checked;
            return result;
        }
        #endregion

        #region OnToolsShowPackageAssets
        void OnToolsShowPackageAssetsExecute(GUIToolbarMenuItem sender)
        {
            Globals.ShowPackageAssets = !Globals.ShowPackageAssets;
            DoPickModeChange(_pickmode, false);
        }

        GUIControlStatus OnToolsShowPackageAssetsQuery(GUIToolbarMenuItem sender)
        {
            var result = GUIControlStatus.Visible | GUIControlStatus.Enable;
            if (Globals.ShowPackageAssets)
                result |= GUIControlStatus.Checked;
            return result;
        }
        #endregion

        #region OnListboxChanged
        /// <summary>
        /// Called when the listbox changed.
        /// </summary>
        void OnListboxChanged(GUIListView sender)
        {
            _searchlabel.Text = _listview.ItemCountString;
            _statslabel.Text = _listview.SelectionString;
            UpdateMemoryUsage();
        }
        #endregion

        #region OnListboxTextureChanged
        /// <summary>
        /// Called when texture properties of an item inside the listbox changed.
        /// </summary>
        void OnListboxTextureChanged(GUIListView sender)
        {
            UpdateMemoryUsage();
        }

        /// <summary>
        /// Gets the current memory usage of textures shown in listbox.
        /// </summary>
        void UpdateMemoryUsage()
        {
            if (!_memoryUsage.Visible)
                return;

            _listview.GetMemoryUsage(out _memoryUsage.CpuUsage, out _memoryUsage.GpuUsage, out _memoryUsage.RuntimeUsage, out _memoryUsage.StorageUsage);
            Repaint();
        }
        #endregion

        #region OnSearchChange
        /// <summary>
        /// Called when the search text or type changed.
        /// </summary>
        void OnSearchChange(GUIControl sender)
        {
            var searchfield = (GUIToolbarSearchField)sender;
            EditorPrefs.SetInt(string.Format("{0}.TextFilterMode", Globals.ProductId), searchfield.SearchMode);
            _listview.SetTextFilter(searchfield.Text, (Listbox.TextFilterMode)searchfield.SearchMode);

            if (_listview.ItemCount == 0 && !string.IsNullOrEmpty(sender.Text))
                _listview.EmptyText = "No match found. Proper search mode used?\n\nYou can choose the search mode using the magnifying glass next to the search field.\nYou can drop files and folders on the search field.\nYou can use search operators like: && (and) || (or) and ! (not)";
            else
                _listview.EmptyText = "The list is empty.";
        }
        #endregion

        #region OnSelectionChange
        /// <summary>
        /// Called when the listbox selection changed.
        /// </summary>
        void OnSelectionChange()
        {
            if (_listview == null)
                return;

            // I'm not really happy with this line of code, particulary with the 'ChangeUnitySelectionTime'.
            // it makes sure that the OnSelectionChange() call only has an impact when any selection change
            // caused by the list is more than 0.5 seconds ago. without this line of code, the plugin most
            // likely ends up in an infinite loop when being in PickMode.Selection, because if the list assigns
            // the selection unity triggers OnSelectionChange() and without the 0.5sec delay the selection is
            // assigned to the list immediately and OnSelectionChange() is called again etc.
            if (_pickmode != PickMode.Selection || _locked || _listview.ChangeUnitySelectionTime + 0.5f > DateTime.Now.TimeOfDay.TotalSeconds)// || selection.Length == 0)
                return;

            // get the current selection
            var selection = Selection.objects;

            var paths = new List<string>();
            selection = EditorUtility.CollectDependencies(selection);

            // get all textures from selection
            var selectionpaths = new List<string>();
            foreach (var obj in selection)
            {
                if (obj is Texture)
                {
                    var path = AssetDatabase.GetAssetPath(obj);
                    if (!string.IsNullOrEmpty(path))
                        paths.Add(path);
                }
            }

            // now paths only contains paths of textures
            _listview.SetItems(paths);

            UpdateMemoryUsage();
        }
        #endregion

        void OnShowAssetBundleManifestContent(List<AssetBundleManifest2> manifests)
        {
            var assets = new List<string>();
            foreach (var manifest in manifests)
                assets.AddRange(manifest.Assets);

            _listview.SetItems(assets);
        }

        #region OnPickModeChange
        /// <summary>
        /// Called when the pick mode (Project, Scene, Selection) changed.
        /// </summary>
        void OnPickModeChange(GUIControl sender)
        {
            var popup = (GUIToolbarPopup)sender;

            SetLock(false);
            _pickmode = (PickMode)popup.SelectedItem.Tag;
            EditorPrefs.SetInt(string.Format("{0}.PickMode", Globals.ProductId), (int)_pickmode);
            DoPickModeChange(_pickmode, false);
        }

        void DoPickModeChange(PickMode newpickmode, bool checkTimeStamp)
        {
            _listview.SetSceneOccurrenceLookup(null);
            switch (newpickmode)
            {
                case PickMode.AssetBundleManifest:
                    _listview.SetItems(new List<string>());
                    break;

                case PickMode.Selection:
                    _listview.SetItems(new List<string>());
                    OnSelectionChange();
                    break;

                case PickMode.Scene:
                    {
                        var deps = new List<UnityEngine.Object>(EditorUtility.CollectDependencies(EditorUtility2.GetSceneRootObjects().ToArray()));

                        // If a skybox is assigned, make sure to add it to the list
                        if (RenderSettings.skybox != null)
                            deps.AddRange(EditorUtility.CollectDependencies(new[] { RenderSettings.skybox }));

                        if (Globals.CountRendererInSceneMode)
                        {
                            var lookup = CountRendererInScene();
                            _listview.SetSceneOccurrenceLookup(lookup);
                        }

                        var paths = new List<string>(128);
                        foreach (var obj in deps)
                        {
                            if (!(obj is Texture))
                                continue; // we're interested in textures only

                            var path = AssetDatabase.GetAssetPath(obj);
                            if (!string.IsNullOrEmpty(path))
                                paths.Add(path);
                        }

                        _listview.SetItems(paths);
                    }
                    break;

                case PickMode.Project:
                    _listview.SetItems(new List<string>(AssetDatabase.GetAllAssetPaths()));
                    break;
            }

            UpdateMemoryUsage();
        }

        Dictionary<string, int> CountRendererInScene()
        {
            var lookup = new Dictionary<string, int>();
            foreach (var root in EditorUtility2.GetSceneRootObjects())
            {
                CountRendererInSceneRecursive(root.transform, lookup);
            }
            return lookup;
        }

        void CountRendererInSceneRecursive(Transform parent, Dictionary<string, int> lookup)
        {
            if (parent == null)
                return;

            var renderer = parent.GetComponent<Renderer>();
            if (renderer != null)
            {
                var deps = EditorUtility.CollectDependencies(renderer.sharedMaterials);
                foreach (var obj in deps)
                {
                    var texture = obj as Texture;
                    if (texture == null)
                        continue; // we're interested in textures only

                    var path = AssetDatabase.GetAssetPath(obj);
                    if (string.IsNullOrEmpty(path))
                        continue; // does not exist in project

                    var guid = AssetDatabase.AssetPathToGUID(path);
                    if (string.IsNullOrEmpty(guid))
                        continue; // does not exist in project

                    int count;
                    if (!lookup.TryGetValue(guid, out count))
                        lookup[guid] = count = 0;

                    count++;
                    lookup[guid] = count;
                }
            }

            for (int n = 0, nend = parent.childCount; n < nend; ++n)
            {
                var child = parent.GetChild(n);
                if (child != null)
                    CountRendererInSceneRecursive(child, lookup);
            }
        }
        #endregion

        #region OnTypeFilter
        /// <summary>
        /// Called when the user changed the texture type filter.
        /// </summary>
        void OnTypeFilterExecute(GUIToolbarMenuItem sender)
        {
            _listview.BeginChangeFilter();
            try
            {
                var filter = sender.Tag as Listbox.TypeFilter;

                // toggle filter
                if (_listview.HasTypeFilter(filter))
                    _listview.RemoveTypeFilter(filter);
                else
                    _listview.AddTypeFilter(filter);

                Repaint();
            }
            finally
            {
                _listview.EndChangeFilter();
            }
        }

        /// <summary>
        /// Gets the UI status of one type filter item.
        /// </summary>
        GUIControlStatus OnQueryTypeFilter(GUIToolbarMenuItem sender)
        {
            var result = GUIControlStatus.Visible | GUIControlStatus.Enable;
            if (_listview.HasTypeFilter(sender.Tag as Listbox.TypeFilter))
                result |= GUIControlStatus.Checked;

            return result;
        }

        /// <summary>
        /// Called when the user clicked the Reset Type Filter item.
        /// </summary>
        void OnTypeFilterResetExecute(GUIToolbarMenuItem sender)
        {
            _listview.ClearTypeFilter();
        }
        #endregion
    }
}
