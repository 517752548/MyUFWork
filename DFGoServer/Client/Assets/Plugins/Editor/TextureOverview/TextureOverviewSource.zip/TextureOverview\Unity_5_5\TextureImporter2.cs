﻿//---------------------------------------
// Copyright (c) 2011-2016 Peter Schraut
// http://console-dev.de
//---------------------------------------

using System;
using System.Reflection;
using UnityEngine;
using UnityEditor;

namespace EditorFramework
{
    /// <summary>
    /// TextureImporter2 provides various methods to read properties of a TextureImporter.
    /// </summary>
    /// <remarks>
    /// Some methods are actually available in UnityEditor.TextureImporter, but they are not public in there.
    /// </remarks>
    public static class TextureImporter2
    {
        static Type _type;
        static MethodInfo _getWidthAndHeight;

        static TextureImporter2()
        {
            _type = typeof(TextureImporter).Assembly.GetType("UnityEditor.TextureImporter");
            if (null == _type)
            {
                Debug.LogWarning("Could not find type 'TextureImporter'.");
                return;
            }

            // https://feedback.unity3d.com/suggestions/textureimporter-api-to-retrieve-width-slash-height-of-source-texture
            _getWidthAndHeight = _type.GetMethod("GetWidthAndHeight", BindingFlags.Instance | BindingFlags.NonPublic, null, new[] { typeof(int).MakeByRefType(), typeof(int).MakeByRefType() }, null);
            if (null == _getWidthAndHeight)
                Debug.LogWarning("Could not find method 'TextureImporter.GetWidthAndHeight(ref int, ref int)'.");
        }

        /// <summary>
        /// Gets the width and height of the source texture asset.
        /// </summary>
        /// <param name="importer">The TextureImporter</param>
        /// <param name="width">The output width</param>
        /// <param name="height">The output height</param>
        public static void GetWidthAndHeight(TextureImporter importer, ref int width, ref int height)
        {
            if (null == _getWidthAndHeight)
                return;

            var args = new object[] { width, height };
            _getWidthAndHeight.Invoke(importer, args);
            width = (int)args[0];
            height = (int)args[1];
        }
    }
}
