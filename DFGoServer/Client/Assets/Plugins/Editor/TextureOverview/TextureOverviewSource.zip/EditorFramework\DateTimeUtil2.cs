﻿//---------------------------------------
// Copyright (c) 2012-2014 Peter Schraut
// http://console-dev.de
//---------------------------------------

using System;

namespace EditorFramework
{
    /// <summary>
    /// Helper class to convert date and time to formatted text.
    /// </summary>
    public static class DateTimeUtil2
    {
        #region GetPrettyDateTimeString
        /// <summary>
        /// Gets a formatted text representation of the specified datetime.
        /// </summary>
        /// <param name="datetime">The DateTime.</param>
        /// <returns>Returns the text. Dates not too far in the past are displayed as 'Today' for example.</returns>
        public static string GetPrettyDateTimeString(DateTime datetime)
        {
            if (datetime.Date == DateTime.Today)
                return string.Format("Today {0}", datetime.ToShortTimeString());

            //else if (LastWriteTime.Date == DateTime.Today.Subtract(new TimeSpan(1, 0, 0, 0)))
            //    LastWriteTimeString = string.Format("Yesterday {0}", LastWriteTime.ToShortTimeString());
            return string.Format("{0} {1}", datetime.ToShortDateString(), datetime.ToShortTimeString());
        }
        #endregion
    }
}
