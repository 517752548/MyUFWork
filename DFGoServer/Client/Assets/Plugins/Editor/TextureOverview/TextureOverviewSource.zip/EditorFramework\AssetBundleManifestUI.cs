//---------------------------------------
// Copyright (c) 2013-2015 Peter Schraut
// http://console-dev.de
//---------------------------------------

using UnityEngine;
using UnityEditor;
using System;
using System.Collections.Generic;

namespace EditorFramework
{
    public class AssetBundleManifestUI
    {
        #region Private Fields
        GUIToolbar _menu;
        EditorWindow _owner;
        Listbox _listbox;
        DependencyListbox _dependencyListbox;
        GUIToolbarSearchField _searchfield; // the control to enter a search text
        List<string> _files = new List<string>();

        string EditorPrefsPrefix
        {
            get
            {
                return string.Format("{0}.{1}", EditorPrefsPath, GetType().Name);
            }
        }

        public float Width
        {
            get
            {
                return EditorPrefs.GetFloat(string.Format("{0}.Width", EditorPrefsPrefix), 200);
            }
            private set
            {
                EditorPrefs.SetFloat(string.Format("{0}.Width", EditorPrefsPrefix), value);
            }
        }

        float BundleDependencySplitter
        {
            get
            {
                return EditorPrefs.GetFloat(string.Format("{0}.BundleDependencySplitter", EditorPrefsPrefix), 200);
            }
            set
            {
                EditorPrefs.SetFloat(string.Format("{0}.BundleDependencySplitter", EditorPrefsPrefix), value);
            }
        }

        string Directory
        {
            get
            {
                // Check if the directory was set for this project.
                var projectPath = EditorPrefs.GetString(string.Format("{0}.Project", EditorPrefsPrefix), "");
                if (!string.Equals(projectPath, Application.dataPath, StringComparison.OrdinalIgnoreCase))
                    return "";

                return EditorPrefs.GetString(string.Format("{0}.Directory", EditorPrefsPrefix), "");
            }
            set
            {
                EditorPrefs.SetString(string.Format("{0}.Directory", EditorPrefsPrefix), value);
                EditorPrefs.SetString(string.Format("{0}.Project", EditorPrefsPrefix), Application.dataPath);
            }
        }
        #endregion

        #region Public Fields
        public string EditorPrefsPath;
        public System.Action<List<AssetBundleManifest2>> SelectionChange;
        #endregion

        public void Init(EditorWindow owner)
        {
            _owner = owner;

            _menu = new GUIToolbar(owner, null);
            _menu.AddButton("Open...", "Locate *.manifest directory", null, OnClickedOpen);
            _menu.AddButton("", "Refresh list. Loads *.manifest files from recently selected directory.", Images.Refresh16x16, OnClickRefresh, OnQueryRefresh);

            _menu.AddSpace(8);
            _menu.AddFlexibleSpace();
            _searchfield = _menu.AddSearchField("", null, OnSearchChange, null);

            _listbox = new Listbox(owner, null);
            _listbox.EditorPrefsPath = string.Format("{0}.BundleListbox", EditorPrefsPath);
            _listbox.SelectionChange += OnListboxSelectionChanged;
            _listbox.LoadPrefs();

            _dependencyListbox = new DependencyListbox(owner, null);
            _dependencyListbox.EditorPrefsPath = string.Format("{0}.DependencyListbox", EditorPrefsPath);
            _dependencyListbox.LoadPrefs();
            _dependencyListbox.ItemDoubleClick += OnDoubleClickDependency;

            if (!string.IsNullOrEmpty(Directory))
                LoadFiles(Directory);
        }

        public void Destroy()
        {
            SelectionChange = null;

            if (_listbox != null)
            {
                _listbox.SavePrefs();
                _listbox.SelectionChange -= OnListboxSelectionChanged;
                _listbox = null;
            }

            if (_dependencyListbox != null)
            {
                _dependencyListbox.SavePrefs();
                _dependencyListbox.ItemDoubleClick -= OnDoubleClickDependency;
                _dependencyListbox = null;
            }
        }

        #region Refresh
        void OnClickRefresh(GUIControl sender)
        {
            LoadFiles(Directory);
        }

        GUIControlStatus OnQueryRefresh(GUIControl sender)
        {
            var status = GUIControlStatus.Visible;
            if (!string.IsNullOrEmpty(Directory))
                status |= GUIControlStatus.Enable;

            return status;
        }
        #endregion

        void OnDoubleClickDependency(GUIListView sender, GUIListViewItemDoubleClickArgs args)
        {
            var model = args.Model as DependencyListbox.Model;
            if (model == null)
                return;

            _listbox.SelectedBundlePaths = new List<string>(new[] { model.Path });
            _listbox.Focus();
        }

        void OnListboxSelectionChanged(GUIListView sender)
        {
            var manifests = new List<AssetBundleManifest2>();

            if (sender.SelectedItemsCount > 0)
            {
                foreach (var item in sender.SelectedItems)
                {
                    var model = item as Listbox.Model;
                    if (model == null || string.IsNullOrEmpty(model.Name))
                        return;

                    var path = string.Format("{0}/{1}.manifest", Directory, model.Name);
                    var manifest = AssetBundleManifestParser.Load(path);

                    manifests.Add(manifest);
                }
            }

            _dependencyListbox.Clear();
            _dependencyListbox.EmptyText = "The list is empty.";
            if (manifests.Count == 1)
            {
                _dependencyListbox.EmptyText = string.Format("'{0}' has no AssetBundle dependencies.", manifests[0].Name);

                var model = manifests[0];
                var paths = new List<string>();
                foreach (var dependency in model.Dependencies)
                {
                    var path = System.IO.Path.Combine(System.IO.Path.GetDirectoryName(model.Path), dependency + ".manifest").Replace('\\', '/');
                    paths.Add(path);
                }
                _dependencyListbox.SetItems(paths);
            }
            else if (manifests.Count > 1)
            {
                _dependencyListbox.EmptyText = "Select only one bundle to display dependencies.";
            }

            if (SelectionChange != null)
            {
                var copy = SelectionChange;
                copy.Invoke(manifests);
            }
        }

        void OnClickedOpen(GUIControl sender)
        {
            var directory = EditorUtility.OpenFolderPanel("Locate AssetBundle Manifest directory...", Directory, "");
            if (!string.IsNullOrEmpty(directory))
                LoadFiles(directory);
        }

        #region OnSearchChange
        /// <summary>
        /// Called when the search text or type changed.
        /// </summary>
        void OnSearchChange(GUIControl sender)
        {
            var searchfield = (GUIToolbarSearchField)sender;
            _listbox.SetTextFilter(searchfield.Text);

            if (_listbox.ItemCount == 0 && !string.IsNullOrEmpty(sender.Text))
                _listbox.EmptyText = "No match found.\nYou can use search operators like: && (and) || (or) and ! (not)";
            else
                _listbox.EmptyText = "The list is empty.";
        }
        #endregion

        void LoadFiles(string directory)
        {
            if (!System.IO.Directory.Exists(directory))
            {
                _owner.ShowNotification(new GUIContent(string.Format("Directory does not exist.\n'{0}'", directory)));
                _listbox.SelectedItems = null;
                _listbox.Clear();
                return;
            }

            var selection = _listbox.SelectedBundlePaths;
            _listbox.Clear();

            var items = new List<Listbox.Model>();
            var files = System.IO.Directory.GetFiles(directory, "*.manifest");
            foreach (var path in files)
            {
                var filename = System.IO.Path.GetFileNameWithoutExtension(path);
                var filesize = 0L;
                
                var bundlepaths = new[]{System.IO.Path.Combine(directory, filename), System.IO.Path.Combine(directory, filename + ".unity3d")};
                foreach (var bundlepath in bundlepaths)
                {
                    if (System.IO.File.Exists(bundlepath))
                    {
                        filesize = new System.IO.FileInfo(bundlepath).Length;
                        break;
                    }
                }

                var model = new Listbox.Model();
                model.Name = filename;
                model.Path = path.Replace('\\', '/');
                model.Size = filesize;

                items.Add(model);
            }

            _listbox.SetItems(items);
            Directory = directory;

            _listbox.SelectedBundlePaths = selection;
        }

        #region OnGUI
        public void OnGUI()
        {
            EditorGUILayout.BeginVertical(GUILayout.Width(Width));

            _menu.OnGUI();
            _listbox.OnGUI();

            GUILayout.Space(2);
            EditorGUILayout.BeginVertical(GUILayout.Height(BundleDependencySplitter));
            {
                var height = BundleDependencySplitter;
                EditorGUILayout2.VerticalSplitter(ref height);
                height = Mathf.Clamp(height, 30, _owner.position.height * 0.8f);
                if (!Mathf.Approximately(height, BundleDependencySplitter))
                {
                    BundleDependencySplitter = height;

                    var editor = _owner as EditorWindow2;
                    if (editor != null)
                        editor.TriggerResize();
                }

                _dependencyListbox.OnGUI();
            }
            EditorGUILayout.EndVertical();

            EditorGUILayout.EndVertical();

            var width = Width;
            EditorGUILayout2.HorizontalSplitter(ref width);
            width = Mathf.Clamp(width, 30, _owner.position.width * 0.8f);
            if (!Mathf.Approximately(width, Width))
            {
                Width = width;

                var editor = _owner as EditorWindow2;
                if (editor != null)
                    editor.TriggerResize();
            }
        }
        #endregion

        public class Listbox : GUIListView
        {
            public class Model
            {
                public string Name;
                public string Path;
                public long Size;
                public AssetBundleManifest2 Manifest;
            }

            public int ItemCount
            {
                get
                {
                    return _items.Count;
                }
            }

            #region class Column
            /// <summary>
            /// The Column class represents one column in the list header.
            /// </summary>
            class Column : GUIListViewColumn
            {
                public delegate void ColumnDrawer(Model model, GUIListViewDrawItemArgs args);
                public delegate int CompareDelegate2(Model x, Model y);

                /// <summary>
                /// Occurs when the model gets drawn.
                /// </summary>
                public ColumnDrawer Drawer;

                /// <summary>
                /// Occurs when the column gets sorted.
                /// </summary>
                public CompareDelegate2 Comparer;

                /// <summary>
                /// Initializes a new instance of the Column class.
                /// </summary>
                public Column(string serializeName, string text, string tooltip, float width, ColumnDrawer drawer, CompareDelegate2 comparer)
                    : base(text, tooltip, null, width, null)
                {
                    base.SerializeName = serializeName;
                    this.Drawer = drawer;
                    this.Comparer = comparer;

                    // detour the base comparer callback to our CompareFuncImpl method
                    if (null != comparer)
                        this.CompareFunc = CompareFuncImpl;
                }

                int CompareFuncImpl(object x, object y)
                {
                    return this.Comparer(x as Model, y as Model);
                }
            }
            #endregion

            List<Model> _items = new List<Model>();
            List<Model> _allitems = new List<Model>();
            SearchTextParser.Result _filterResult = new SearchTextParser.Result();

            public List<string> SelectedBundlePaths
            {
                get
                {
                    var result = new List<string>();
                    var selection = this.SelectedItems;
                    foreach (var item in selection)
                    {
                        var model = item as Model;
                        result.Add(model.Path);
                    }
                    return result;
                }
                set
                {
                    if (value == null)
                    {
                        Clear();
                        return;
                    }

                    var selection = new List<System.Object>();
                    foreach (var path in value)
                    {
                        var model = GetModelFromPath(path);
                        if (model == null)
                            continue;

                        selection.Add(model);
                    }

                    SelectedItems = selection.ToArray();
                }
            }

            public Listbox(EditorWindow editor, GUIControl parent)
                : base(editor, parent)
            {
                HeaderStyle = GUIListViewHeaderStyle.ClickablePopup;
                MultiSelect = true;
                DragDropEnabled = false;
                RightClickSelect = true;
                Mode = GUIListViewMode.Details;
                ItemSize = new Vector2(0, 22);
                FullRowSelect = true;

                Columns.Add(new Column("Name", "Bundle", "The asset bundle manifest file. The tool searches in this file to find assets that are stored in the bundle (assets that have been added explicitly).\nIt does NOT load the actual asset bundle.", 150, OnDrawName, OnCompareName));
                Columns.Add(new Column("Size", "Size", "Asset bundle file size of this particular manifest file. The asset bundle must be in the same directory as the manifest file and either end with .unity3d or have no file extension at all.", 80, OnDrawSize, OnCompareSize));
            }

            public void Clear()
            {
                _items.Clear();
                _allitems.Clear();

                DoChanged();
            }

            public void SetItems(List<Model> items)
            {
                _allitems = new List<Model>(items);

                UpdateFilter();
                Sort();
                DoChanged();
            }

            public void SetTextFilter(string text)
            {
                _filterResult = SearchTextParser.Parse(text);

                UpdateFilter();
                Sort();
                DoChanged();
            }

            void UpdateFilter()
            {
                _items = new List<Model>(_allitems.Count);
                foreach (var model in _allitems)
                {
                    if (IsIncludedInFilter(model))
                        _items.Add(model);
                }
            }

            bool IsIncludedInFilter(Model model)
            {
                if (_filterResult.NamesExpr.Count == 0)
                    return true;

                return _filterResult.IsNameMatch(model.Name);
            }

            Model GetModelFromPath(string path)
            {
                foreach (var model in _items)
                {
                    if (string.Equals(model.Path, path, StringComparison.OrdinalIgnoreCase))
                        return model;
                }
                return null;
            }

            #region Sorting
            protected override object[] OnBeforeSortItems()
            {
                return _items.ToArray();
            }

            protected override void OnAfterSortItems(object[] models)
            {
                _items.Clear();
                _items.AddRange((Model[])models);
            }
            #endregion

            #region OnGetItemKeyword
            /// <summary>
            /// Gets the item keyword for the specified args.
            /// </summary>
            /// <remarks>
            /// The item-keyword is used to jump to a particular item in the list
            /// when the user pressed a key. When a model begins with the keyword(sequence) the list jumps to it.
            /// </remarks>
            protected override string OnGetItemKeyword(GUIListViewGetItemKeywordArgs args)
            {
                var model = args.Model as Model;
                if (model != null)
                    return model.Name;

                return null;
            }
            #endregion

            #region GetSelectedPaths
            /// <summary>
            /// Gets all paths that are currently selected in in the tool.
            /// </summary>
            List<string> GetSelectedPaths()
            {
                var selection = SelectedItems;
                var paths = new List<string>(selection.Length);
                foreach (var item in selection)
                {
                    var model = item as Model;
                    if (!string.IsNullOrEmpty(model.Path))
                        paths.Add(model.Path);
                }
                return paths;
            }
            #endregion

            #region OnItemContextMenu
            /// <summary>
            /// Occurs when the user requests the context menu.
            /// </summary>
            protected override void OnItemContextMenu(GUIListViewContextMenuArgs args)
            {
                base.OnItemContextMenu(args);

                if (SelectedItemsCount < 1)
                    return; // no item selected, do not open a context menu

                GUIUtility.hotControl = 0;
                var model = args.Model as Model;

                var menu = new GenericMenu();
                menu.AddItem(new GUIContent(Application.platform == RuntimePlatform.OSXEditor ? "Reveal in Finder" : "Show in Explorer"), false, SelectedItemsCount <= 10 ? OnContextMenuShowInExplorer : (GenericMenu.MenuFunction2)null, model);
                menu.AddItem(new GUIContent(string.Empty), false, null);
                menu.AddItem(new GUIContent("Copy Full Path"), false, OnContextMenuCopyFullPath);

                // display the context menu. make sure to use the provided args.MenuLocation position
                // rather than 'Event.current.mousePosition', because the user could have been pressed
                // the context-menu key as well, thus mousePosition would be most likely wrong.
                menu.DropDown(new Rect(args.MenuLocation.x, args.MenuLocation.y, 0, 0));
                Event.current.Use();
                Editor.Repaint();
            }

            void OnContextMenuShowInExplorer(object userData)
            {
                var objects = GetSelectedPaths();
                EditorApplication2.ShowInExplorer(objects.ToArray());
                Editor.Repaint();
            }

            void OnContextMenuCopyFullPath()
            {
                var paths = GetSelectedPaths();
                ClipboardUtil.CopyPaths(paths);
            }
            #endregion

            #region OnGetItem
            protected override object OnGetItem(int index)
            {
                if (index < 0 || index >= _items.Count)
                    return null;

                return _items[index];
            }
            #endregion

            #region OnGetItemCount
            protected override int OnGetItemCount()
            {
                return _items.Count;
            }
            #endregion

            #region OnDrawItem
            protected override void OnDrawItem(GUIListViewDrawItemArgs args)
            {
                var model = (Model)args.Model;
                if (model == null)
                    return;

                var column = args.Column as Column;
                if (column == null)
                    return;

                if (column.IsPrimaryColumn)
                    DrawItemImageHelper(ref args.ItemRect, Images.AssetBundle16x16, Vector2.one * 16);

                column.Drawer(model, args);          
            }
            #endregion

            #region Draw/Compare Manifest Name
            void OnDrawName(Model model, GUIListViewDrawItemArgs args)
            {
                args.ItemRect.y += 3;
                EditorGUI2.PathLabel(args.ItemRect, model.Name, args.Selected);
            }

            int OnCompareName(Model x, Model y)
            {
                return string.Compare(x.Name, y.Name, StringComparison.OrdinalIgnoreCase);
            }
            #endregion

            #region Draw/Compare AssetBundle size
            void OnDrawSize(Model model, GUIListViewDrawItemArgs args)
            {
                args.ItemRect.y += 3;
                EditorGUI2.Label(args.ItemRect, EditorUtility2.FormatBytes(model.Size), args.Selected);
            }

            int OnCompareSize(Model x, Model y)
            {
                return x.Size.CompareTo(y.Size);
            }
            #endregion
        }


        class DependencyListbox : GUIListView
        {
            public class Model
            {
                public string Name;
                public string Path;
            }

            #region class Column
            /// <summary>
            /// The Column class represents one column in the list header.
            /// </summary>
            class Column : GUIListViewColumn
            {
                public delegate void ColumnDrawer(Model model, GUIListViewDrawItemArgs args);
                public delegate int CompareDelegate2(Model x, Model y);

                /// <summary>
                /// Occurs when the model gets drawn.
                /// </summary>
                public ColumnDrawer Drawer;

                /// <summary>
                /// Occurs when the column gets sorted.
                /// </summary>
                public CompareDelegate2 Comparer;

                /// <summary>
                /// Initializes a new instance of the Column class.
                /// </summary>
                public Column(string serializeName, string text, string tooltip, float width, ColumnDrawer drawer, CompareDelegate2 comparer)
                    : base(text, tooltip, null, width, null)
                {
                    base.SerializeName = serializeName;
                    this.Drawer = drawer;
                    this.Comparer = comparer;

                    // detour the base comparer callback to our CompareFuncImpl method
                    if (null != comparer)
                        this.CompareFunc = CompareFuncImpl;
                }

                int CompareFuncImpl(object x, object y)
                {
                    return this.Comparer(x as Model, y as Model);
                }
            }
            #endregion

            List<Model> _items = new List<Model>();

            public DependencyListbox(EditorWindow editor, GUIControl parent)
                : base(editor, parent)
            {
                HeaderStyle = GUIListViewHeaderStyle.Clickable;
                MultiSelect = true;
                DragDropEnabled = false;
                RightClickSelect = true;
                Mode = GUIListViewMode.Details;
                ItemSize = new Vector2(0, 22);
                FullRowSelect = true;
                
                Columns.Add(new Column("Bundle", "Dependency", "", 150, OnDrawName, OnCompareName));

                FlexibleColumn = Columns[0];
            }

            public void Clear()
            {
                _items.Clear();

                DoChanged();
            }

            public void SetItems(List<string> paths)
            {
                Clear();
                foreach (var path in paths)
                {
                    var model = new Model();
                    model.Path = path;
                    model.Name = System.IO.Path.GetFileNameWithoutExtension(path);

                    _items.Add(model);
                }

                Sort();
                DoChanged();
            }

            protected override object[] OnBeforeSortItems()
            {
                return _items.ToArray();
            }

            protected override void OnAfterSortItems(object[] models)
            {
                _items.Clear();
                _items.AddRange((Model[])models);
            }

            protected override object OnGetItem(int index)
            {
                if (index < 0 || index >= _items.Count)
                    return null;

                return _items[index];
            }

            protected override int OnGetItemCount()
            {
                return _items.Count;
            }

            protected override void OnDrawItem(GUIListViewDrawItemArgs args)
            {
                var model = (Model)args.Model;
                if (model == null)
                    return;

                var column = args.Column as Column;
                if (column == null)
                    return;

                if (column.IsPrimaryColumn)
                    DrawItemImageHelper(ref args.ItemRect, Images.AssetBundle16x16, Vector2.one * 16);

                args.ItemRect.y += 3;
                column.Drawer(model, args);
            }

            #region Draw/Compare Manifest Name
            void OnDrawName(Model model, GUIListViewDrawItemArgs args)
            {
                EditorGUI2.PathLabel(args.ItemRect, model.Name, args.Selected);
                //if (EditorGUI2.Link(args.ItemRect, model.Name, args.Selected))
                //{
                //    if (LinkClicked != null)
                //    {
                //        var copy = LinkClicked;
                //        copy.Invoke(this, model);
                //    }
                //}
            }

            int OnCompareName(Model x, Model y)
            {
                return string.Compare(x.Name, y.Name, StringComparison.OrdinalIgnoreCase);
            }
            #endregion
        }
    }
}