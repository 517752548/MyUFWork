﻿//---------------------------------------
// Copyright (c) 2013-2014 Peter Schraut
// http://console-dev.de
//---------------------------------------

using System;

namespace EditorFramework
{
    /// <summary>
    /// Helper to bit-manipulate values.
    /// </summary>
    public static class BitUtil
    {
        static BitUtil()
        {
            System.Diagnostics.Debug.Assert(0x78563412 == SwapBytes(0x12345678), "SwapBytes(UInt32 value) failed.");
        }

        #region SwapBytes
        /// <summary>
        /// Swapes bytes of the specified value.
        /// </summary>
        /// <param name="UInt32">The value.</param>
        /// <returns>The swapped value.</returns>
        /// <example>
        /// 0x78563412 = SwapBytes(0x12345678);
        /// </example>
        public static UInt32 SwapBytes(UInt32 value)
        {
            value = ((value & 0xff000000) >> 24)| 
                    ((value & 0x00ff0000) >> 8) |
                    ((value & 0x0000FF00) << 8) |
                    ((value & 0x000000ff) << 24);
            return value;
        }
        #endregion
    }
}
