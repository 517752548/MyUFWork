﻿//---------------------------------------
// Copyright (c) 2013-2014 Peter Schraut
// http://console-dev.de
//---------------------------------------

using UnityEngine;
using UnityEditor;

namespace EditorFramework
{
    /// <summary>
    /// Represents the About dialog used across all my plugins.
    /// </summary>
    public class AboutWindow : EditorWindow
    {
        /// <summary>
        /// Name of the plugin.
        /// </summary>
        public string ProductName = "";

        /// <summary>
        /// URL where to give feedback or get help about the plugin.
        /// </summary>
        public string FeedbackUrl = "";

        /// <summary>
        /// URL of the plugin in the asset store.
        /// </summary>
        public string AssetStoreUrl = "";

        void Awake()
        {
            minSize = new Vector2(480, 240);
            maxSize = new Vector2(480, 240);
        }

        void OnGUI()
        {
            GUILayout.BeginVertical();

            // product name
            DrawLinkLabel(string.Format("{0} by Peter Schraut", ProductName), "http://www.console-dev.de");

            // horizontal line
            GUILayout.Box("", GUILayout.ExpandWidth(true), GUILayout.MaxHeight(1), GUILayout.MinHeight(1));
            GUILayout.Space(16);

            // links
            DrawLinkLabel("Feedback", FeedbackUrl);
            DrawLinkLabel("Rate this plugin", AssetStoreUrl);
            DrawLinkLabel("Find more of my products", "https://www.assetstore.unity3d.com/#/publisher/3683");

            GUILayout.EndVertical();
        }

        void DrawLinkLabel(string title, string url)
        {
            GUILayout.Label(title, EditorStyles.boldLabel);
            GUILayout.BeginHorizontal();
            GUILayout.Space(12);
            if (GUILayout.Button(url, GUIStyles.Hyperlink))
                Application.OpenURL(url);
            EditorGUIUtility.AddCursorRect(GUILayoutUtility.GetLastRect(), MouseCursor.Link);
            GUILayout.EndHorizontal();
            GUILayout.Space(4);
        }
    }
}
