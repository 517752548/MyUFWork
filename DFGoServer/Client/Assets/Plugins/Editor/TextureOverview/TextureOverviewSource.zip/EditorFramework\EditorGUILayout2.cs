﻿//---------------------------------------
// Copyright (c) 2014-2017 Peter Schraut
// http://console-dev.de
//---------------------------------------

using System;
using System.Reflection;
using UnityEngine;
using UnityEditor;

namespace EditorFramework
{
    /// <summary>
    /// EditorGUILayout2 provides methods to draw GUI controls.
    /// </summary>
    public static class EditorGUILayout2
    {
        public static Enum EnumFlagsField(Enum enumValue, params GUILayoutOption[] options)
        {
#if UNITY_2017_3_OR_NEWER
            return EditorGUILayout.EnumFlagsField(enumValue, options);
#else
            return EditorGUILayout.EnumMaskField(enumValue, options);
#endif
        }

        #region Separator
        /// <summary>
        /// Draws a seperator line.
        /// </summary>
        /// <param name="options">The layout options.</param>
        /// <example>
        /// Horizontal Separator:
        ///   EditorGUILayout2.Separator(GUILayout.Height(1), GUILayout.ExpandWidth(true));
        /// Vertical Separator:
        ///   EditorGUILayout2.Separator(GUILayout.Width(1), GUILayout.ExpandHeight(true));
        /// </example>
        public static void Separator(params GUILayoutOption[] options)
        {
            var rect = GUILayoutUtility.GetRect(1, 1, options);

            if (Event.current.type == EventType.Repaint)
            {
                var oldcolor = GUI.color;
                GUI.color = new Color(0, 0, 0, 0.3f);
                GUI.DrawTexture(rect, EditorGUIUtility.whiteTexture, ScaleMode.StretchToFill, false);
                GUI.color = oldcolor;
            }
        }
        #endregion

        #region HorizontalSplitter
        /// <summary>
        /// Draws a splitter to horizontally split UI.
        /// </summary>
        /// <param name="value">The current splitting value</param>
        /// <returns>Whether the value has been changed.</returns>
        public static bool HorizontalSplitter(ref float value)
        {
            var changed = false;

            EditorGUILayout.BeginVertical(GUILayout.Width(2), GUILayout.ExpandHeight(true));
            {
                // draw a vertical line
                var oldcolor = GUI.color;
                GUI.color = new Color(EditorStyles.label.normal.textColor.r, EditorStyles.label.normal.textColor.g, EditorStyles.label.normal.textColor.b, 0.15f);
                GUILayout.Box(GUIContent.none, GUIStyles.White, GUILayout.Width(2), GUILayout.ExpandHeight(true));
                GUI.color = oldcolor;

                // get the size of just drawn line and inflate it a bit to make it easier to grab
                var grabrect = GUILayoutUtility.GetLastRect();
                grabrect.x += 1; // without x+=1 the splitter cannot be grabbed at the left grabrect edge (wtf?)
                grabrect.width += 2;
                EditorGUIUtility.AddCursorRect(grabrect, MouseCursor.ResizeHorizontal);

                // our hot-control id
                int hotId = EditorGUIUtility.GetControlID("SplitterH".GetHashCode(), FocusType.Passive);

                // if the mouse button has been released, the splitter isn't active anymore
                if (Event.current.rawType == EventType.MouseUp && EditorGUIUtility.hotControl == hotId)
                    EditorGUIUtility.hotControl = 0;

                // if mouse pressed inside splitter rectangle, we assume it's active
                if (Event.current.type == EventType.MouseDown && Event.current.button == 0 && grabrect.Contains(Event.current.mousePosition))
                    EditorGUIUtility.hotControl = hotId;

                // if mouse gets dragged while splitter is active, update the value
                if (EditorGUIUtility.hotControl == hotId && Event.current.type == EventType.MouseDrag)
                {
                    value += Event.current.delta.x;
                    Event.current.Use();
                    changed = true;
                }
            }
            EditorGUILayout.EndVertical();

            return changed;
        }
        #endregion

        #region HorizontalSplitter
        /// <summary>
        /// Draws a splitter to vertically split UI.
        /// </summary>
        /// <param name="value">The current splitting value</param>
        /// <returns>Whether the value has been changed.</returns>
        public static bool VerticalSplitter(ref float value)
        {
            var changed = false;

            EditorGUILayout.BeginHorizontal(GUILayout.Height(2), GUILayout.ExpandWidth(true));
            {
                // draw a vertical line
                var oldcolor = GUI.color;
                GUI.color = new Color(EditorStyles.label.normal.textColor.r, EditorStyles.label.normal.textColor.g, EditorStyles.label.normal.textColor.b, 0.15f);
                GUILayout.Box(GUIContent.none, GUIStyles.White, GUILayout.Height(2), GUILayout.ExpandWidth(true));
                GUI.color = oldcolor;

                // get the size of just drawn line and inflate it a bit to make it easier to grab
                var grabrect = GUILayoutUtility.GetLastRect();
                grabrect.y += 2; // without x+=1 the splitter cannot be grabbed at the left grabrect edge (wtf?)
                grabrect.height += 3;
                EditorGUIUtility.AddCursorRect(grabrect, MouseCursor.ResizeVertical);

                // our hot-control id
                int hotId = EditorGUIUtility.GetControlID("SplitterV".GetHashCode(), FocusType.Passive);

                // if the mouse button has been released, the splitter isn't active anymore
                if (Event.current.rawType == EventType.MouseUp && EditorGUIUtility.hotControl == hotId)
                    EditorGUIUtility.hotControl = 0;

                // if mouse pressed inside splitter rectangle, we assume it's active
                if (Event.current.type == EventType.MouseDown && Event.current.button == 0 && grabrect.Contains(Event.current.mousePosition))
                    EditorGUIUtility.hotControl = hotId;

                // if mouse gets dragged while splitter is active, update the value
                if (EditorGUIUtility.hotControl == hotId && Event.current.type == EventType.MouseDrag)
                {
                    value -= Event.current.delta.y;
                    Event.current.Use();
                    changed = true;
                }
            }
            EditorGUILayout.EndHorizontal();

            return changed;
        }
        #endregion
    }
}
