﻿//---------------------------------------
// Copyright (c) 2011-2014 Peter Schraut
// http://console-dev.de
//---------------------------------------

using System.Collections.Generic;
using System.Text;
using UnityEditor;

namespace EditorFramework
{
    /// <summary>
    /// Helper class to copy text to the operating system clipboard.
    /// </summary>
    public static class ClipboardUtil
    {
        #region Copy
        /// <summary>
        /// Copies the specified text to the OS clipboard.
        /// </summary>
        /// <param name="text">The text</param>
        public static void Copy(string text)
        {
            EditorGUIUtility.systemCopyBuffer = text;
        }
        #endregion

        #region CopyPaths
        /// <summary>
        /// Copies the specified path-list to the OS clipboard.
        /// </summary>
        /// <remarks>
        /// Each path gets trimmed and copied to a new line.
        /// </remarks>
        /// <param name="paths">The paths</param>
        public static void CopyPaths(IEnumerable<string> paths)
        {
            var builder = new StringBuilder(128 * 64);

            foreach (var p in paths)
            {
                if (p == null)
                    continue;

                var path = p.Trim();
                if (string.IsNullOrEmpty(path))
                    continue;

                builder.AppendLine(path);
            }

            Copy(builder.ToString().Trim());
        }
        #endregion
    }
}
