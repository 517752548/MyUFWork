﻿//---------------------------------------
// Copyright (c) 2011-2017 Peter Schraut
// http://console-dev.de
//
// Requires Unity 5.5 or newer
//---------------------------------------

using System;
using System.Reflection;
using UnityEngine;
using UnityEditor;

namespace EditorFramework
{
    static class TextureImporterFormatDatabase
    {
        public class Entry
        {
            public TextureImporterFormat Format;
            public TextureImporterFormat UncompressedFormat;
            public TextureFormat RuntimeFormat;
            public float BitsPerPixel;
            public bool MustBeSquare;
            public bool MustBePot;
            public bool MustBePotForMipMaps;
            public int MinimumSize;
            public int MustBeMultipleOf;
            public bool CanUseCompressionQuality;
            public bool CanUseCrunchCompression;
            public bool CanBeReadable;
            public int BlockSize;
            public string Name = "";
            public string LongName = "";
            public bool HasAlphaChannel;

            public Entry()
            {
            }
        }

        static Entry[] _List;

        public static Entry Find(TextureImporterFormat format)
        {
            var index = (int)format;
            if (index < 0)
                return new Entry();

            if (index >= _List.Length)
                return new Entry();

            var entry = _List[index];
            if (entry == null)
                return new Entry();

            return entry;
        }

        public static Entry Find(TextureFormat format)
        {
            for (var n = 0; n < _List.Length; ++n)
            {
                if (_List[n] != null && _List[n].RuntimeFormat == format)
                    return _List[n];
            }

            return new Entry();
        }

        static void Add(TextureImporterFormat format, TextureImporterFormat uncompressedFormat, TextureFormat runtimeFormat,
                float bitsPerPixel, bool hasAlphaChannel, bool mustBeSquare, bool mustBePot, bool mustBePotForMipMaps, int minimumSize, int multipleOf, int blockSize,
                bool canUseCompressionQuality, bool canUseCrunchCompression, bool canBeReadable, string prettyName)
        {
            var entry = new Entry();
            entry.Name = format.ToString();
            entry.LongName = prettyName;
            entry.BitsPerPixel = bitsPerPixel;
            entry.HasAlphaChannel = hasAlphaChannel;
            entry.Format = format;
            entry.UncompressedFormat = uncompressedFormat;
            entry.MinimumSize = minimumSize;
            entry.MustBeMultipleOf = multipleOf;
            entry.BlockSize = blockSize;
            entry.MustBePot = mustBePot;
            entry.MustBePotForMipMaps = mustBePotForMipMaps;
            entry.MustBeSquare = mustBeSquare;
            entry.CanUseCompressionQuality = canUseCompressionQuality;
            entry.CanUseCrunchCompression = canUseCrunchCompression;
            entry.CanBeReadable = canBeReadable;
            entry.RuntimeFormat = runtimeFormat;

            _List[(int)format] = entry;
        }

        static TextureImporterFormatDatabase()
        {
            _List = new Entry[256];

            Add(TextureImporterFormat.Alpha8, TextureImporterFormat.Alpha8, TextureFormat.Alpha8, 8, true, false, false, false, 0, 0, 0, false, false, true, "Alpha 8");
            Add(TextureImporterFormat.ARGB16, TextureImporterFormat.ARGB16, TextureFormat.ARGB4444, 16, true, false, false, false, 0, 0, 0, false, false, false, "ARGB 16 bit"); // really not readable?
            Add(TextureImporterFormat.RGB24, TextureImporterFormat.RGB24, TextureFormat.RGB24, 24, false, false, false, false, 0, 0, 0, false, false, true, "RGB 24 bit");
            Add(TextureImporterFormat.RGBA32, TextureImporterFormat.RGBA32, TextureFormat.RGBA32, 32, true, false, false, false, 0, 0, 0, false, false, true, "RGBA 32 bit");
            Add(TextureImporterFormat.ARGB32, TextureImporterFormat.ARGB32, TextureFormat.ARGB32, 32, true, false, false, false, 0, 0, 0, false, false, true, "ARGB 32 bit");
            Add(TextureImporterFormat.RGB16, TextureImporterFormat.RGB16, TextureFormat.RGB565, 16, false, false, false, false, 0, 0, 0, false, false, false, "RGB 16 bit"); // really not readable?
            Add(TextureImporterFormat.DXT1, TextureImporterFormat.RGB24, TextureFormat.DXT1, 4, false, false, false, true, 0, 4, 4, false, true, true, "RGB Compressed DXT1");
            Add(TextureImporterFormat.DXT5, TextureImporterFormat.RGBA32, TextureFormat.DXT5, 8, true, false, false, true, 0, 4, 4, false, true, true, "RGBA Compressed DXT5");
            Add(TextureImporterFormat.RGBA16, TextureImporterFormat.RGBA16, TextureFormat.RGBA4444, 16, true, false, false, false, 0, 0, 0, false, false, false, "RGBA 16 bit"); // really not readable?
            Add(TextureImporterFormat.RGBAHalf, TextureImporterFormat.RGBAHalf, TextureFormat.RGBAHalf, 16, true, false, false, false, 0, 0, 0, false, false, false, "RGBA Half");
            Add(TextureImporterFormat.BC6H, TextureImporterFormat.RGB24, TextureFormat.BC6H, 8, false, false, false, true, 0, 4, 4, false, false, false, "RGB HDR Compressed BC6H");
            Add(TextureImporterFormat.BC7, TextureImporterFormat.RGB24, TextureFormat.BC7, 8, true, false, false, true, 0, 4, 4, false, false, false, "RGB(A) Compressed BC7");
            Add(TextureImporterFormat.BC4, TextureImporterFormat.RGB24, TextureFormat.BC4, 4, false, false, false, true, 0, 4, 4, false, false, false, "R Compressed BC4");
            Add(TextureImporterFormat.BC5, TextureImporterFormat.RGB24, TextureFormat.BC5, 8, false, false, false, true, 0, 4, 4, false, false, false, "RG Compressed BC5");
            Add(TextureImporterFormat.DXT1Crunched, TextureImporterFormat.RGB24, TextureFormat.DXT1Crunched, 4, false, false, false, true, 0, 4, 4, true, false, true, "RGB Crunched DXT1");
            Add(TextureImporterFormat.DXT5Crunched, TextureImporterFormat.RGBA32, TextureFormat.DXT5Crunched, 8, true, false, false, true, 0, 4, 4, true, false, true, "RGBA Crunched DXT5");
            Add(TextureImporterFormat.PVRTC_RGB2, TextureImporterFormat.RGB24, TextureFormat.PVRTC_RGB2, 2, true, true, true, true, 8, 0, 4, true, false, false, "ARGB 16 bit");
            Add(TextureImporterFormat.PVRTC_RGBA2, TextureImporterFormat.RGBA32, TextureFormat.PVRTC_RGBA2, 2, true, true, true, true, 8, 0, 4, true, false, false, "RGBA Compressed PVRTC 2 bits");
            Add(TextureImporterFormat.PVRTC_RGB4, TextureImporterFormat.RGB24, TextureFormat.PVRTC_RGB4, 4, false, true, true, true, 8, 0, 4, true, false, false, "RGB Compressed PVRTC 4 bits");
            Add(TextureImporterFormat.PVRTC_RGBA4, TextureImporterFormat.RGBA32, TextureFormat.PVRTC_RGBA4, 4, true, true, true, true, 8, 0, 4, true, false, false, "RGBA Compressed PVRTC 4 bits");
            Add(TextureImporterFormat.ETC_RGB4, TextureImporterFormat.RGB24, TextureFormat.ETC_RGB4, 4, false, false, true, true, 0, 4, 4, true, false, false, "RGB Compressed ETC 4 bits");
#if !UNITY_2018_OR_NEWER
            Add(TextureImporterFormat.ATC_RGB4, TextureImporterFormat.RGB24, TextureFormat.ATC_RGB4, 4, false, false, true, true, 0, 4, 4, true, false, false, "RGB Compressed ATC 4 bits");
            Add(TextureImporterFormat.ATC_RGBA8, TextureImporterFormat.RGBA32, TextureFormat.ATC_RGBA8, 8, true, false, true, true, 0, 4, 4, true, false, false, "RGBA Compressed ATC 8 bits");
#endif
            Add(TextureImporterFormat.EAC_R, TextureImporterFormat.RGB24, TextureFormat.EAC_R, 4, false, false, true, true, 0, 4, 4, true, false, false, "R Compressed EAC 4 bit");
            Add(TextureImporterFormat.EAC_R_SIGNED, TextureImporterFormat.RGB24, TextureFormat.EAC_R_SIGNED, 4, false, false, true, true, 0, 4, 4, true, false, false, "EAC_R_SIGNED");
            Add(TextureImporterFormat.EAC_RG, TextureImporterFormat.RGB24, TextureFormat.EAC_RG, 4, false, false, true, true, 0, 4, 4, true, false, false, "EAC_RG");
            Add(TextureImporterFormat.EAC_RG_SIGNED, TextureImporterFormat.RGB24, TextureFormat.EAC_RG_SIGNED, 4, false, false, true, true, 0, 4, 4, true, false, false, "EAC_RG_SIGNED");
            Add(TextureImporterFormat.ETC2_RGB4, TextureImporterFormat.RGB24, TextureFormat.ETC2_RGB, 4, false, false, true, true, 0, 4, 4, true, false, false, "RGB Compressed ETC2 4 bits");
            Add(TextureImporterFormat.ETC2_RGB4_PUNCHTHROUGH_ALPHA, TextureImporterFormat.RGBA32, TextureFormat.ETC2_RGBA1, 4, true, false, true, true, 0, 4, 4, true, false, false, "RGB+1 bit Alpha Compressed ETC2 4 bits"); // really RGBA32?
            Add(TextureImporterFormat.ETC2_RGBA8, TextureImporterFormat.RGBA32, TextureFormat.ETC2_RGBA8, 8, true, false, true, true, 0, 4, 4, true, false, false, "RGBA Compressed ETC2 8 bits");
            Add(TextureImporterFormat.ASTC_RGB_4x4, TextureImporterFormat.RGB24, TextureFormat.ASTC_RGB_4x4, 0, false, false, false, true, 0, 0, 4, true, false, false, "RGB Compressed ASTC 4x4 block");
            Add(TextureImporterFormat.ASTC_RGB_5x5, TextureImporterFormat.RGB24, TextureFormat.ASTC_RGB_5x5, 0, false, false, false, true, 0, 0, 5, true, false, false, "RGB Compressed ASTC 5x5 block");
            Add(TextureImporterFormat.ASTC_RGB_6x6, TextureImporterFormat.RGB24, TextureFormat.ASTC_RGB_6x6, 0, false, false, false, true, 0, 0, 6, true, false, false, "RGB Compressed ASTC 6x6 block");
            Add(TextureImporterFormat.ASTC_RGB_8x8, TextureImporterFormat.RGB24, TextureFormat.ASTC_RGB_8x8, 0, false, false, false, true, 0, 0, 8, true, false, false, "RGB Compressed ASTC 8x8 block");
            Add(TextureImporterFormat.ASTC_RGB_10x10, TextureImporterFormat.RGB24, TextureFormat.ASTC_RGB_10x10, 0, false, false, false, true, 0, 0, 10, true, false, false, "RGB Compressed ASTC 10x10 block");
            Add(TextureImporterFormat.ASTC_RGB_12x12, TextureImporterFormat.RGB24, TextureFormat.ASTC_RGB_12x12, 0, false, false, false, true, 0, 0, 12, true, false, false, "RGB Compressed ASTC 12x12 block");
            Add(TextureImporterFormat.ASTC_RGBA_4x4, TextureImporterFormat.RGBA32, TextureFormat.ASTC_RGBA_4x4, 0, true, false, false, true, 0, 0, 4, true, false, false, "RGBA Compressed ASTC 4x4 block");
            Add(TextureImporterFormat.ASTC_RGBA_5x5, TextureImporterFormat.RGBA32, TextureFormat.ASTC_RGBA_5x5, 0, true, false, false, true, 0, 0, 5, true, false, false, "RGBA Compressed ASTC 5x5 block");
            Add(TextureImporterFormat.ASTC_RGBA_6x6, TextureImporterFormat.RGBA32, TextureFormat.ASTC_RGBA_6x6, 0, true, false, false, true, 0, 0, 6, true, false, false, "RGBA Compressed ASTC 6x6 block");
            Add(TextureImporterFormat.ASTC_RGBA_8x8, TextureImporterFormat.RGBA32, TextureFormat.ASTC_RGBA_8x8, 0, true, false, false, true, 0, 0, 8, true, false, false, "RGBA Compressed ASTC 8x8 block");
            Add(TextureImporterFormat.ASTC_RGBA_10x10, TextureImporterFormat.RGBA32, TextureFormat.ASTC_RGBA_10x10, 0, true, false, false, true, 0, 0, 10, true, false, false, "RGBA Compressed ASTC 10x10 block");
            Add(TextureImporterFormat.ASTC_RGBA_12x12, TextureImporterFormat.RGBA32, TextureFormat.ASTC_RGBA_12x12, 0, true, false, false, true, 0, 0, 12, true, false, false, "RGBA Compressed ASTC 12x12 block");

#if UNITY_2017_3_OR_NEWER
            Add(TextureImporterFormat.ETC_RGB4Crunched, TextureImporterFormat.RGB24, TextureFormat.ETC_RGB4Crunched, 4, false, false, true, true, 0, 4, 4, true, false, false, "RGB Crunched ETC 4 bits");
            Add(TextureImporterFormat.ETC2_RGBA8Crunched, TextureImporterFormat.RGBA32, TextureFormat.ETC2_RGBA8Crunched, 8, true, false, true, true, 0, 4, 4, true, false, false, "RGBA Crunched ETC2 8 bits");
#endif

#if UNITY_2018_OR_NEWER
            Add(TextureImporterFormat.R8, TextureImporterFormat.R8, TextureFormat.R8, 8, false, false, false, true, 0, 0, 0, false, false, false, "R 8");
#endif
        }
    }

    /// <summary>
    /// TextureUtil2 provides various methods to get texture properties.
    /// </summary>
    /// <remarks>
    /// Some methods are actually available in UnityEditor.TextureUtil, but they are not public in there.
    /// </remarks>
    public static class TextureUtil2
    {
        #region Private Fields
        static Type _type;
        static MethodInfo _getStorageMemorySize;
        static MethodInfo _getGLWidth;
        static MethodInfo _getGLHeight;
        
        #endregion

        #region ctor
        static TextureUtil2()
        {
            _type = typeof(TextureImporter).Assembly.GetType("UnityEditor.TextureUtil");
            if (_type != null)
            {
                _getStorageMemorySize = _type.GetMethod("GetStorageMemorySize", BindingFlags.Static | BindingFlags.Public);
                _getGLWidth = _type.GetMethod("GetGPUWidth", BindingFlags.Static | BindingFlags.Public, null, new[] { typeof(Texture) }, null);
                _getGLHeight = _type.GetMethod("GetGPUHeight", BindingFlags.Static | BindingFlags.Public, null, new[] { typeof(Texture) }, null);
            }

            if (null == _type)
                Debug.LogWarning("Could not find type 'TextureUtil'.");

            if (null == _getStorageMemorySize)
                Debug.LogWarning("Could not find method 'TextureUtil.GetStorageMemorySize'.");

            if (null == _getGLWidth)
                Debug.LogWarning("Could not find method 'TextureUtil.GetGLWidth(Texture)' or 'TextureUtil.GetGPUWidth(Texture)'.");

            if (null == _getGLHeight)
                Debug.LogWarning("Could not find method 'TextureUtil.GetGLHeight(Texture)' or 'TextureUtil.GetGPUHeight(Texture)'.");
        }
        #endregion



        #region GetStorageMemorySize
        /// <summary>
        /// Gets the storage memory usage of the specified texture.
        /// </summary>
        /// <param name="texture">The Texture</param>
        /// <returns>The storage memory usage in bytes.</returns>
        public static int GetStorageMemorySize(Texture texture)
        {
            if (null == _getStorageMemorySize)
                return 0;

            var args = new object[] { texture };
            return (int)_getStorageMemorySize.Invoke(null, args);
        }
        #endregion

        #region GetRuntimeMemorySize
        public struct RuntimeMemoryUsage
        {
            public int Cpu;
            public int Gpu;
        }

        public static RuntimeMemoryUsage GetRuntimeMemorySize(TextureImporterFormat format, int width, int height, bool hasmips, bool isreadable, TextureImporterShape shape)
        {
            var entry = TextureImporterFormatDatabase.Find(format);

            var bitsPerPixel = entry.BitsPerPixel;
            switch (format)
            {
                case TextureImporterFormat.ASTC_RGB_4x4:
                case TextureImporterFormat.ASTC_RGBA_4x4:
                case TextureImporterFormat.ASTC_RGB_5x5:
                case TextureImporterFormat.ASTC_RGBA_5x5:
                case TextureImporterFormat.ASTC_RGB_6x6:
                case TextureImporterFormat.ASTC_RGBA_6x6:
                case TextureImporterFormat.ASTC_RGB_8x8:
                case TextureImporterFormat.ASTC_RGBA_8x8:
                case TextureImporterFormat.ASTC_RGB_10x10:
                case TextureImporterFormat.ASTC_RGBA_10x10:
                case TextureImporterFormat.ASTC_RGB_12x12:
                case TextureImporterFormat.ASTC_RGBA_12x12:
                    {
                        // https://www.opengl.org/registry/specs/KHR/texture_compression_astc_hdr.txt
                        // Given a 2D image which is W x H pixels in size, with block size
                        // w x h, the size of the image in blocks is:
                        //    Bw = ceiling(W/w)
                        //    Bh = ceiling(H/h)

                        width = Mathf.CeilToInt(width / (float)entry.BlockSize) * entry.BlockSize;
                        height = Mathf.CeilToInt(height / (float)entry.BlockSize) * entry.BlockSize;
                        bitsPerPixel = 1.0f / (entry.BlockSize * entry.BlockSize) * 128;
                    }
                    break;
            }


            var sizeInBytes = (width * height * bitsPerPixel) / 8.0f;

            if (hasmips)
                sizeInBytes *= 1.3333333333333f; // mimaps add an additional overhead of 33%

            var iscubemap = shape == TextureImporterShape.TextureCube;
            if (iscubemap)
                sizeInBytes *= 6; // cubemap has 6 faces

            var result = new RuntimeMemoryUsage();
            result.Gpu = Mathf.RoundToInt(sizeInBytes);

            // if a texture is readable, a copy of the texture data will be made,
            // doubling the amount of memory required for texture asset. 
            // see http://docs.unity3d.com/Manual/class-TextureImporter.html for details
            if (isreadable && !iscubemap) // for some reason, cubemaps are never considered readable
            {
                // this is only valid for uncompressed and DTX compressed textures,
                // other types of compressed textures cannot be read from.
                if (entry.CanBeReadable)
                    result.Cpu = Mathf.RoundToInt(sizeInBytes);
            }

            return result;
        }
        #endregion


        public static Color GetTextureImporterTypeChartColor(TextureImporterType type, TextureImporterShape shape)
        {
            if (shape == TextureImporterShape.TextureCube)
                return new Color32(225, 151, 76, 255);

            switch (type)
            {
                case TextureImporterType.Default: return new Color32(211, 94, 96, 255);
                case TextureImporterType.NormalMap: return new Color32(114, 147, 203, 255);
                case TextureImporterType.GUI: return new Color32(144, 103, 167, 255);
                case TextureImporterType.Cookie: return new Color32(204, 194, 16, 255);
                case TextureImporterType.Lightmap: return new Color32(128, 133, 133, 255);
                case TextureImporterType.Cursor: return Color.white;
                case TextureImporterType.Sprite: return new Color32(132, 186, 91, 255);
                case TextureImporterType.SingleChannel: return new Color32(171, 104, 87, 255);
            }

            return new Color32(171, 104, 87, 255);
        }

        public static string GetTextureShapeString(TextureImporterShape value)
        {
            switch (value)
            {
                case TextureImporterShape.Texture2D: return "2D";
                case TextureImporterShape.TextureCube: return "Cube";
            }

            return value.ToString();
        }

        public static string GetAlphaSourceString(TextureImporterAlphaSource value)
        {
            switch (value)
            {
                case TextureImporterAlphaSource.None: return "None";
                case TextureImporterAlphaSource.FromInput: return "Input Alpha";
                case TextureImporterAlphaSource.FromGrayScale: return "From Grayscale";
            }

            return value.ToString();
        }

        /// <summary>
        /// Gets a string-representation of the specified TextureType.
        /// </summary>
        /// <param name="type">The TextureType</param>
        /// <returns>The string of the TextureType</returns>
        public static string GetTextureTypeString(TextureImporterType type, TextureImporterShape shape)
        {
            switch (shape)
            {
                case TextureImporterShape.TextureCube: return "Cubemap";
            }

            switch (type)
            {
                case TextureImporterType.Cookie: return "Cookie";
                case TextureImporterType.Cursor: return "Cursor";
                case TextureImporterType.Default: return "Default";
                case TextureImporterType.GUI: return "Editor GUI & Legacy UI";
                case TextureImporterType.Lightmap: return "Lightmap";
                case TextureImporterType.NormalMap: return "Normal map";
                case TextureImporterType.SingleChannel: return "Single Channel";
                case TextureImporterType.Sprite: return "Sprite (2D & UI)";
            }

            return type.ToString();
        }

        public static string GetWrapModeString(TextureWrapMode value)
        {
            switch (value)
            {
                case TextureWrapMode.Clamp:
                    return "Clamp";

                case (TextureWrapMode)(-1): // -1 is handled by Unity as Repeat, seems to be something from ancient times
                case TextureWrapMode.Repeat:
                    return "Repeat";

#if UNITY_2017_OR_NEWER
                case TextureWrapMode.Mirror:
                    return "Mirror";

                case TextureWrapMode.MirrorOnce:
                    return "Mirror Once";
#endif
            }

            return value.ToString();
        }

        public static string GetWrapModeString(TextureImporterShape shape, TextureWrapMode u, TextureWrapMode v, TextureWrapMode w)
        {
            if (shape == TextureImporterShape.TextureCube)
            {
                if (u == v && v == w)
                    return GetWrapModeString(u);

                return string.Format("Per-axis ({0}|{1}|{2})", GetWrapModeString(u), GetWrapModeString(v), GetWrapModeString(w));
            }

            if (u == v)
                return GetWrapModeString(u);

            return string.Format("Per-axis ({0}|{1})", GetWrapModeString(u), GetWrapModeString(v));
        }

        public static string GetFilterModeString(FilterMode value)
        {
            switch (value)
            {
                case (FilterMode)(-1): // -1 is handled by Unity as Bilinear, seems to be something from ancient times
                case FilterMode.Bilinear:
                    return "Bilinear";

                case FilterMode.Trilinear: return "Trilinear";
                case FilterMode.Point: return "Point";
            }

            return value.ToString();
        }

        public static string GetNPOTScaleString(TextureImporterNPOTScale value)
        {
            switch (value)
            {
                case TextureImporterNPOTScale.None: return "None";
                case TextureImporterNPOTScale.ToLarger: return "To Larger";
                case TextureImporterNPOTScale.ToNearest: return "To Nearest";
                case TextureImporterNPOTScale.ToSmaller: return "To Smaller";
            }
            return value.ToString();
        }

#if UNITY_2017_2_OR_NEWER
        public static string GetResizeAlgorithmString(TextureResizeAlgorithm value)
        {
            switch (value)
            {
                case TextureResizeAlgorithm.Bilinear: return "Bilinear";
                case TextureResizeAlgorithm.Mitchell: return "Mitchell";
            }
            return value.ToString();
        }
#endif

        public static bool HasAlphaChannel(TextureImporterFormat value)
        {
            var entry = TextureImporterFormatDatabase.Find(value);
            if (entry != null)
                return entry.HasAlphaChannel;

            return false;
        }

        public static string GetCompressionString(TextureImporterCompression value)
        {
            switch (value)
            {
                case TextureImporterCompression.Uncompressed: return "None";
                case TextureImporterCompression.CompressedLQ: return "Low";
                case TextureImporterCompression.CompressedHQ: return "High";
                case TextureImporterCompression.Compressed: return "Normal";
            }

            return value.ToString();
        }

        public static string GetCompressionQualityString(int value)
        {
            switch (value)
            {
                case 0: return "Fast";
                case 50: return "Normal";
                case 100: return "Best";
            }

            return string.Format("{0}", value);
        }

        public static bool CanUseCrunchCompression(TextureImporterFormat value)
        {
            var entry = TextureImporterFormatDatabase.Find(value);
            if (entry != null)
                return entry.CanUseCrunchCompression;

            return false;
        }

        public static bool CanUseCompressionQuality(TextureImporterFormat value)
        {
            var entry = TextureImporterFormatDatabase.Find(value);
            if (entry != null)
                return entry.CanUseCompressionQuality;

            return false;
        }

        public static bool IsCompressedFormat(TextureImporterFormat value)
        {
            var entry = TextureImporterFormatDatabase.Find(value);
            if (entry != null)
                return entry.Format != entry.UncompressedFormat;

            return false;
        }

        public static TextureImporterFormat GetTextureImporterFormatFromTextureFormat(TextureFormat value)
        {
            var entry = TextureImporterFormatDatabase.Find(value);
            if (entry != null)
                return entry.Format;

            return TextureImporterFormat.RGBA32;
        }

        public static string GetTextureImporterFormatString(TextureImporterFormat value)
        {
            // AutomaticCompressedHDR, AutomaticHDR, AutomaticCrunched, AutomaticTruecolor, Automatic16bit, AutomaticCompressed
            // are all obsolete in Unity 5.5! The "Automatic" setting is -1
            if ((int)value < 0)
                return "Auto";

            var entry = TextureImporterFormatDatabase.Find(value);
            if (entry != null)
                return entry.Name;

            return value.ToString();
        }

        public static string GetTextureImporterFormatLongString(TextureImporterFormat value)
        {
            // AutomaticCompressedHDR, AutomaticHDR, AutomaticCrunched, AutomaticTruecolor, Automatic16bit, AutomaticCompressed
            // are all obsolete in Unity 5.5! The "Automatic" setting is -1
            if ((int)value < 0)
                return "Auto";

            var entry = TextureImporterFormatDatabase.Find(value);
            if (entry != null)
                return entry.LongName;

            return value.ToString();
        }

        public static int GetPOTSize(int size, TextureImporterNPOTScale scale)
        {
            if (scale == TextureImporterNPOTScale.None)
                return size;

            if (scale == TextureImporterNPOTScale.ToSmaller)
            {
                for (var n = 1; n < 16; ++n)
                {
                    var value = 1 << n;
                    if (size < value)
                        return 1 << (n - 1);
                }
            }

            if (scale == TextureImporterNPOTScale.ToLarger)
            {
                for (var n = 1; n < 16; ++n)
                {
                    var value = 1 << n;
                    if (size <= value)
                        return value;
                }
            }

            if (scale == TextureImporterNPOTScale.ToNearest)
            {
                for (var n = 1; n < 16; ++n)
                {
                    var smaller = 1 << (n - 1);
                    var larger = 1 << n;
                    if (size > smaller && size <= larger)
                    {
                        var s = size - smaller;
                        var l = larger - size;
                        if (s < l)
                            return smaller;
                        return larger;
                    }
                }
            }

            return size;
        }

        public static int GetMultipleOf(TextureImporterFormat format)
        {
            return TextureImporterFormatDatabase.Find(format).MustBeMultipleOf;
        }

        public static bool IsSquareRequired(TextureImporterFormat format)
        {
            return TextureImporterFormatDatabase.Find(format).MustBeSquare;
        }

        public static bool IsPOTRequired(TextureImporterFormat format)
        {
            return TextureImporterFormatDatabase.Find(format).MustBePot;
        }

        public static bool IsPOTRequiredForMipMaps(TextureImporterFormat format)
        {
            return TextureImporterFormatDatabase.Find(format).MustBePotForMipMaps;
        }

        public static TextureImporterFormat GetUncompressedFormat(TextureImporterFormat format)
        {
            return TextureImporterFormatDatabase.Find(format).UncompressedFormat;
        }

        #region GetOriginalWidthAndHeight
        /// <summary>
        /// Gets the width and height of the source texture asset.
        /// </summary>
        /// <param name="texture">The Texture</param>
        /// <param name="importer">The TextureImporter</param>
        /// <param name="width">The output width</param>
        /// <param name="height">The output height</param>
        public static void GetOriginalWidthAndHeight(Texture texture, TextureImporter importer, out int width, out int height)
        {
            width = 0;
            height = 0;

            var cubemap = texture as Cubemap;
            if (null != cubemap)
            {
                width = GetGLWidth(texture);
                height = GetGLHeight(texture);
                return;
            }

            if (null != importer)
            {
                TextureImporter2.GetWidthAndHeight(importer, ref width, ref height);
                return;
            }
        }

        static int GetGLWidth(Texture texture)
        {
            if (null == _getGLWidth)
                return -1;

            var args = new object[] { texture };
            return (int)_getGLWidth.Invoke(null, args);
        }

        static int GetGLHeight(Texture texture)
        {
            if (null == _getGLHeight)
                return -1;

            var args = new object[] { texture };
            return (int)_getGLHeight.Invoke(null, args);
        }
        #endregion

        #region ToSourceCode
        /// <summary>
        /// Gets the C# source code of the specified texture.
        /// </summary>
        /// <param name="texture">Texture to get the source code for.</param>
        /// <returns>A string containing the source code of the texture</returns>
        /// <remarks>
        /// If you don't want editor only textures to appear in the Unity Texture Selector,
        /// you must not store them in the Assets folder. Thus my workaround is to include textures
        /// in the source code instead.
        /// </remarks>
        public static string ToSourceCode(Texture2D texture)
        {
            var builder = new System.Text.StringBuilder(4096);
            var pixels = texture.GetPixels32();

            //builder.AppendLine("readonly static Color32[] PixelData = new Color32[] {");
            builder.AppendLine("new Color32[] {");

            var n = 0;
            while (n < pixels.Length)
            {
                var x=0;
                while (x < 6 && n < pixels.Length)
                {
                    var pixel = pixels[n];
                    builder.Append(string.Format(" new Color32({0},{1},{2},{3}),", pixel.r, pixel.g, pixel.b, pixel.a));
                    n++;
                    x++;
                }
                builder.AppendLine();
            }
            builder.AppendLine("};");

            return builder.ToString();
        }
        #endregion
    }
}
