﻿//---------------------------------------
// Copyright (c) 2011-2018 Peter Schraut
// http://console-dev.de
//---------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEditor;
using EditorFramework;

namespace TextureOverview
{
    /// <summary>
    /// Listbox represents the control that displays texture settings.
    /// </summary>
    public class Listbox : GUIListView, IDisposable
    {
        #region class Column
        /// <summary>
        /// The Column class represents one column in the list header.
        /// </summary>
        class Column : GUIListViewColumn
        {
            public enum ColumnMode
            {
                None,
                PlatformSpecific
            }

            public delegate void ColumnDrawer(Model model, GUIListViewDrawItemArgs args);
            public delegate int CompareDelegate2(Model x, Model y);
            public delegate string ExportDelegate(Model model);

            /// <summary>
            /// Occurs when the model gets drawn.
            /// </summary>
            public ColumnDrawer Drawer;

            /// <summary>
            /// Occurs when the column gets sorted.
            /// </summary>
            public CompareDelegate2 Comparer;

            /// <summary>
            /// Occurs when the column gets a request to get the item value as text.
            /// </summary>
            public ExportDelegate Exporter;

            /// <summary>
            /// The Mode is used to colorize a column.
            /// </summary>
            public ColumnMode Mode = ColumnMode.None;

            // Hide the value if the selected platform is default
            public bool HideIfDefault;

            /// <summary>
            /// Initializes a new instance of the Column class.
            /// </summary>
            public Column(string serializeName, string text, string tooltip, float width, ColumnDrawer drawer, CompareDelegate2 comparer, ExportDelegate exporter)
                : base(text, tooltip, null, width, null)
            {
                base.SerializeName = serializeName;
                this.Drawer = drawer;
                this.Comparer = comparer;
                this.Exporter = exporter;

                // detour the base comparer callback to our CompareFuncImpl method
                if (null != comparer)
                    this.CompareFunc = CompareFuncImpl;
            }

            int CompareFuncImpl(object x, object y)
            {
                var xx = x as Model;
                var yy = y as Model;

                var result = this.Comparer(xx, yy);

                // In order to make the sort stable in all occurences, we use the asset guid as second sorting.
                //if (result == 0 && xx != null && yy != null)
                //    result = string.CompareOrdinal(xx.AssetGuid, yy.AssetGuid);

                return result;
            }
        }
        #endregion

        #region class Model
        /// <summary>
        /// The Model class represents an item within the list.
        /// </summary>
        class Model : ICacheFileEntry
        {
            #region Private Fields
            // use en-US for formatting numbers, because we want to have 1.2 rather than 1,2 even in german language
            static System.Globalization.CultureInfo _enusCulture = System.Globalization.CultureInfo.GetCultureInfo("en-US");

            // when the model moves into view (it becomes visible inside the list), the asset preview
            // icon gets allocated. when it moves out of view, it gets released again.
            Texture _assetIcon;
            #endregion

            public string AssetGuid;
            public string AssetHash;
            public bool HasError; // Whether an error occured while reading texture settings.
            public bool PlatformHasIssue;
            public string PlatformIssueString="";

            #region AssetPath
            string _assetPath;
            public string AssetPath
            {
                get
                {
                    if (null != _assetPath)
                        return _assetPath;

                    _assetPath = AssetDatabase.GUIDToAssetPath(AssetGuid) ?? AssetGuid;
                    if (string.IsNullOrEmpty(_assetPath))
                        _assetPath = "<Missing asset in project>";

                    return _assetPath;
                }
            }
            #endregion

            #region FileExtension
            string _fileExtension;
            public string FileExtension
            {
                get
                {
                    if (null == _fileExtension)
                        _fileExtension = FileUtil2.GetFileExtension(AssetPath);
                    return _fileExtension;
                }
            }
            #endregion

            #region AssetName
            string _assetName;
            public string AssetName
            {
                get
                {
                    if (null == _assetName)
                        _assetName = FileUtil2.GetFileNameWithoutExtension(AssetPath);
                    return _assetName;
                }
            }
            #endregion

            #region OrgWidth
            public int OrgWidth;
            string _orgWidthString;
            public string OrgWidthString
            {
                get
                {
                    if (null == _orgWidthString)
                        _orgWidthString = OrgWidth.ToString();
                    return _orgWidthString;
                }
            }
            #endregion

            #region OrgHeight
            public int OrgHeight;
            string _orgHeightString;
            public string OrgHeightString
            {
                get
                {
                    if (null == _orgHeightString)
                        _orgHeightString = OrgHeight.ToString();
                    return _orgHeightString;
                }
            }
            #endregion

            #region AnisoLevel
            public int AnisoLevel;
            public int AbsAnisoLevel; // UNITY BUG: Upgrading Unity from 5.4 to 5.5 causes some aniso values to show up as negatve 1, so we have a 'fixed value' for that
            string _anisoLevelString;
            public string AnisoLevelString
            {
                get
                {
                    if (null == _anisoLevelString)
                        _anisoLevelString = AbsAnisoLevel.ToString();// AnisoLevel.ToString();
                    return _anisoLevelString;
                }
            }
            #endregion

            public bool MipmapEnabled;
            public TextureImporterMipFilter MipmapFilter;
            public bool MipmapBorder;
            public bool MipmapFadeout;
            public float MipmapBias;
#if UNITY_2017_OR_NEWER
            public bool MipmapPreserveCoverage;
#endif

#if UNITY_2018_2_OR_NEWER
            public bool StreamingMipmaps;
            public int StreamingMipmapsPriority;
#endif

            public TextureImporterGenerateCubemap GenerateCubemap;
            public float HeightmapScale;
            public bool HeightmapToNormalmap;
            public TextureImporterNormalFilter NormalFilter;

            public TextureImporterNPOTScale NPOTScale;

#if UNITY_2017_OR_NEWER
            public TextureWrapMode WrapModeU;
            public TextureWrapMode WrapModeV;
            public TextureWrapMode WrapModeW;
#else
            public TextureWrapMode WrapMode;
#endif

            public FilterMode FilterMode;

            #region TextureType
            public TextureImporterType TextureType;
            public string TextureTypeString
            {
                get
                {
                    if (IsLegacyCubemap)
                        return "Cubemap (Legacy)";
                    return TextureUtil2.GetTextureTypeString(TextureType, TextureShape);
                }
            }
            #endregion

            #region TextureShape
            public TextureImporterShape TextureShape;
            public string TextureShapeString
            {
                get
                {
                    return TextureUtil2.GetTextureShapeString(TextureShape);
                }
            }
            #endregion

            #region AlphaSource
            public TextureImporterAlphaSource AlphaSource;
            public string AlphaSourceString
            {
                get
                {
                    return TextureUtil2.GetAlphaSourceString(AlphaSource);
                }
            }
            #endregion

            public bool AlphaIsTransparency;
            public bool AlphaAllowSplitting;
            public bool HasAlpha;
            public bool PlatformIsPowerOfTwo;
            public bool PlatformIsSquare;
            
            public bool IsReadable;
            public bool sRGBTexture; // Corresponds to the 'Bypass sRGB Sampling' setting in the Texture Inspector.

            #region SpriteImportMode
            public SpriteImportMode SpriteImportMode = SpriteImportMode.None;
            string _spriteImportModeString;
            public string SpriteImportModeString
            {
                get
                {
                    if (null == _spriteImportModeString)
                        _spriteImportModeString = SpriteImportMode.ToString();
                    return _spriteImportModeString;
                }
            }
            #endregion

            public string SpritePackingTag = "";

            #region SpritePixelToUnit
            public float SpritePixelPerUnit;
            string _spritePixelToUnitString;
            public string SpritePixelPerUnitString
            {
                get
                {
                    if (null == _spritePixelToUnitString)
                        _spritePixelToUnitString = string.Format("{0:F2}", SpritePixelPerUnit);
                    return _spritePixelToUnitString;
                }
            }
            #endregion

            public bool IsLegacyCubemap;

            // Everything prefixed with Platform is specific to the selected platform in Texture Overview.
            // These settings are NOT serialized. They are generated on-the-fly from the original texture importer copied values.
            public TextureImporterFormat PlatformFormat;

            #region MaxTextureSize
            public int MaxTextureSize;
            string _maxTextureSizeString;
            public string MaxTextureSizeString
            {
                get
                {
                    if (null == _maxTextureSizeString)
                        _maxTextureSizeString = MaxTextureSize.ToString();
                    return _maxTextureSizeString;
                }
            }
            #endregion

            #region Width
            string _widthString;
            public int PlatformWidth;
            public string WidthString
            {
                get
                {
                    if (null == _widthString)
                        _widthString = PlatformWidth.ToString();
                    return _widthString;
                }
            }
            #endregion

            #region Height
            public int PlatformHeight;
            string _heightString;
            public string HeightString
            {
                get
                {
                    if (null == _heightString)
                        _heightString = PlatformHeight.ToString();
                    return _heightString;
                }
            }
            #endregion

            #region RuntimeSize
            public int PlatformRuntimeSize;
            string _runtimeSizeString;
            public string RuntimeSizeString
            {
                get
                {
                    if (null == _runtimeSizeString)
                        _runtimeSizeString = EditorUtility2.FormatBytes(PlatformRuntimeSize);
                    return _runtimeSizeString;
                }
            }
            #endregion

            #region CpuSize
            // How much memory the texture consumes in RAM.
            // Texture needs to be Read/Write Enabled=true to add to RAM.
            public int PlatformCpuSize;

            string _cpuSizeString;
            public string CpuSizeString
            {
                get
                {
                    if (null == _cpuSizeString)
                        _cpuSizeString = EditorUtility2.FormatBytes(PlatformCpuSize);
                    return _cpuSizeString;
                }
            }
            #endregion

            #region GpuSize
            // How much memory the texture consumes in graphics memory,
            // when strictly considering the texture format (such as handling rgb24 as rgb24)
            public int PlatformGpuSize;

            string _gpuSizeString;
            public string GpuSizeString
            {
                get
                {
                    if (null == _gpuSizeString)
                        _gpuSizeString = EditorUtility2.FormatBytes(PlatformGpuSize);
                    return _gpuSizeString;
                }
            }
            #endregion

            #region StorageSize
            public int PlatformStorageSize;
            string _storageSizeString;
            public string StorageSizeString
            {
                get
                {
                    if (null == _storageSizeString)
                        _storageSizeString = EditorUtility2.FormatBytes(PlatformStorageSize);
                    return _storageSizeString;
                }
            }
            #endregion

            #region MipmapCount
            public int PlatformMipmapCount
            {
                get
                {
                    if (!MipmapEnabled)
                        return 1;

                    var value = 1 + Mathf.FloorToInt(Mathf.Log((float)Mathf.Max(PlatformWidth, PlatformHeight), 2));
                    return value;
                }
            }
            #endregion

            #region PixelRatio
            public float PlatformPixelRatio
            {
                get
                {
                    if (HasError)
                        return 0;

                    return 1 / ((PlatformWidth * PlatformHeight) / (float)(OrgWidth * OrgHeight));
                }
            }

            string _pixelRatioString;
            public string PlatformPixelRatioString
            {
                get
                {
                    if (null == _pixelRatioString)
                        _pixelRatioString = string.Format("1/{0:F0}", PlatformPixelRatio);
                    return _pixelRatioString;
                }
            }
            #endregion

            #region PixelRatioTooltip
            string _pixelRatioTooltip;
            public string PlatformPixelRatioTooltip
            {
                get
                {
                    if (null == _pixelRatioTooltip)
                    {
                        if (Mathf.Abs(PlatformPixelRatioPercentage - 100) > 0.0001f)
                            _pixelRatioTooltip = string.Format("'{4}' resized from {0}x{1} to {2}x{3}", OrgWidth, OrgHeight, PlatformWidth, PlatformHeight, AssetName);
                        else
                            _pixelRatioTooltip = "";
                    }
                    return _pixelRatioTooltip;
                }
            }
            #endregion

            #region PixelRatioPercentage
            public float PlatformPixelRatioPercentage
            {
                get
                {
                    if (HasError)
                        return 0;

                    return 100 * ((PlatformWidth * PlatformHeight) / (float)(OrgWidth * OrgHeight));
                }
            }

            string _pixelRatioPercentageString;
            public string PlatformPixelRatioPercentageString
            {
                get
                {
                    if (null == _pixelRatioPercentageString)
                        _pixelRatioPercentageString = string.Format(_enusCulture, "{0:F1}%", PlatformPixelRatioPercentage); // use culture because we want a dot/point as fractional-separator (german for example uses a comma) but different formats usually make import in various applications more difficult
                    return _pixelRatioPercentageString;
                }
            }
            #endregion

            #region RendererCount
            public int RendererCount; // how many renderer reference this texture
            #endregion

            struct ImporterPlatformSettings
            {
                public bool available;
                public bool overridden;
                public bool allowsAlphaSplitting;
                public int compressionQuality;
                public bool crunchedCompression;
                public TextureImporterFormat format;
                public TextureImporterCompression textureCompression;
                public int maxTextureSize;
                public TextureImporterFormat platformFormat;

#if UNITY_2017_2_OR_NEWER
                public TextureResizeAlgorithm resizeAlgorithm;
#endif
            }

            ImporterPlatformSettings DefaultImporterSettings
            {
                get
                {
                    return ImporterSettings[(int)BuildTargetGroup.Unknown];
                }
            }

            const int ImporterSettingsLength = 32; // Unity currently supports 22 platforms.
            ImporterPlatformSettings[] ImporterSettings; // The original platform specific importer settings. Index into this array using values of BuildTargetGroup.

            #region ICacheFileEntry Implementation
            public string GetAssetGuid()
            {
                return AssetGuid;
            }

            public string GetAssetHash()
            {
                return AssetHash;
            }

            public void Serialize(BinarySerializer data)
            {
                data.Serialize(ref AssetGuid);
                data.Serialize(ref AssetHash);
                data.Serialize(ref HasError);
                data.Serialize(ref MaxTextureSize);
                data.Serialize(ref OrgWidth);
                data.Serialize(ref OrgHeight);
                data.Serialize(ref AnisoLevel);
                data.Serialize(ref MipmapEnabled);
                data.Serialize(ref MipmapBorder);
                data.Serialize(ref MipmapFadeout);
                data.Serialize(ref MipmapBias);

#if UNITY_2017_OR_NEWER
                data.Serialize(ref MipmapPreserveCoverage);
#endif

                MipmapFilter = (TextureImporterMipFilter)data.SerializeInt32((int)MipmapFilter);

#if UNITY_2018_2_OR_NEWER
                data.Serialize(ref StreamingMipmaps);
                data.Serialize(ref StreamingMipmapsPriority);
#endif

#if UNITY_2017_OR_NEWER
                WrapModeU = (TextureWrapMode)data.SerializeInt32((int)WrapModeU);
                WrapModeV = (TextureWrapMode)data.SerializeInt32((int)WrapModeV);
                WrapModeW = (TextureWrapMode)data.SerializeInt32((int)WrapModeW);
#else
                WrapMode = (TextureWrapMode)data.SerializeInt32((int)WrapMode);
#endif

                FilterMode = (FilterMode)data.SerializeInt32((int)FilterMode);
                TextureType = (TextureImporterType)data.SerializeInt32((int)TextureType);
                TextureShape = (TextureImporterShape)data.SerializeInt32((int)TextureShape);
                data.Serialize(ref HasAlpha);
                data.Serialize(ref IsReadable);
                data.Serialize(ref sRGBTexture);
                SpriteImportMode = (SpriteImportMode)data.SerializeInt32((int)SpriteImportMode);
                data.Serialize(ref SpritePackingTag);
                data.Serialize(ref SpritePixelPerUnit);
                AlphaSource = (TextureImporterAlphaSource)data.SerializeInt32((int)AlphaSource);
                data.Serialize(ref AlphaIsTransparency);
                data.Serialize(ref AlphaAllowSplitting);
                GenerateCubemap = (TextureImporterGenerateCubemap)data.SerializeInt32((int)GenerateCubemap);
                data.Serialize(ref HeightmapToNormalmap);
                NPOTScale = (TextureImporterNPOTScale)data.SerializeInt32((int)NPOTScale);
                NormalFilter = (TextureImporterNormalFilter)data.SerializeInt32((int)NormalFilter);
                data.Serialize(ref HeightmapScale);
                

                if (data.IsReader)
                {
                    ImporterSettings = new ImporterPlatformSettings[ImporterSettingsLength];
                }

                for (int n = 0, nend = ImporterSettings.Length; n < nend; ++n)
                {
                    var settings = ImporterSettings[n];
                    data.Serialize(ref settings.available);
                    data.Serialize(ref settings.overridden);

                    data.Serialize(ref settings.allowsAlphaSplitting);
                    data.Serialize(ref settings.compressionQuality);
                    data.Serialize(ref settings.crunchedCompression);

                    settings.textureCompression = (TextureImporterCompression)data.SerializeInt32((int)settings.textureCompression);
                    settings.format = (TextureImporterFormat)data.SerializeInt32((int)settings.format);
                    data.Serialize(ref settings.maxTextureSize);
                    settings.platformFormat = (TextureImporterFormat)data.SerializeInt32((int)settings.platformFormat);

#if UNITY_2017_2_OR_NEWER
                    settings.resizeAlgorithm = (TextureResizeAlgorithm)data.SerializeInt32((int)settings.resizeAlgorithm);
#endif

                    ImporterSettings[n] = settings;
                }
            }
            #endregion

            #region Preview Image

            public Texture AllocAssetIcon()
            {
                if (_assetIcon != null)
                    return _assetIcon;

                if (TextureShape == TextureImporterShape.TextureCube)
                    _assetIcon = Images.Cubemap16x16;

                if (TextureShape == TextureImporterShape.Texture2D)
                    _assetIcon = UnityEditor.AssetDatabase.GetCachedIcon(AssetPath);

                if (_assetIcon == null)
                    _assetIcon = Images.Texture2D16x16;

                return _assetIcon;
            }

            public void ReleaseAssetIcon()
            {
                _assetIcon = null;
            }
            #endregion

            #region Init
            void ResetCachedString()
            {
                PlatformIssueString = "";
                _assetPath = null;
                _fileExtension = null;
                _assetName = null;
                _maxTextureSizeString = null;
                _widthString = null;
                _heightString = null;
                _orgWidthString = null;
                _orgHeightString = null;
                _anisoLevelString = null;
                _runtimeSizeString = null;
                _cpuSizeString = null;
                _gpuSizeString = null;
                _storageSizeString = null;

                _pixelRatioString = null;
                _pixelRatioTooltip = null;
                _pixelRatioPercentageString = null;
                _assetIcon = null;
                _spriteImportModeString = null;
                _spritePixelToUnitString = null;

                ImporterSettings = new ImporterPlatformSettings[ImporterSettingsLength];
            }

            /// <summary>
            /// Initializes the model for the texture of the specified path and platform.
            /// </summary>
            /// <param name="path">The full path to the texture.</param>
            /// <param name="platform">The platform from which to read the settings.</param>
            public long Init(string path)
            {
                ResetCachedString();

                // Reset the most important properties that are required to identify the asset
                HasError = false;
                AssetGuid = AssetDatabase.AssetPathToGUID(path);
                AssetHash = AssetDatabase.GetAssetDependencyHash(path).ToString();

                // I've seen cases were loading fails due to corrupt asset file, so better check for null here.
                var importer = AssetImporter.GetAtPath(path);
                if (importer == null)
                {
                    HasError = true;
                    return 0;
                }

                // Is it a legacy cubemap file?
                // I believe this was integrated into TextureImporter prior Unity 5.5,
                // but now we have to workaround its absence...
                if (!string.IsNullOrEmpty(path) && path.EndsWith(".cubemap"))
                {
                    return InitLegacyCubemap(importer);
                }

                // Is it a texture at all?
                var textureImporter = importer as TextureImporter;
                if (textureImporter == null)
                    HasError = true;

                // I've seen cases were loading fails due to corrupt texture file.
                var asset = AssetDatabase.LoadAssetAtPath<Texture>(path);
                if (null == asset)
                    HasError = true;

                long loadedAssetSize = 0;
                if (asset != null)
                    loadedAssetSize = ProfilerUtility.GetRuntimeMemorySize(asset);

                // If an error occured, leave!
                if (HasError)
                    return loadedAssetSize;

                // Copy texture importer settings
                HasAlpha = textureImporter.DoesSourceTextureHaveAlpha();
                AlphaIsTransparency = textureImporter.alphaIsTransparency;
                AlphaSource = textureImporter.alphaSource;
                AlphaAllowSplitting = textureImporter.allowAlphaSplitting;
                AnisoLevel = textureImporter.anisoLevel;
                FilterMode = textureImporter.filterMode;
                IsReadable = textureImporter.isReadable;

#if UNITY_2017_OR_NEWER
                WrapModeU = textureImporter.wrapModeU;
                WrapModeV = textureImporter.wrapModeV;
                WrapModeW = textureImporter.wrapModeW;
#else
                WrapMode = textureImporter.wrapMode;
#endif

                TextureType = textureImporter.textureType;
                TextureShape = textureImporter.textureShape;
                sRGBTexture = textureImporter.sRGBTexture;
                MipmapEnabled = textureImporter.mipmapEnabled;
                MipmapBorder = textureImporter.borderMipmap;
                MipmapFadeout = textureImporter.fadeout;
                MipmapFilter = textureImporter.mipmapFilter;
                MipmapBias = textureImporter.mipMapBias;
#if UNITY_2017_OR_NEWER
                MipmapPreserveCoverage = textureImporter.mipMapsPreserveCoverage;
#endif
#if UNITY_2018_2_OR_NEWER
                StreamingMipmaps = textureImporter.streamingMipmaps;
                StreamingMipmapsPriority = textureImporter.streamingMipmapsPriority;
#endif
                GenerateCubemap = textureImporter.generateCubemap;
                HeightmapScale = textureImporter.heightmapScale;
                HeightmapToNormalmap = textureImporter.convertToNormalmap; // convert heightmap to normalmap
                NPOTScale = textureImporter.npotScale;
                NormalFilter = textureImporter.normalmapFilter;
                SpriteImportMode = UnityEditor.SpriteImportMode.None;
                SpritePackingTag = "";
                SpritePixelPerUnit = -1;
                if (textureImporter.spriteImportMode != UnityEditor.SpriteImportMode.None)
                {
                    SpriteImportMode = textureImporter.spriteImportMode;
                    SpritePackingTag = textureImporter.spritePackingTag;
                    SpritePixelPerUnit = textureImporter.spritePixelsPerUnit;
                }

                TextureUtil2.GetOriginalWidthAndHeight(asset, textureImporter, out OrgWidth, out OrgHeight);

                // Read the default settings
                {
                    var defaultSettings = textureImporter.GetDefaultPlatformTextureSettings();

                    var index = (int)BuildTargetGroup.Unknown;
                    ImporterSettings[index].maxTextureSize = defaultSettings.maxTextureSize;
                    ImporterSettings[index].compressionQuality = defaultSettings.compressionQuality;
                    ImporterSettings[index].crunchedCompression = defaultSettings.crunchedCompression;
                    ImporterSettings[index].allowsAlphaSplitting = defaultSettings.allowsAlphaSplitting;
                    ImporterSettings[index].format = TextureImporterFormat.Automatic;
                    ImporterSettings[index].textureCompression = defaultSettings.textureCompression;
                    ImporterSettings[index].overridden = true;
                    ImporterSettings[index].available = true;

#if UNITY_2017_2_OR_NEWER
                    ImporterSettings[index].resizeAlgorithm = defaultSettings.resizeAlgorithm;
#endif
                }

                // Read platform specific settings
                var availablePlatforms = BuildPlayerWindow2.GetValidPlatforms();
                for (int n = 0, nend = availablePlatforms.Count; n < nend; ++n)
                {
                    var platform = availablePlatforms[n];
                    if (platform.TargetGroup == BuildTargetGroup.Unknown)
                        continue;

                    var platformId = (int)platform.TargetGroup;
                    var platformName = platform.Name;

                    var unitySettings = textureImporter.GetPlatformTextureSettings(platformName);
                    if (!unitySettings.overridden)
                        unitySettings = textureImporter.GetDefaultPlatformTextureSettings();

                    var settings = new ImporterPlatformSettings();
                    settings.available = true;
                    settings.overridden = unitySettings.overridden;
                    settings.allowsAlphaSplitting = unitySettings.allowsAlphaSplitting;
                    settings.compressionQuality = unitySettings.compressionQuality;
                    settings.crunchedCompression = unitySettings.crunchedCompression;
                    settings.format = unitySettings.format;
                    settings.maxTextureSize = unitySettings.maxTextureSize;
                    settings.textureCompression = unitySettings.textureCompression;
                    settings.platformFormat = textureImporter.GetAutomaticFormat(platformName);

#if UNITY_2017_2_OR_NEWER
                    settings.resizeAlgorithm = unitySettings.resizeAlgorithm;
#endif

                    ImporterSettings[platformId] = settings;
                }

                return loadedAssetSize;
            }

            long InitLegacyCubemap(AssetImporter importer)
            {
                var asset = AssetDatabase.LoadAssetAtPath<Cubemap>(importer.assetPath);
                if (null == asset)
                {
                    HasError = true;
                    return 0;
                }

                HasAlpha = false;
                AlphaIsTransparency = false;
                AlphaSource = TextureImporterAlphaSource.None;
                AlphaAllowSplitting = false;
                AnisoLevel = asset.anisoLevel;
                FilterMode = asset.filterMode;
                IsReadable = true; // legacy cubemaps were readable always

#if UNITY_2017_OR_NEWER
                WrapModeU = asset.wrapModeU;
                WrapModeV = asset.wrapModeV;
                WrapModeW = asset.wrapModeW;
#else
                WrapMode = asset.wrapMode;
#endif

                TextureType = TextureImporterType.Default;
                TextureShape = TextureImporterShape.TextureCube;
                sRGBTexture = true;
                MipmapEnabled = asset.mipmapCount > 1;
                MipmapBorder = false;
                MipmapFadeout = false;
                MipmapFilter = TextureImporterMipFilter.BoxFilter;
                MipmapBias = asset.mipMapBias;
                //GenerateCubemap = TextureImporterGenerateCubemap.None;
                HeightmapScale = 0;
                HeightmapToNormalmap = false;
                NPOTScale = TextureImporterNPOTScale.None;
                NormalFilter = TextureImporterNormalFilter.Standard;
                SpriteImportMode = UnityEditor.SpriteImportMode.None;
                SpritePackingTag = "";
                SpritePixelPerUnit = 0;
                OrgWidth = asset.width;
                OrgHeight = asset.height;

                // There are no per platform settings for legacy cubemaps
                for (var n = 0; n < ImporterSettings.Length; ++n)
                {
                    ImporterSettings[n] = new ImporterPlatformSettings();
                    ImporterSettings[n].available = true;
                    ImporterSettings[n].maxTextureSize = asset.width;
                    ImporterSettings[n].format = TextureUtil2.GetTextureImporterFormatFromTextureFormat(asset.format);
                    ImporterSettings[n].platformFormat = ImporterSettings[n].format;
                    ImporterSettings[n].textureCompression = TextureImporterCompression.Uncompressed;

#if UNITY_2017_2_OR_NEWER
                    ImporterSettings[n].resizeAlgorithm = (TextureResizeAlgorithm)0;
#endif
                }

                var loadedAssetSize = ProfilerUtility.GetRuntimeMemorySize(asset);
                return loadedAssetSize;
            }
            #endregion

            #region Importer platform dependend settings
            public bool GetImporterSettingsAvailable(BuildTargetGroup platform)
            {
                var settings = ImporterSettings[(int)platform];
                return settings.available;
            }

            public bool GetImporterOverridden(BuildTargetGroup platform)
            {
                return ImporterSettings[(int)platform].overridden;
            }

            public TextureImporterFormat GetImporterFormat(BuildTargetGroup platform)
            {
                return ImporterSettings[(int)platform].format;
            }

            public TextureImporterFormat GetImporterPlatformFormat(BuildTargetGroup platform)
            {
                return ImporterSettings[(int)platform].platformFormat;
            }

            public int GetImporterCompressionQuality(BuildTargetGroup platform)
            {
                return ImporterSettings[(int)platform].compressionQuality;
            }

            public int GetImporterMaxSize(BuildTargetGroup platform)
            {
                return ImporterSettings[(int)platform].maxTextureSize;
            }

            public bool GetImporterUseCrunchCompression(BuildTargetGroup platform)
            {
                return ImporterSettings[(int)platform].crunchedCompression;
            }

            public TextureImporterCompression GetImporterTextureCompression(BuildTargetGroup platform)
            {
                return ImporterSettings[(int)platform].textureCompression;
            }

            int GetImporterWidthAndHeight(BuildTargetGroup platform, out int width, out int height)
            {
                width = OrgWidth;
                height = OrgHeight;

                var settings = ImporterSettings[(int)platform];
                if (!settings.overridden)
                    settings = DefaultImporterSettings;

                if (height <= width)
                {
                    var aspect = height / (float)width;
                    width = Mathf.Min(width, settings.maxTextureSize);
                    height = Mathf.RoundToInt(width * aspect);
                }
                else
                {
                    var aspect = width / (float)height;
                    height = Mathf.Min(height, settings.maxTextureSize);
                    width = Mathf.RoundToInt(height * aspect);
                }

                return settings.maxTextureSize;
            }

#if UNITY_2017_2_OR_NEWER
            public TextureResizeAlgorithm GetImporterResizeAlgorithm(BuildTargetGroup platform)
            {
                return ImporterSettings[(int)platform].resizeAlgorithm;
            }
#endif
            #endregion

            public void SetPlatform(BuildTargetGroup platform)
            {
                if (HasError)
                {
                    PlatformHasIssue = true;
                    return;
                }

                // Clear cached strings, so on the next access they get recreated with the new sizes
                PlatformIssueString = "";
                _gpuSizeString = null;
                _cpuSizeString = null;
                _runtimeSizeString = null;
                _storageSizeString = null;
                _widthString = null;
                _heightString = null;

                PlatformFormat = GetImporterPlatformFormat(platform);
                var desiredPlatformFormat = PlatformFormat;
                var desiredPlatformFormatString = TextureUtil2.GetTextureImporterFormatString(desiredPlatformFormat);
                var platformFormatOption = GetImporterFormat(platform);

                AbsAnisoLevel = Mathf.Abs(AnisoLevel);
                IsLegacyCubemap = TextureShape == TextureImporterShape.TextureCube && FileExtension == "cubemap";

                var maxTextureSize = GetImporterWidthAndHeight(platform, out PlatformWidth, out PlatformHeight);
                PlatformWidth = TextureUtil2.GetPOTSize(PlatformWidth, NPOTScale);
                PlatformHeight = TextureUtil2.GetPOTSize(PlatformHeight, NPOTScale);

                if (TextureUtil2.IsSquareRequired(desiredPlatformFormat))
                {
                    if (NPOTScale == TextureImporterNPOTScale.ToSmaller)
                        PlatformWidth = Mathf.Min(PlatformWidth, PlatformHeight);

                    if (NPOTScale == TextureImporterNPOTScale.ToLarger)
                        PlatformWidth = Mathf.Max(PlatformWidth, PlatformHeight);

                    if (NPOTScale == TextureImporterNPOTScale.ToNearest)
                    {
                        if (maxTextureSize - PlatformWidth < maxTextureSize - PlatformHeight)
                            PlatformHeight = PlatformWidth;
                        else
                            PlatformWidth = PlatformHeight;
                    }
                }

                PlatformIsPowerOfTwo = Mathf.IsPowerOfTwo(PlatformWidth) && Mathf.IsPowerOfTwo(PlatformHeight);
                PlatformIsSquare = PlatformWidth == PlatformHeight;

                // Check if the texture can be compressed
                if (TextureUtil2.IsCompressedFormat(desiredPlatformFormat))
                {
                    var isAtlased = this.TextureType == TextureImporterType.Sprite && !string.IsNullOrEmpty(this.SpritePackingTag);

                    if (!PlatformIsPowerOfTwo && MipmapEnabled && TextureUtil2.IsPOTRequiredForMipMaps(desiredPlatformFormat))
                    {
                        PlatformIssueString += "Only POT textures can be compressed if mip-maps are enabled.\n\n";
                        PlatformFormat = TextureUtil2.GetUncompressedFormat(PlatformFormat);
                    }

                    if (!isAtlased && TextureUtil2.GetMultipleOf(desiredPlatformFormat) != 0)
                    {
                        var multipleOf = TextureUtil2.GetMultipleOf(desiredPlatformFormat);
                        if ((PlatformWidth % multipleOf) != 0 || (PlatformHeight % multipleOf) != 0)
                        {
                            PlatformIssueString += string.Format("Only textures with width/height being multiple of 4 can be compressed to {0} format.\n\n", desiredPlatformFormatString);
                            PlatformFormat = TextureUtil2.GetUncompressedFormat(PlatformFormat);
                        }
                    }

                    if (!PlatformIsPowerOfTwo && !isAtlased && TextureUtil2.IsPOTRequired(desiredPlatformFormat))
                    {
                        PlatformIssueString += string.Format("Only POT textures can be compressed to {0} format.\n\n", desiredPlatformFormatString);
                        PlatformFormat = TextureUtil2.GetUncompressedFormat(PlatformFormat);
                    }

                    if (!isAtlased && !PlatformIsSquare && TextureUtil2.IsSquareRequired(desiredPlatformFormat))
                    {
                        PlatformIssueString += string.Format("Only square textures can be compressed to {0} format.\n\n", desiredPlatformFormatString);
                        PlatformFormat = TextureUtil2.GetUncompressedFormat(PlatformFormat);
                    }
                }


                //if (HasAlpha && !TextureUtil2.HasAlphaChannel(platformFormatOption) && AlphaSource == TextureImporterAlphaSource.FromInput)
                //{
                //    PlatformIssueString += string.Format("Format {0} does not have alpha, but is needed for the 'Alpha Source = Input Texture Alpha' usage, setting to {1}.\n\n", platformFormatOption, PlatformFormat);
                //    //PlatformFormat = TextureUtil2.GetUncompressedFormat(PlatformFormat);
                //}

                // Warn if legacy types are used
                //if (IsLegacyCubemap)
                //{
                //    PlatformIssueString += string.Format("Legacy Cubemap asset found. Use the Cubemap texture import type instead.\n\n");
                //}

                PlatformHasIssue = !string.IsNullOrEmpty(PlatformIssueString);
                PlatformIssueString = PlatformIssueString.Trim();

                var diskusage = TextureUtil2.GetRuntimeMemorySize(PlatformFormat, PlatformWidth, PlatformHeight, MipmapEnabled, false, TextureShape);
                PlatformStorageSize = diskusage.Gpu;

                // Get memory size for specified format
                var memusage = TextureUtil2.GetRuntimeMemorySize(PlatformFormat, PlatformWidth, PlatformHeight, MipmapEnabled, IsReadable, TextureShape);
                PlatformGpuSize = memusage.Gpu;
                PlatformCpuSize = memusage.Cpu;

                // Check if we want to expand rgb24 to rgba32 for gpu memory calculation
                if (PlatformFormat == TextureImporterFormat.RGB24 && Globals.GpuExpandRgb24ToRgba32)
                {
                    memusage = TextureUtil2.GetRuntimeMemorySize(TextureImporterFormat.RGBA32, PlatformWidth, PlatformHeight, MipmapEnabled, IsReadable, TextureShape);
                    PlatformGpuSize = memusage.Gpu;
                }

                PlatformRuntimeSize = PlatformGpuSize + PlatformCpuSize;
            }
        }
        #endregion

        #region Private Fields
#if UNITY_2018_2_OR_NEWER
        CacheFile<Model> _cache = new CacheFile<Model>(20180201, Globals.ProductTitle, "TextureOverview");
#elif UNITY_2017_2_OR_NEWER
        CacheFile<Model> _cache = new CacheFile<Model>(20170201, Globals.ProductTitle, "TextureOverview");
#elif UNITY_2017_OR_NEWER
        CacheFile<Model> _cache = new CacheFile<Model>(201702, Globals.ProductTitle, "TextureOverview");
#else
        CacheFile<Model> _cache = new CacheFile<Model>(5509, Globals.ProductTitle, "TextureOverview");
#endif
        List<Model> _items = new List<Model>();
        List<Model> _allitems = new List<Model>();
        bool _disposed;
        List<TypeFilter> _typeFilter = new List<TypeFilter>();
        Dictionary<int, TypeFilter> _typeFilterLookup = new Dictionary<int, TypeFilter>();
        SearchTextParser.Result _filterResult = new SearchTextParser.Result();
        TextFilterMode _filterMode;
        int _filterUpdateCount;
        BuildTargetGroup _platform = BuildTargetGroup.Unknown; // unknown=default
        int _warningCount;
        #endregion

        /// <summary>
        /// The TextFilterMode indicates which property the search function considers for text matching.
        /// </summary>
        public enum TextFilterMode
        {
            All = 0,
            Name,
            Path,
            SpritePackingTag,
        }

        public class TypeFilter
        {
            public string Name;
            public TextureImporterType Type;
            public TextureImporterShape Shape;

            public TypeFilter(string name, TextureImporterType type, TextureImporterShape shape)
            {
                Name = name;
                Type = type;
                Shape = shape;
            }

            public override int GetHashCode()
            {
                var hash = ComputeHashCode(Type, Shape);
                return hash;
            }

            public static int ComputeHashCode(TextureImporterType type, TextureImporterShape shape)
            {
                var hash = 256 * (int)shape;
                hash += (int)type;
                return hash;
            }
        }

        /// <summary>
        /// Event is raised whenever a texture changed,
        /// </summary>
        public Action<Listbox> TextureChanged;

        /// <summary>
        /// Gets the number of items currently in the list.
        /// </summary>
        public int ItemCount
        {
            get
            {
                return _items.Count;
            }
        }

        /// <summary>
        /// Gets a string describing how many items are in the list.
        /// </summary>
        public string ItemCountString
        {
            get
            {
                var issueVerb = string.Format("{0} {1}", _warningCount, _warningCount == 1 ? "issue" : "issues");

                if (_items.Count != _allitems.Count)
                    return string.Format("{0}/{1} textures | {2}", _items.Count, _allitems.Count, issueVerb);

                return string.Format("{0} textures | {1}", _items.Count, issueVerb);
            }
        }

        /// <summary>
        /// Indicates at which time the UnityEditor.Selection has been assigned.
        /// </summary>
        /// <remarks>
        /// If the user double-clicks an item in AudioClip Explorer, we assign it to UnityEditor.Selection.
        /// But on the same hand, AudioClip Explorer can listen to selection changes in Unity to automatically
        /// display the selected items. To avoid that 'feedback loop', we assign the time to this variable
        /// when the user double-clicks an item in the list and the selection change listening code can check
        /// if the selection change came from this list.
        /// </remarks>
        public double ChangeUnitySelectionTime
        {
            get;
            private set;
        }

        /// <summary>
        /// Gets a string describing the selected items in the list.
        /// </summary>
        public string SelectionString
        {
            get
            {
                if (SelectedItemsCount == 0)
                    return ""; // no selection, no text

                var models = GetSelectedModels();
                if (SelectedItemsCount == 1)
                    return models[0].AssetPath;

                // sum the sizes of all selected models
                long storagesize = 0;
                long runtimesize = 0;
                foreach (var model in models)
                {
                    storagesize += model.PlatformStorageSize;
                    runtimesize += model.PlatformRuntimeSize;
                }

                return string.Format("{0} selected | Storage: {1} | Runtime: {2}",
                    models.Count,
                    EditorUtility2.FormatBytes(storagesize),
                    EditorUtility2.FormatBytes(runtimesize));
            }
        }

        #region ctor
        /// <summary>
        /// Initializes a new instance of the Listbox class.
        /// </summary>
        /// <param name="editor">The EditorWindow where this control resides in.</param>
        /// <param name="parent">The parent container of the control or null when it's a top-level control.</param>
        public Listbox(EditorWindow editor, GUIControl parent)
            : base(editor, parent)
        {
            HeaderStyle = GUIListViewHeaderStyle.ClickablePopup;
            MultiSelect = true;
            DragDropEnabled = true;
            RightClickSelect = true;
            Mode = GUIListViewMode.Details;
            ItemSize = new Vector2(0, 22);
            FullRowSelect = true;

            // add columns to the listbox
            Columns.Add(new Column("Name", "Name", "Asset Name", 220, OnDrawAssetName, OnCompareAssetName, OnExportAssetName));
            Columns.Add(new Column("Path", "Path", "Asset Path", 220, OnDrawAssetPath, OnCompareAssetPath, OnExportAssetPath) { Visible = false });
            Columns.Add(new Column("Issue", "Issue", "Indicates whether an issue was found with the texture and the selected platform.", 40, OnDrawHasIssue, OnCompareHasIssue, OnExportHasIssue) { Visible = false });
            Columns.Add(new Column("Type", "Type", "Texture Type is used to define what your Texture is to be used for.", 110, OnDrawImportType, OnCompareImportType, OnExportImportType));
            Columns.Add(new Column("Shape", "Shape", "Texture Shape setting.", 60, OnDrawImportShape, OnCompareImportShape, OnExportImportShape));
            Columns.Add(new Column("RendererCount", "Renderer Count", "How often a texture is referenced by Renderer Components, through their sharedMaterials property, in the open scene. UI elements are not included. This is valid in 'Scene Mode' only.\n(EXPERIMENTAL)", 60, OnDrawRendererCount, OnCompareRendererCount, OnExportRendererCount) { Visible = false });

            Columns.Add(new Column("sRGB", "sRGB (Color Texture)", "Texture content is stored in gamme space. Non-HDR color textures should enable this flag (except if used for IMGUI).", 85, OnDrawsRGBTexture, OnComparesRGBTexture, OnExportsRGBTexture) { Visible = false });
            Columns.Add(new Column("Alpha", "Alpha", "Indicates whether the texture contains an alpha channel.", 40, OnDrawHasAlpha, OnCompareHasAlpha, OnExportHasAlpha) { Visible = false });
            Columns.Add(new Column("AlphaSource", "Alpha Source", "How is the alpha channel generated for the texture.", 100, OnDrawAlphaSource, OnCompareAlphaSource, OnExportAlphaSource) { Visible = false });
            Columns.Add(new Column("AlphaIsTransparency", "Alpha is Transparency", "Alpha Is Transparency", 40, OnDrawAlphaIsTransparency, OnCompareAlphaIsTransparency, OnExportAlphaIsTransparency) { Visible = false });

            Columns.Add(new Column("StorageSize", "Storage Size", "Estimate how many space the asset consumes on the storage system (disk). 'Crunched' compressed assets always assumed to have the worst/biggest size, rather than the actual compressed file size.", 80, OnDrawStorageSize, OnCompareStorageSize, OnExportStorageSize) { HideIfDefault = true });
            Columns.Add(new Column("RuntimeSize", "Runtime Size", "How many space the asset consumes in memory (graphics + main memory).", 85, OnDrawRuntimeSize, OnCompareRuntimeSize, OnExportRuntimeSize) { HideIfDefault = true });
            Columns.Add(new Column("CpuSize", "Main Memory", "How many space the texture consumes in main memory. Only applies to textures that use Read/Write Enabled.", 85, OnDrawCpuSize, OnCompareCpuSize, OnExportCpuSize) { Visible = false, HideIfDefault = true });
            Columns.Add(new Column("GpuSize", "Graphics Memory", "How many space the texture consumes in graphics memory.", 85, OnDrawGpuSize, OnCompareGpuSize, OnExportGpuSize) { Visible = false, HideIfDefault = true });
            Columns.Add(new Column("RW", "Read\\Write Enabled", "Read/Write enables access to the texture data from scripts (GetPixels, SetPixels, etc).\n\nNote however that a copy of the texture data will be made, doubling the amount of memory required for the texture. This is only valid for uncompressed and DTX compressed textures, other types of compressed textures cannot be read from.", 35, OnDrawReadWriteEnabled, OnCompareReadWriteEnabled, OnExportReadWriteEnabled));

            Columns.Add(new Column("NPOTScale", "Non Power of 2 Scaling", "How non power of two textures are scaled on import.", 100, OnDrawNPOTScale, OnCompareNPOTScale, OnExportNPOTScale) { Visible = false });
            Columns.Add(new Column("Mips", "Mips", "Number of mipmaps in texture.", 40, OnDrawMips, OnCompareMips, OnExportMips) { Visible = false, HideIfDefault = true });
            Columns.Add(new Column("Mips Enabled", "Mips Enabled", "Generate Mip Maps.", 40, OnDrawMipsEnabled, OnCompareMipsEnabled, OnExportMipsEnabled) { Visible = false });
#if UNITY_2018_2_OR_NEWER
            Columns.Add(new Column("StreamingMips", "Streaming Mips", "", 115, OnDrawStreamingMips, OnCompareStreamingMips, OnExportStreamingMips) { Visible = false });
            Columns.Add(new Column("StreamingMipsPrio", "Streaming Mips Prio", "", 115, OnDrawStreamingMipsPrio, OnCompareStreamingMipsPrio, OnExportStreamingMipsPrio) { Visible = false });
#endif

            Columns.Add(new Column("Width", "Width", "Texture Width in pixels.", 45, OnDrawWidth, OnCompareWidth, OnExportWidth) { HideIfDefault = true });
            Columns.Add(new Column("Height", "Height", "Texture Height in pixels.", 45, OnDrawHeight, OnCompareHeight, OnExportHeight) { HideIfDefault = true });

            Columns.Add(new Column("Override", "Override", "Whether texture settings have been overridden for the selected platform.", 60, OnDrawOverride, OnCompareOverride, OnExportOverride) { Mode = Column.ColumnMode.PlatformSpecific, HideIfDefault = true });
            Columns.Add(new Column("MaxSize", "Max Size", "Maximum Texture Size in pixels.", 60, OnDrawMaxSize, OnCompareMaxSize, OnExportMaxSize) { Mode = Column.ColumnMode.PlatformSpecific });
            Columns.Add(new Column("TextureCompression", "Compression", "How will the texture be compressed?", 85, OnDrawCompression, OnCompareCompression, OnExportCompression) { Mode = Column.ColumnMode.PlatformSpecific });
            Columns.Add(new Column("FormatShort", "Format", "Internal representation used for the texture.", 115, OnDrawFormatShort, OnCompareFormatShort, OnExportFormatShort) { Mode = Column.ColumnMode.PlatformSpecific });
            Columns.Add(new Column("Format", "Format (full)", "Internal representation used for the texture.", 200, OnDrawFormat, OnCompareFormat, OnExportFormat) { Visible = false, Mode = Column.ColumnMode.PlatformSpecific });
            Columns.Add(new Column("CompressionQuality", "Compressor Quality", "Quality of texture compression (0=Fastest, 100=Best).", 85, OnDrawCompressionQuality, OnCompareCompressionQuality, OnExportCompressionQuality) { Visible = false, Mode = Column.ColumnMode.PlatformSpecific });
            Columns.Add(new Column("UseCrunchCompression", "Crunch", "Whether the texture is crunch-compressed to save space on disk.", 85, OnDrawUseCrunchCompression, OnCompareUseCrunchCompression, OnExportUseCrunchCompression) { Visible = false, Mode = Column.ColumnMode.PlatformSpecific });

#if UNITY_2017_2_OR_NEWER
            Columns.Add(new Column("TextureResizeAlgorithm", "Resize Algorithm", "", 115, OnDrawResizeAlgorithm, OnCompareResizeAlgorithm, OnExportResizeAlgorithm) { Visible = false, Mode = Column.ColumnMode.PlatformSpecific });
#endif

            Columns.Add(new Column("SourceWidth", "Source Width", "Width in pixels of source texture.", 40, OnDrawOriginalWidth, OnCompareOriginalWidth, OnExportOriginalWidth) { Visible = false });
            Columns.Add(new Column("SourceHeight", "Source Height", "Height in pixels of source texture.", 40, OnDrawOriginalHeight, OnCompareOriginalHeight, OnExportOriginalHeight) { Visible = false });

            Columns.Add(new Column("Wrap", "Wrap", "Texture Wrap Mode (U, V, W).", 60, OnDrawWrapMode, OnCompareWrapMode, OnExportWrapMode));
            Columns.Add(new Column("Filter", "Filter", "Texture Filter Mode.", 60, OnDrawFilterMode, OnCompareFilterMode, OnExportFilterMode));
            Columns.Add(new Column("Aniso", "Aniso", "Anisotropic Texture Filtering Level.", 40, OnDrawAnisoLevel, OnCompareAnisoLevel, OnExportAnisoLevel) { Visible = false });

            Columns.Add(new Column("PoT", "Power of 2", "Indicates whether the texture size is power of two.", 35, OnDrawIsPowerOfTwo, OnCompareIsPowerOfTwo, OnExportIsPowerOfTwo) { Visible = false, HideIfDefault = true });
            Columns.Add(new Column("Sqr", "Square", "Indicates whether the texture size is square (width and height are of equal size).", 35, OnDrawIsSquare, OnCompareIsSquare, OnExportIsSquare) { Visible = false, HideIfDefault = true });

            Columns.Add(new Column("ResizeRatio", "Resize Ratio", "The ratio between the number of pixels in the original texture and the imported texture.", 80, OnDrawPixelRatioPercentage, OnComparePixelRatioPercentage, OnExportPixelRatioPercentage) { Visible = false, HideIfDefault = true });
            Columns.Add(new Column("FileExtension", "Extension", "File extension of source texture.", 70, OnDrawFileExtension, OnCompareFileExtension, OnExportFileExtension) { Visible = false });

            Columns.Add(new Column("SpriteImportMode", "Sprite Mode", "Indicates how the the sprite graphic will be extracted from the image.", 90, OnDrawSpriteImportMode, OnCompareSpriteImportMode, OnExportSpriteImportMode) { Visible = false });
            Columns.Add(new Column("SpritePackingTag", "Sprite Packing Tag", "The name of an optional sprite atlas into which this texture should be packed.", 90, OnDrawSpritePackingTag, OnCompareSpritePackingTag, OnExportSpritePackingTag));
            Columns.Add(new Column("SpritePixelPerUnit", "Sprite Pixels per Unit", "The number of pixels of width/height in the sprite image that will correspond to one distance unit in world space.", 80, OnDrawSpritePixelPerUnit, OnCompareSpritePixelPerUnit, OnExportSpritePixelPerUnit) { Visible = false });


            // Colorize columns that contain platform settings
            //for (var n = 0; n < Columns.Count; ++n)
            //{
            //    var column = Columns[n] as Column;
            //    if (column.Mode == Column.ColumnMode.PlatformSpecific)
            //    {
            //        var tint = new Color(0.3f, 0.3f, 1, 0.06f);
            //        if (EditorGUIUtility.isProSkin)
            //            tint = new Color(0.7f, 0.7f, 1, 0.06f);

            //        column.Color = GUIColors.TintIfPlaying(tint);
            //    }
            //}

            // Hook into the asset pipeline, since we need to update the list in case the user deletes,
            // moves or imports assets while AudioClip Explorer is running.
            AssetFileWatcher.Imported += AssetFileWatcher_Imported;
            AssetFileWatcher.Deleted += AssetFileWatcher_Deleted;
            AssetFileWatcher.Moved += AssetFileWatcher_Moved;
        }
        #endregion

        #region Dispose
        public void Dispose()
        {
            if (_disposed)
                return;

            // check if it's empty to avoid overwriting a cache file
            // in case the plugin crashed and wasnt able to fill the cache.
            if (!_cache.IsEmpty)
                _cache.Write();

            AssetFileWatcher.Imported -= AssetFileWatcher_Imported;
            AssetFileWatcher.Deleted -= AssetFileWatcher_Deleted;
            AssetFileWatcher.Moved -= AssetFileWatcher_Moved;

            _cache = null;
            _items = null;
            _allitems = null;
            _disposed = true;
            GC.SuppressFinalize(this);
        }
        #endregion

        #region RefreshModels
        public void RefreshModels()
        {
            var platform = _platform;
            if (platform == BuildTargetGroup.Unknown)
                platform = BuildPipeline2.GetBuildTargetGroup(EditorUserBuildSettings.activeBuildTarget);

            _warningCount = 0;
            foreach (var model in _allitems)
            {
                model.SetPlatform(platform);

                if (model.PlatformHasIssue || model.HasError)
                    _warningCount++;
            }

            DoChanged();
        }
        #endregion

        /// <summary>
        /// Reads the cache file to speed up the SetItems() operation.
        /// </summary>
        public void ReadCacheFile()
        {
            _cache.Read();
        }

        public bool DeleteCacheFile()
        {
            return _cache.Delete();
        }

        #region DoTextureChanged
        /// <summary>
        /// Raises the Changed event.
        /// Call this method to notify subscribers about list content or state changes.
        /// </summary>
        void DoTextureChanged()
        {
            if (null != TextureChanged)
            {
                var cb = TextureChanged;
                cb.Invoke(this);
            }

            Editor.Repaint();
        }
        #endregion

        #region Search/Filter the list
        /// <summary>
        /// Begins changing filter settings.
        /// </summary>
        /// <remarks>
        /// Changing the filter is an expensive operation, because it causes the list to (re)sort.
        /// In order to avoid multiple sorts whenever one filter setting changes, we use do
        ///    BeginChangeFilter()
        ///    ... Change many filter settings here
        ///    EndChangeFilter()
        /// The EndChangeFilter() call will actually cause the list to (re)sort.
        /// </remarks>
        public void BeginChangeFilter()
        {
            _filterUpdateCount++;
        }

        /// <summary>
        /// Ends changing filter settings.
        /// </summary>
        public void EndChangeFilter()
        {
            _filterUpdateCount--;
            UpdateFilter();
        }

        /// <summary>
        /// Filters the list using the specified text and mode.
        /// </summary>
        /// <param name="text">The text a item must contain to match.</param>
        /// <param name="mode">The mode, in which property of the model, the search should check.</param>
        public void SetTextFilter(string text, TextFilterMode mode)
        {
            var parserresult = SearchTextParser.Parse(text);
            SetTextFilter(parserresult, mode);
        }

        void SetTextFilter(SearchTextParser.Result parserresult, TextFilterMode mode)
        {
            _filterResult = parserresult;
            _filterMode = mode;

            UpdateFilter();
        }

        /// <summary>
        /// Adds a texture type to the search filter.
        /// </summary>
        /// <param name="name">The texture type. Any value of TextureUtil2.TextureTypeStrings.</param>
        public void AddTypeFilter(TypeFilter filter)
        {
            if (!HasTypeFilter(filter))
            {
                _typeFilter.Add(filter);

                UpdateFilter();
            }
        }

        /// <summary>
        /// Removes a texture type from the search filter.
        /// </summary>
        /// <param name="name">The texture type. Any value of TextureUtil2.TextureTypeStrings.</param>
        public void RemoveTypeFilter(TypeFilter filter)
        {
            if (_typeFilter.Remove(filter))
                UpdateFilter();
        }

        /// <summary>
        /// Removes all texture types from the search filter.
        /// </summary>
        public void ClearTypeFilter()
        {
            _typeFilter.Clear();
            UpdateFilter();
        }

        /// <summary>
        /// Gets whether the search filter contains the specified texture type.
        /// </summary>
        /// <param name="name">The texture type. Any value of TextureUtil2.TextureTypeStrings.</param>
        /// <returns>true when it contains the specified texture type, false otherwise.</returns>
        public bool HasTypeFilter(TypeFilter filter)
        {
            if (_typeFilter.Contains(filter))
                return true;

            return false;
        }

        /// <summary>
        /// Gets how many texture type filters are set.
        /// </summary>
        public int GetTypeFilterCount()
        {
            return _typeFilter.Count;
        }

        /// <summary>
        /// Updates the content of the list using the current search filter.
        /// </summary>
        void UpdateFilter()
        {
            if (_filterUpdateCount > 0)
                return; // changing filter not ended yet

            // build the lookup table to speed up the operation to check
            // if a certain texture is whether visible due to the texture type filter.
            _typeFilterLookup = new Dictionary<int, TypeFilter>();
            foreach (var t in _typeFilter)
                _typeFilterLookup[t.GetHashCode()] = t;

            // check each item if it's included in the search filter
            _items = new List<Model>(_allitems.Count);
            for (var n = 0; n < _allitems.Count; ++n)
            {
                var item = _allitems[n];
                if (IsIncludedInFilter(item))
                    _items.Add(item);
            }

            // notify about changed
            DoChanged();
        }


        /// <summary>
        /// Gets whether the specified model matchs the filter criteria.
        /// </summary>
        /// <returns>true when the filter is matching and the item has to be included in the list, false otherwise.</returns>
        bool IsIncludedInFilter(Model model)
        {
            // check if the texture type (normalmap, reflection, etc) is allowed to
            // be displayed due to any existing type-filter that might be set.
            if (_typeFilterLookup.Count > 0)
            {
                if (!_typeFilterLookup.ContainsKey(TypeFilter.ComputeHashCode(model.TextureType, model.TextureShape)))
                    return false;
            }

            // filter does not contain any filter-text, so the item should be displayed
            if (_filterResult.NamesExpr.Count > 0)
            {
                // check if the filter text occurs in the name
                switch (_filterMode)
                {
                    case TextFilterMode.All:
                        if (_filterResult.IsNameMatch(model.AssetName))
                            return true;
                        if (_filterResult.IsNameMatch(model.AssetPath))
                            return true;
                        if (_filterResult.IsNameMatch(model.SpritePackingTag))
                            return true;
                        break;

                    case TextFilterMode.Name:
                        if (_filterResult.IsNameMatch(model.AssetName))
                            return true;
                        break;

                    case TextFilterMode.Path:
                        if (_filterResult.IsNameMatch(model.AssetPath))
                            return true;
                        break;

                    case TextFilterMode.SpritePackingTag:
                        if (_filterResult.IsNameMatch(model.SpritePackingTag))
                            return true;
                        break;
                }

                return false;
            }

            return true;
        }
        #endregion

        public void SetPlatform(BuildTargetGroup platform)
        {
            _platform = platform;

            var paths = GetAllPaths();
            SetItems(paths);
        }

        public BuildTargetGroup Platform
        {
            get
            {
                return _platform;
            }
        }

        Dictionary<string, int> _RendererCountLookup;
        public void SetSceneOccurrenceLookup(Dictionary<string, int> lookup)
        {
            _RendererCountLookup = lookup;
        }

        #region SetItems
        /// <summary>
        /// Sets the textures that should be shown in Texture Overview.
        /// </summary>
        /// <param name="paths">The asset paths of assets to add to the list.</param>
        public void SetItems(List<string> paths)
        {
            ProfilerUtility.BeginSample("Listbox.SetItems");

            // get memory usage of all assets currently loaded in unity
            // we use this to calculate a sane number of memory we can use while
            // loading textures. without limiting this, unity would crash with an out-of-memory error.
            long availableMemory = 0;
            {
                // calc how much memory we have to work with until we need to free resources
                // we want to leave 256mb free and never use more than 1024mb
                long _1024mb = 512 * 1024 * 1024;
                long memoryLimit = (SystemInfo.systemMemorySize * 1024 * 1024L) - _1024mb;
                availableMemory = Math.Max(0, Math.Min(_1024mb, memoryLimit));
            }

            var oldSelection = GetSelectedPaths();

            // build a list of texture files only
            _allitems = new List<Model>();
            var texpaths = new List<string>(paths.Count);
            //foreach (var path in paths)
            for (int n=0, nend=paths.Count; n<nend; ++n)
            {
                var path = paths[n];
                if (!IsSupportedFile(path))
                    continue;

                texpaths.Add(path);
            }

            using (var progressbar = new EditorGUI2.ModalProgressBar(string.Format("{0}: Loading", Globals.ProductTitle), true))
            {
                // indicates how many bytes are loaded during initialization
                // and is used to release memory at some threshold to prevent the
                // editor to crash with an out-of-mem exception.
                long loadedsize = 0;

                // create the model-representation for each texture in texpaths
                for (var n = 0; n < texpaths.Count; ++n)
                {
                    var path = texpaths[n];

                    // report the progress to the user, since it can be a time consuming operation to read many textures.
                    if (progressbar.TotalElapsedTime > 1.0f && progressbar.ElapsedTime > 0.1f)
                    {
                        var progress = n / (float)texpaths.Count;
                        var text = string.Format("[{1} remaining] {0}", FileUtil2.GetFileName(path), texpaths.Count - n - 1);
                        if (progressbar.Update(text, progress))
                            break;
                    }

                    // initialize the model-representation
                    Model model = null;
                    loadedsize += InitModel(ref model, path);

                    model.RendererCount = 0;
                    if (_RendererCountLookup != null && !model.HasError)
                    {
                        _RendererCountLookup.TryGetValue(model.AssetGuid, out model.RendererCount);
                    }

                    // check if we have loaded so much memory, that we need to release it to avoid an editor crash
                    CheckUnloadUnused(ref loadedsize, availableMemory);

                    _allitems.Add(model);
                }

                // if it actually loaded new texture settings make
                // sure to save the cache file
                if (loadedsize > 0)
                    _cache.Write();
            }

            _items = new List<Model>(_allitems);
            RefreshModels();
            Sort();

            // Restore the previous selection
            var newSelection = new List<Model>(oldSelection.Count);
            for (int n = 0, nend = oldSelection.Count; n < nend; ++n)
            {
                var model = FindModel(oldSelection[n]);
                if (model != null)
                    newSelection.Add(model);
            }
            SelectedItems = newSelection.ToArray();

            ProfilerUtility.EndSample();
        }
        #endregion

        #region IsSupportedFile
        /// <summary>
        /// Gets whether the asset of the specified path is supported to be displayed in Texture Overview.
        /// </summary>
        /// <param name="path">The relative asset path</param>
        bool IsSupportedFile(string path)
        {
            var type = AssetDatabase2.GetAssetType(path);
            if (type == null)
                return false;

            if (!typeof(Texture).IsAssignableFrom(type))
                return false;

            // Ignore textures in StreamingAssets, because they're not imported and can't be read
            if (path.IndexOf("/StreamingAssets/", StringComparison.OrdinalIgnoreCase) != -1)
                return false;

            if (!Globals.ShowEditorAssets)
            {
                if (path.IndexOf("/Editor Resources/", StringComparison.OrdinalIgnoreCase) != -1)
                    return false;

                if (path.IndexOf("/Editor/", StringComparison.OrdinalIgnoreCase) != -1)
                    return false;

                if (path.IndexOf("/Editor Default Resources/", StringComparison.OrdinalIgnoreCase) != -1)
                    return false;

                if (path.IndexOf("/Gizmos/", StringComparison.OrdinalIgnoreCase) != -1)
                    return false;
            }

            if (!Globals.ShowPackageAssets)
            {
                if (path.IndexOf("Packages/", StringComparison.OrdinalIgnoreCase) != -1)
                    return false;
            }

            return true;
        }
        #endregion

        #region CheckUnloadUnused
        /// <summary>
        /// Call this method after every InitModel(). It sums the sizes of the loaded
        /// clips and makes sure to unload those when a certail memory consumtion threshold has been reached.
        /// </summary>
        void CheckUnloadUnused(ref long loadedsize, long availableMemory)
        {
            if (loadedsize <= 0)
                return;

            // if a certain memory threshold has been reached
            // we force the editor to unload unused assets.
            // without doing this, the editor will crash by an out-of-memory exception eventually.
            if (loadedsize >= availableMemory)
            {
                _cache.Write(); // also a good idea to write the cache file, in case unity crashes for an unknown reason, we have at least the textures already read into the cache
                EditorUtility2.UnloadUnusedAssetsImmediate();
                loadedsize = 0;
                System.Threading.Thread.Sleep(1); // ios editor workaround: the ios editor does not immediately release unused memory, but after a sleep. meh.
            }
        }
        #endregion

        #region InitModel
        /// <summary>
        /// Initializes the specified model of the specified path.
        /// </summary>
        /// <returns>
        /// returns the amount of memory the editor had to allocate to initialize the model.
        /// </returns>
        long InitModel(ref Model model, string path)
        {
            // do we already have a model for the specified path?
            if (null == model)
            {
                // nope, try to get it from the cache
                var guid = AssetDatabase.AssetPathToGUID(path);
                if (_cache.TryGetEntry(guid, out model, true))
                {
                    // Platform settings can be unavailable if a platform module
                    // in Unity has been installed after this plugin has created
                    // a cache entry already.
                    if (model.GetImporterSettingsAvailable(_platform))
                        return 0; // read from cache
                }

                // it's not in the cache yet, so create a new Model instead
                model = new Model();
            }

            // it's not located in cache, initialize it the expensive way
            var loadedAssetSize = model.Init(path);
            _cache.UpdateEntry(model);

            return loadedAssetSize;
        }
        #endregion

        #region FindModel
        /// <summary>
        /// Finds the model with the specified assetPath.
        /// </summary>
        /// <param name="assetPath">The path.</param>
        /// <returns>The model on success, null otherwise.</returns>
        Model FindModel(string assetPath)
        {
            // we could also use a dictionary to speedup the search,
            // but this has not been a performance issue yet, not even with 20000 textures.
            for (int n=0, nend=_allitems.Count; n<nend; ++n)
            {
                var model = _allitems[n];
                if (string.Equals(assetPath, model.AssetPath, StringComparison.OrdinalIgnoreCase))
                    return model;
            }
            return null;
        }
        #endregion

        #region Helper methods to get selected paths/models/textures
        /// <summary>
        /// Gets all models that are currently selected in Texture Overview.
        /// </summary>
        List<Model> GetSelectedModels()
        {
            var selection = SelectedItems;
            var objects = new List<Model>(selection.Length);
            foreach (var item in selection)
            {
                var model = item as Model;
                objects.Add(model);
            }
            return objects;
        }

        /// <summary>
        /// Gets all paths that are currently selected in Texture Overview.
        /// </summary>
        List<string> GetSelectedPaths()
        {
            var selection = SelectedItems;
            var paths = new List<string>(selection.Length);
            foreach (var item in selection)
            {
                var model = item as Model;
                if (!string.IsNullOrEmpty(model.AssetPath))
                    paths.Add(model.AssetPath);
            }
            return paths;
        }

        List<string> GetAllPaths()
        {
            var paths = new List<string>(_allitems.Count);
            for (int n = 0, nend = _allitems.Count; n < nend; ++n)
            {
                paths.Add(_allitems[n].AssetPath);
            }

            return paths;
        }

        /// <summary>
        /// Gets all textures that are currently selected in Texture Overview.
        /// </summary>
        /// <remarks>
        /// To return the Texture, the asset actually needs to be loaded into memory.
        /// This can be an expensive operation and since Unity is 32bit only, it might even
        /// crash the editor when you try to get/load more textures into memory than there
        /// is available due to the 32bit limit.
        /// Unlike the Unity editor, we display a progressbar during this time, so it won't look like
        /// the editor freezed when a large amount of textures are selected.
        /// </remarks>
        /// <param name="showprogress">Indicates whether a progressbar should be shown.</param>
        /// <param name="maxcount">Maximum count of textures that are allowed  to be returned.</param>
        List<UnityEngine.Object> GetSelectedAssets(bool showprogress, int maxcount)
        {
            var objects = new List<UnityEngine.Object>(64);
            using (var progressbar = new EditorGUI2.ModalProgressBar(string.Format("{0}: Loading", Globals.ProductTitle), true))
            {
                var selection = SelectedItems;
                for (var n = 0; n < Mathf.Min(maxcount, selection.Length); ++n)
                {
                    var model = selection[n] as Model;
                    if (string.IsNullOrEmpty(model.AssetGuid))
                        continue;

                    var assetPath = AssetDatabase.GUIDToAssetPath(model.AssetGuid);
                    if (string.IsNullOrEmpty(assetPath))
                        continue;

                    if (showprogress && progressbar.TotalElapsedTime > 1.0f && progressbar.ElapsedTime > 0.1f)
                    {
                        var progress = n / (float)selection.Length;
                        var text = string.Format("[{1} remaining] {0}", FileUtil2.GetFileNameWithoutExtension(assetPath), selection.Length - n - 1);
                        if (progressbar.Update(text, progress))
                            break;
                    }

                    var asset = AssetDatabase.LoadMainAssetAtPath(assetPath);
                    if (null != asset)
                        objects.Add(asset);
                }
            }
            return objects;
        }
        #endregion

        #region OnBeginDrag
        /// <summary>
        /// Occurs at the beginning of a Drag&Drop operation.
        /// </summary>
        protected override void OnBeginDrag(int index, out UnityEngine.Object[] objects, out string[] paths)
        {
            paths = GetSelectedPaths().ToArray();
            objects = GetSelectedAssets(SelectedItemsCount > 20, int.MaxValue).ToArray();
        }
        #endregion

        #region OnSorting
        /// <summary>
        /// Occurs when the user requests to sort the list.
        /// </summary>
        /// <returns>Returns the array of items to sort.</returns>
        protected override object[] OnBeforeSortItems()
        {
            return _allitems.ToArray();
        }

        /// <summary>
        /// Occurs after sorting completed.
        /// </summary>
        /// <param name="models">The sorted data. This is the data returned by OnBeforeSortItems(), but sorted.</param>
        protected override void OnAfterSortItems(object[] models)
        {
            base.OnAfterSortItems(models);

            _allitems = new List<Model>((Model[])models); // write the sorted data back to our data model
            SetTextFilter(_filterResult, _filterMode); // make sure any existing filter will still have impact on the now sorted list
        }
        #endregion

        #region OnSelectionChange
        /// <summary>
        /// Occurs when the list selection changed.
        /// </summary>
        protected override void OnSelectionChange()
        {
            base.OnSelectionChange();
            DoChanged();
        }
        #endregion

        #region OnItemContextMenu
        /// <summary>
        /// Occurs when the user requests the context menu.
        /// </summary>
        protected override void OnItemContextMenu(GUIListViewContextMenuArgs args)
        {
            base.OnItemContextMenu(args);

            if (SelectedItemsCount < 1)
                return; // no item selected, do not open a context menu

            GUIUtility.hotControl = 0;
            var model = args.Model as Model;

            var menu = new GenericMenu();
            menu.AddItem(new GUIContent(Application.platform == RuntimePlatform.OSXEditor ? "Reveal in Finder" : "Show in Explorer"), false, SelectedItemsCount <= 10 ? OnContextMenuShowInExplorer : (GenericMenu.MenuFunction2)null, model);
            menu.AddItem(new GUIContent("Open %enter"), false, OnContextMenuOpenWithDefaultApp, model);
            menu.AddItem(new GUIContent("Delete... _delete"), false, OnContextMenuDelete);
            menu.AddItem(new GUIContent(string.Empty), false, null);
            menu.AddItem(new GUIContent("Select in Project _enter"), false, OnContextMenuSelect);
            menu.AddItem(new GUIContent("Find References In Scene"), false, SelectedItemsCount == 1 ? OnContextMenuFindReferencesInScene : (GenericMenu.MenuFunction)null);
            menu.AddItem(new GUIContent("Find Materials in Project"), false, OnContextMenuFindMaterialsInProject);
            menu.AddItem(new GUIContent("Find Prefabs in Project"), false, OnContextMenuFindPrefabsInProject);
            menu.AddItem(new GUIContent("Find Prefabs and Scenes in Project"), false, OnContextMenuFindPrefabsAndScenesInProject);
            menu.AddItem(new GUIContent(string.Empty), false, null);
            menu.AddItem(new GUIContent("Reimport"), false, OnContextMenuReimport);
            menu.AddItem(new GUIContent(string.Empty), false, null);
            menu.AddItem(new GUIContent("Copy Full Path"), false, OnContextMenuCopyFullPath);

            // display the context menu. make sure to use the provided args.MenuLocation position
            // rather than 'Event.current.mousePosition', because the user could have been pressed
            // the context-menu key as well, thus mousePosition would be most likely wrong.
            menu.DropDown(new Rect(args.MenuLocation.x, args.MenuLocation.y, 0, 0));
            Event.current.Use();
            Editor.Repaint();
        }

        void OnContextMenuShowInExplorer(object userData)
        {
            var paths = GetSelectedPaths();
            EditorApplication2.ShowInExplorer(paths.ToArray());
            Editor.Repaint();
        }

        void OnContextMenuOpenWithDefaultApp(object userData)
        {
            var paths = GetSelectedPaths();
            EditorApplication2.OpenAssets(paths.ToArray());
            Editor.Repaint();
        }

        void OnContextMenuDelete()
        {
            var paths = GetSelectedPaths();
            AssetDatabase2.Delete(paths);
            Editor.Focus(); // make sure to focus our plugin window again after the user confirmed the messagebox
            Editor.Repaint();
        }

        void OnContextMenuSelect()
        {
            var clips = GetSelectedAssets(SelectedItemsCount > 20, int.MaxValue);
            Selection.objects = clips.ToArray();
        }

        void OnContextMenuFindMaterialsInProject()
        {
            FindAssetUsageWindow.FindUsageInProject(Globals.ProductId, Globals.ProductTitle, GetSelectedPaths(), new[] { typeof(Material) });
        }

        void OnContextMenuFindPrefabsInProject()
        {
            FindAssetUsageWindow.FindUsageInProject(Globals.ProductId, Globals.ProductTitle, GetSelectedPaths(), new[] { typeof(GameObject) });
        }

        void OnContextMenuFindPrefabsAndScenesInProject()
        {
            FindAssetUsageWindow.FindUsageInProject(Globals.ProductId, Globals.ProductTitle, GetSelectedPaths(), new[] { typeof(GameObject), typeof(AssetDatabase2.UnityScene) });
        }

        void OnContextMenuFindReferencesInScene()
        {
            var objects = GetSelectedAssets(false, 1);
            if (objects.Count > 0)
            {
                EditorApplication2.FindReferencesInScene(objects[0]);
                EditorUtility2.UnloadUnusedAssetsImmediate();
            }
        }

        void OnContextMenuReimport()
        {
            var paths = GetSelectedPaths();
            AssetDatabase2.Reimport(paths, 10);
        }

        void OnContextMenuCopyFullPath()
        {
            var paths = GetSelectedPaths();
            ClipboardUtil.CopyPaths(paths);
        }
        #endregion

        #region OnItemKeyDown
        /// <summary>
        /// Occurs when the user presses a key.
        /// </summary>
        protected override void OnItemKeyDown(ref GUIListViewItemKeyDownArgs args)
        {
            switch (Event.current.keyCode)
            {
                case KeyCode.Delete:
                    //OnContextMenuDelete();
                    EditorApplication.delayCall += OnContextMenuDelete; // delay to avoid InvalidOperationException in UnityEditor.EditorGUI.EndDisabledGroup
                    args.Handled = true;
                    break;

                case KeyCode.Return:
                    if (Event.current.control) // Ctrl+Return opens selected textures in the default application
                    {
                        OnContextMenuOpenWithDefaultApp(args.Model);
                        args.Handled = true;
                    }
                    else // Return assigns selected textures to the Unity Inspector
                    {
                        //OnContextMenuSelect();
                        EditorApplication.delayCall += OnContextMenuSelect; // delay to avoid InvalidOperationException in UnityEditor.EditorGUI.EndDisabledGroup
                        args.Handled = true;
                    }
                    break;
            }
        }
        #endregion

        #region OnItemDoubleClick
        /// <summary>
        /// Occurs when the user double clicks an item.
        /// </summary>
        /// <param name="index">The index of the item.</param>
        protected override void OnItemDoubleClick(GUIListViewItemDoubleClickArgs args)
        {
            base.OnItemDoubleClick(args);

            // a double-click actually forces the list to have only 1 item selected,
            // so we also just get one clip here.
            var objs = GetSelectedAssets(false, 1);
            if (objs.Count > 0)
            {
                ChangeUnitySelectionTime = DateTime.Now.TimeOfDay.TotalSeconds; // store at which time the user invoked the selected model, in order to avoid a feedback loop if the plugin is listening to selection changes.
                Selection.activeObject = objs[0];
                EditorGUIUtility.PingObject(objs[0]);
            }
        }
        #endregion

        #region OnGetItemKeyword
        /// <summary>
        /// Gets the item keyword for the specified args.
        /// </summary>
        /// <remarks>
        /// The item-keyword is used to jump to a particular item in the list
        /// when the user pressed a key. When a model begins with the keyword(sequence) the list jumps to it.
        /// </remarks>
        protected override string OnGetItemKeyword(GUIListViewGetItemKeywordArgs args)
        {
            var model = args.Model as Model;
            if (model != null)
                return model.AssetName;

            return null;
        }
        #endregion

        #region OnGetItem
        /// <summary>
        /// Gets the item at the specified index.
        /// </summary>
        protected override object OnGetItem(int index)
        {
            if (index < 0 || index >= _items.Count)
                return null;

            return _items[index];
        }
        #endregion

        #region OnGetItemCount
        /// <summary>
        /// Gets the count of items in the list.
        /// </summary>
        protected override int OnGetItemCount()
        {
            return _items.Count;
        }
        #endregion

        #region OnGetItemText
        /// <summary>
        /// Gets the item text of the specified column.
        /// </summary>
        protected override string OnGetItemText(GUIListViewGetItemTextArgs args)
        {
            var column = args.Column as Column;
            return column.Exporter(args.Model as Model);
        }
        #endregion

        #region OnDrawItem
        /// <summary>
        /// Occurs when a list item is requested to draw.
        /// </summary>
        /// <param name="args">The data containing all the information needed to draw the item.</param>
        protected override void OnDrawItem(GUIListViewDrawItemArgs args)
        {
            var model = args.Model as Model;
            if (null == model)
                return;

            // if the texture could not be read, thus has an error,
            // just display a red box with the path.
            if (model.HasError)
            {
                if (args.Column == this.FirstVisibleColumn)
                {
                    DrawItemImageHelper(ref args.ItemRect, GUIContent2.Temp(Images.Error16x16, "The texture could not be loaded."), new Vector2(16, 16));
                    args.ItemRect.y += 4; args.ItemRect.height -= 4;
                    EditorGUI2.Label(args.ItemRect, "ERROR: " + model.AssetPath, args.Selected);
                }
                return;
            }

            // if this is the first column in the list, display an icon there
            if (args.Column.IsPrimaryColumn)
            {
                DrawItemImageHelper(ref args.ItemRect, model.AllocAssetIcon(), new Vector2(16, 16));

                if (model.PlatformHasIssue)
                {
                    DrawItemImageHelper(ref args.ItemRect, new GUIContent("", Images.Warning16x16, model.PlatformIssueString), new Vector2(16, 16));
                }
            }

            // make the text appear vertically centered in the row
            args.ItemRect.width -= 5;
            args.ItemRect.y += 4; args.ItemRect.height -= 4;

            // draw the models value using the specified custom drawer method
            var column = args.Column as Column;
            if (null != column && null != column.Drawer)
            {
                if (column.HideIfDefault && _platform == BuildTargetGroup.Unknown)
                    return;

                column.Drawer(model, args);
            }
        }
        #endregion

        #region OnItemHide
        /// <summary>
        /// Called when the item goes out of view.
        /// </summary>
        /// <param name="model">The Model</param>
        protected override void OnItemHide(object item)
        {
            base.OnItemHide(item);

            var model = item as Model;
            if (null == model)
                return;

            model.ReleaseAssetIcon();
        }
        #endregion

        #region Draw/Compare AssetPath
        void OnDrawAssetPath(Model model, GUIListViewDrawItemArgs args)
        {
            EditorGUI2.PathLabel(args.ItemRect, model.AssetPath, args.Selected);
        }

        int OnCompareAssetPath(Model x, Model y)
        {
            return string.Compare(x.AssetPath, y.AssetPath, StringComparison.OrdinalIgnoreCase);
        }

        string OnExportAssetPath(Model model)
        {
            return model.AssetPath;
        }
        #endregion

        #region Draw/Compare AssetName
        void OnDrawAssetName(Model model, GUIListViewDrawItemArgs args)
        {
            EditorGUI2.Label(args.ItemRect, model.AssetName, args.Selected);
        }

        int OnCompareAssetName(Model x, Model y)
        {
            return string.Compare(x.AssetName, y.AssetName, StringComparison.OrdinalIgnoreCase);
        }

        string OnExportAssetName(Model model)
        {
            return model.AssetName;
        }
        #endregion

        #region Draw/Compare TextureType
        void OnDrawRendererCount(Model model, GUIListViewDrawItemArgs args)
        {
            if (_RendererCountLookup == null)
                return;

            EditorGUI2.Label(args.ItemRect, model.RendererCount.ToString(), args.Selected);
        }

        int OnCompareRendererCount(Model x, Model y)
        {
            return x.RendererCount.CompareTo(y.RendererCount);
        }

        string OnExportRendererCount(Model model)
        {
            return model.RendererCount.ToString();
        }
        #endregion
        

        #region Draw/Compare TextureType
        void OnDrawImportType(Model model, GUIListViewDrawItemArgs args)
        {
            EditorGUI2.Label(args.ItemRect, model.TextureTypeString, args.Selected);
        }

        int OnCompareImportType(Model x, Model y)
        {
            return string.Compare(x.TextureTypeString, y.TextureTypeString, StringComparison.CurrentCultureIgnoreCase);
        }

        string OnExportImportType(Model model)
        {
            return model.TextureTypeString;
        }
        #endregion

        #region Draw/Compare TextureShape
        void OnDrawImportShape(Model model, GUIListViewDrawItemArgs args)
        {
            EditorGUI2.Label(args.ItemRect, model.TextureShapeString, args.Selected);
        }

        int OnCompareImportShape(Model x, Model y)
        {
            return string.Compare(x.TextureShapeString, y.TextureShapeString, StringComparison.CurrentCultureIgnoreCase);
        }

        string OnExportImportShape(Model model)
        {
            return model.TextureShapeString;
        }
        #endregion

        #region Draw/Compare Compression
        void OnDrawCompression(Model model, GUIListViewDrawItemArgs args)
        {
            var value = model.GetImporterTextureCompression(_platform);
            var text = TextureUtil2.GetCompressionString(value);

            EditorGUI2.Label(args.ItemRect, text, args.Selected);
        }

        int OnCompareCompression(Model x, Model y)
        {
            var xx = TextureUtil2.GetCompressionString(x.GetImporterTextureCompression(_platform));
            var yy = TextureUtil2.GetCompressionString(y.GetImporterTextureCompression(_platform));
            return xx.CompareTo(yy);
        }

        string OnExportCompression(Model model)
        {
            var value = TextureUtil2.GetCompressionString(model.GetImporterTextureCompression(_platform));
            return value;
        }
        #endregion

        #region Draw/Compare MaxTextureSize
        void OnDrawMaxSize(Model model, GUIListViewDrawItemArgs args)
        {
            var value = model.GetImporterMaxSize(_platform);
            EditorGUI2.Label(args.ItemRect, value.ToString(), args.Selected);
        }

        int OnCompareMaxSize(Model x, Model y)
        {
            var xx = x.GetImporterMaxSize(_platform);
            var yy = y.GetImporterMaxSize(_platform);
            return xx.CompareTo(yy);
        }

        string OnExportMaxSize(Model model)
        {
            var value = model.GetImporterMaxSize(_platform);
            return value.ToString();
        }
        #endregion

        #region Draw/Compare TextureFormat
        void OnDrawFormat(Model model, GUIListViewDrawItemArgs args)
        {
            if (_platform == BuildTargetGroup.Unknown)
            {
                EditorGUI2.Label(args.ItemRect, "Auto", args.Selected);
                return;
            }

            var value = TextureUtil2.GetTextureImporterFormatLongString(model.PlatformFormat);
            EditorGUI2.Label(args.ItemRect, value, args.Selected);
        }

        int OnCompareFormat(Model x, Model y)
        {
            if (_platform == BuildTargetGroup.Unknown)
                return 0;

            var xx = TextureUtil2.GetTextureImporterFormatLongString(x.PlatformFormat);
            var yy = TextureUtil2.GetTextureImporterFormatLongString(y.PlatformFormat);
            return string.Compare(xx, yy, StringComparison.CurrentCultureIgnoreCase);
        }

        string OnExportFormat(Model model)
        {
            if (_platform == BuildTargetGroup.Unknown)
                return "Auto";

            var value = TextureUtil2.GetTextureImporterFormatLongString(model.PlatformFormat);
            return value;
        }
        #endregion

        #region Draw/Compare TextureFormatShort
        void OnDrawFormatShort(Model model, GUIListViewDrawItemArgs args)
        {
            if (_platform == BuildTargetGroup.Unknown)
            {
                EditorGUI2.Label(args.ItemRect, "Auto", args.Selected);
                return;
            }

            var value = TextureUtil2.GetTextureImporterFormatString(model.PlatformFormat);
            if (value == null)
            {
                value = TextureUtil2.GetTextureImporterFormatString(model.PlatformFormat);
            }

            EditorGUI2.Label(args.ItemRect, value.ToString(), args.Selected);
        }

        int OnCompareFormatShort(Model x, Model y)
        {
            if (_platform == BuildTargetGroup.Unknown)
                return 0;

            var xx = TextureUtil2.GetTextureImporterFormatString(x.PlatformFormat);
            var yy = TextureUtil2.GetTextureImporterFormatString(y.PlatformFormat);
            return string.Compare(xx.ToString(), yy.ToString(), StringComparison.CurrentCultureIgnoreCase);
        }

        string OnExportFormatShort(Model model)
        {
            if (_platform == BuildTargetGroup.Unknown)
                return "Auto";

            var value = TextureUtil2.GetTextureImporterFormatString(model.PlatformFormat);
            return value.ToString();
        }
        #endregion

        #region Draw/Compare ResizeAlgorithm
#if UNITY_2017_2_OR_NEWER
        void OnDrawResizeAlgorithm(Model model, GUIListViewDrawItemArgs args)
        {
            var valueString = TextureUtil2.GetResizeAlgorithmString(model.GetImporterResizeAlgorithm(_platform));
            EditorGUI2.Label(args.ItemRect, valueString, args.Selected);
        }

        int OnCompareResizeAlgorithm(Model x, Model y)
        {
            var xx = TextureUtil2.GetResizeAlgorithmString(x.GetImporterResizeAlgorithm(_platform));
            var yy = TextureUtil2.GetResizeAlgorithmString(y.GetImporterResizeAlgorithm(_platform));
            return xx.CompareTo(yy);
        }

        string OnExportResizeAlgorithm(Model model)
        {
            var valueString = TextureUtil2.GetResizeAlgorithmString(model.GetImporterResizeAlgorithm(_platform));
            return valueString;
        }
#endif
        #endregion

        #region Draw/Compare NPOTScale
        void OnDrawNPOTScale(Model model, GUIListViewDrawItemArgs args)
        {
            var valueString = TextureUtil2.GetNPOTScaleString(model.NPOTScale);
            EditorGUI2.Label(args.ItemRect, valueString, args.Selected);
        }

        int OnCompareNPOTScale(Model x, Model y)
        {
            var xx = TextureUtil2.GetNPOTScaleString(x.NPOTScale);
            var yy = TextureUtil2.GetNPOTScaleString(y.NPOTScale);
            return xx.CompareTo(yy);
        }

        string OnExportNPOTScale(Model model)
        {
            var valueString = TextureUtil2.GetNPOTScaleString(model.NPOTScale);
            return valueString;
        }
        #endregion

        #region Draw/Compare CompressionQuality
        void OnDrawCompressionQuality(Model model, GUIListViewDrawItemArgs args)
        {
            var value = model.GetImporterCompressionQuality(_platform);
            var valueString = TextureUtil2.GetCompressionQualityString(value);
            EditorGUI2.Label(args.ItemRect, valueString, args.Selected);
        }

        int OnCompareCompressionQuality(Model x, Model y)
        {
            var xx = x.GetImporterCompressionQuality(_platform);
            var yy = y.GetImporterCompressionQuality(_platform);
            return xx.CompareTo(yy);
        }

        string OnExportCompressionQuality(Model model)
        {
            var value = model.GetImporterCompressionQuality(_platform);
            var valueString = TextureUtil2.GetCompressionQualityString(value);
            return valueString;
        }
        #endregion

        #region Draw/Compare UseCrunchCompression
        void OnDrawUseCrunchCompression(Model model, GUIListViewDrawItemArgs args)
        {
            var value = model.GetImporterUseCrunchCompression(_platform);
            DrawToggle(args, value);
        }

        int OnCompareUseCrunchCompression(Model x, Model y)
        {
            var xx = x.GetImporterUseCrunchCompression(_platform);
            var yy = y.GetImporterUseCrunchCompression(_platform);
            return xx.CompareTo(yy);
        }

        string OnExportUseCrunchCompression(Model model)
        {
            var value = model.GetImporterUseCrunchCompression(_platform);
            return value.ToString();
        }
        #endregion

        #region Draw/Compare FilterMode
        void OnDrawFilterMode(Model model, GUIListViewDrawItemArgs args)
        {
            var value = TextureUtil2.GetFilterModeString(model.FilterMode);
            EditorGUI2.Label(args.ItemRect, value, args.Selected);
        }

        int OnCompareFilterMode(Model x, Model y)
        {
            var xx = TextureUtil2.GetFilterModeString(x.FilterMode);
            var yy = TextureUtil2.GetFilterModeString(y.FilterMode);

            return string.Compare(xx, yy, StringComparison.CurrentCultureIgnoreCase);
        }

        string OnExportFilterMode(Model model)
        {
            var value = TextureUtil2.GetFilterModeString(model.FilterMode);
            return value;
        }
        #endregion

        #region Draw/Compare WrapMode
        void OnDrawWrapMode(Model model, GUIListViewDrawItemArgs args)
        {
#if UNITY_2017_OR_NEWER
            var value = TextureUtil2.GetWrapModeString(model.TextureShape, model.WrapModeU, model.WrapModeV, model.WrapModeW);
#else
            var value = TextureUtil2.GetWrapModeString(model.WrapMode);
#endif
            EditorGUI2.Label(args.ItemRect, value, args.Selected);
        }

        int OnCompareWrapMode(Model x, Model y)
        {
#if UNITY_2017_OR_NEWER
            var xx = TextureUtil2.GetWrapModeString(x.TextureShape, x.WrapModeU, x.WrapModeV, x.WrapModeW);
            var yy = TextureUtil2.GetWrapModeString(y.TextureShape, y.WrapModeU, y.WrapModeV, y.WrapModeW);
#else
            var xx = TextureUtil2.GetWrapModeString(x.WrapMode);
            var yy = TextureUtil2.GetWrapModeString(y.WrapMode);
#endif
            return string.Compare(xx, yy, StringComparison.CurrentCultureIgnoreCase);
        }

        string OnExportWrapMode(Model model)
        {
#if UNITY_2017_OR_NEWER
            var value = TextureUtil2.GetWrapModeString(model.TextureShape, model.WrapModeU, model.WrapModeV, model.WrapModeW);
#else
            var value = TextureUtil2.GetWrapModeString(model.WrapMode);
#endif
            return value;
        }
        #endregion

        #region Draw/Compare Mips
        void OnDrawMips(Model model, GUIListViewDrawItemArgs args)
        {
            EditorGUI2.Label(args.ItemRect, model.PlatformMipmapCount.ToString(), args.Selected);
        }

        int OnCompareMips(Model x, Model y)
        {
            return x.PlatformMipmapCount.CompareTo(y.PlatformMipmapCount);
        }

        string OnExportMips(Model model)
        {
            return model.PlatformMipmapCount.ToString();
        }
        #endregion

        #region Draw/Compare MipmapEnabled
        void OnDrawMipsEnabled(Model model, GUIListViewDrawItemArgs args)
        {
            DrawToggle(args, model.MipmapEnabled);
        }

        int OnCompareMipsEnabled(Model x, Model y)
        {
            return x.MipmapEnabled.CompareTo(y.MipmapEnabled);
        }

        string OnExportMipsEnabled(Model model)
        {
            return model.MipmapEnabled.ToString();
        }
        #endregion

#if UNITY_2018_2_OR_NEWER
        #region Draw/Compare StreamingMipmaps
        void OnDrawStreamingMips(Model model, GUIListViewDrawItemArgs args)
        {
            DrawToggle(args, model.StreamingMipmaps);
        }

        int OnCompareStreamingMips(Model x, Model y)
        {
            return x.StreamingMipmaps.CompareTo(y.StreamingMipmaps);
        }

        string OnExportStreamingMips(Model model)
        {
            return model.StreamingMipmaps.ToString();
        }
        #endregion

        #region Draw/Compare StreamingMipmapsPriority
        void OnDrawStreamingMipsPrio(Model model, GUIListViewDrawItemArgs args)
        {
            EditorGUI2.Label(args.ItemRect, model.StreamingMipmapsPriority.ToString(), args.Selected);
        }

        int OnCompareStreamingMipsPrio(Model x, Model y)
        {
            return x.StreamingMipmapsPriority.CompareTo(y.StreamingMipmapsPriority);
        }

        string OnExportStreamingMipsPrio(Model model)
        {
            return model.StreamingMipmapsPriority.ToString();
        }
        #endregion
#endif

        #region Draw/Compare IsLinearSampling
        void OnDrawsRGBTexture(Model model, GUIListViewDrawItemArgs args)
        {
            DrawToggle(args, model.sRGBTexture);
        }

        int OnComparesRGBTexture(Model x, Model y)
        {
            return x.sRGBTexture.CompareTo(y.sRGBTexture);
        }

        string OnExportsRGBTexture(Model model)
        {
            return model.sRGBTexture.ToString();
        }
        #endregion

        #region Draw/Compare FileExtension
        void OnDrawFileExtension(Model model, GUIListViewDrawItemArgs args)
        {
            EditorGUI2.Label(args.ItemRect, model.FileExtension, args.Selected);
        }

        int OnCompareFileExtension(Model x, Model y)
        {
            return string.Compare(x.FileExtension, y.FileExtension, StringComparison.OrdinalIgnoreCase);
        }

        string OnExportFileExtension(Model model)
        {
            return model.FileExtension;
        }
        #endregion

        #region Draw/Compare StorageSize
        void OnDrawStorageSize(Model model, GUIListViewDrawItemArgs args)
        {
            EditorGUI2.Label(args.ItemRect, model.StorageSizeString, args.Selected);
        }

        int OnCompareStorageSize(Model x, Model y)
        {
            return x.PlatformStorageSize.CompareTo(y.PlatformStorageSize);
        }

        string OnExportStorageSize(Model model)
        {
            return model.PlatformStorageSize.ToString();
        }
        #endregion

        #region Draw/Compare RuntimeSize
        void OnDrawRuntimeSize(Model model, GUIListViewDrawItemArgs args)
        {
            EditorGUI2.Label(args.ItemRect, model.RuntimeSizeString, args.Selected);
        }

        int OnCompareRuntimeSize(Model x, Model y)
        {
            return x.PlatformRuntimeSize.CompareTo(y.PlatformRuntimeSize);
        }

        string OnExportRuntimeSize(Model model)
        {
            return model.PlatformRuntimeSize.ToString();
        }
        #endregion

        #region Draw/Compare CpuSize
        void OnDrawCpuSize(Model model, GUIListViewDrawItemArgs args)
        {
            EditorGUI2.Label(args.ItemRect, model.CpuSizeString, args.Selected);
        }

        int OnCompareCpuSize(Model x, Model y)
        {
            return x.PlatformCpuSize.CompareTo(y.PlatformCpuSize);
        }

        string OnExportCpuSize(Model model)
        {
            return model.PlatformCpuSize.ToString();
        }
        #endregion

        #region Draw/Compare GpuSize
        void OnDrawGpuSize(Model model, GUIListViewDrawItemArgs args)
        {
            EditorGUI2.Label(args.ItemRect, model.GpuSizeString, args.Selected);
        }

        int OnCompareGpuSize(Model x, Model y)
        {
            return x.PlatformGpuSize.CompareTo(y.PlatformGpuSize);
        }

        string OnExportGpuSize(Model model)
        {
            return model.PlatformGpuSize.ToString();
        }
        #endregion

        #region Draw/Compare PixelRatioPercentage
        void OnDrawPixelRatioPercentage(Model model, GUIListViewDrawItemArgs args)
        {
            EditorGUI2.Label(args.ItemRect, GUIContent2.Temp(model.PlatformPixelRatioPercentageString, model.PlatformPixelRatioTooltip), args.Selected);
        }

        int OnComparePixelRatioPercentage(Model x, Model y)
        {
            return x.PlatformPixelRatioPercentage.CompareTo(y.PlatformPixelRatioPercentage);
        }

        string OnExportPixelRatioPercentage(Model model)
        {
            return model.PlatformPixelRatioPercentageString;
        }
        #endregion

        #region Draw/Compare Width
        void OnDrawWidth(Model model, GUIListViewDrawItemArgs args)
        {
            EditorGUI2.Label(args.ItemRect, model.WidthString, args.Selected);
        }

        int OnCompareWidth(Model x, Model y)
        {
            return x.PlatformWidth.CompareTo(y.PlatformWidth);
        }

        string OnExportWidth(Model model)
        {
            return model.PlatformWidth.ToString();
        }
        #endregion

        #region Draw/Compare Height
        void OnDrawHeight(Model model, GUIListViewDrawItemArgs args)
        {
            EditorGUI2.Label(args.ItemRect, model.HeightString, args.Selected);
        }

        int OnCompareHeight(Model x, Model y)
        {
            return x.PlatformHeight.CompareTo(y.PlatformHeight);
        }

        string OnExportHeight(Model model)
        {
            return model.PlatformHeight.ToString();
        }
        #endregion

        #region Draw/Compare OriginalWidth
        void OnDrawOriginalWidth(Model model, GUIListViewDrawItemArgs args)
        {
            EditorGUI2.Label(args.ItemRect, model.OrgWidthString, args.Selected);
        }

        int OnCompareOriginalWidth(Model x, Model y)
        {
            return x.OrgWidth.CompareTo(y.OrgWidth);
        }

        string OnExportOriginalWidth(Model model)
        {
            return model.OrgWidth.ToString();
        }
        #endregion

        #region Draw/Compare OriginalHeight
        void OnDrawOriginalHeight(Model model, GUIListViewDrawItemArgs args)
        {
            EditorGUI2.Label(args.ItemRect, model.OrgHeightString, args.Selected);
        }

        int OnCompareOriginalHeight(Model x, Model y)
        {
            return x.OrgHeight.CompareTo(y.OrgHeight);
        }

        string OnExportOriginalHeight(Model model)
        {
            return model.OrgHeight.ToString();
        }
        #endregion

        #region Draw/Compare AnisoLevel
        void OnDrawAnisoLevel(Model model, GUIListViewDrawItemArgs args)
        {
            EditorGUI2.Label(args.ItemRect, model.AnisoLevelString, args.Selected);
        }

        int OnCompareAnisoLevel(Model x, Model y)
        {
            return x.AbsAnisoLevel.CompareTo(y.AbsAnisoLevel);
        }

        string OnExportAnisoLevel(Model model)
        {
            return model.AbsAnisoLevel.ToString();
        }
        #endregion

        void DrawToggle(GUIListViewDrawItemArgs args, bool value)
        {
#if true
            //var oldenable = GUI.enabled;
            //GUI.enabled = false;
            EditorGUI.Toggle(args.ItemRect, value);
            //GUI.enabled = oldenable;
#else
            EditorGUI2.Label(args.ItemRect, value ? "Y" : "N", args.Selected);
#endif
        }

        #region Draw/Compare HasAlpha
        void OnDrawHasAlpha(Model model, GUIListViewDrawItemArgs args)
        {
            DrawToggle(args, model.HasAlpha);
        }

        int OnCompareHasAlpha(Model x, Model y)
        {
            var xx = x.HasAlpha ? 1 : 0;
            var yy = y.HasAlpha ? 1 : 0;
            return xx - yy;
        }

        string OnExportHasAlpha(Model model)
        {
            return model.HasAlpha.ToString();
        }
        #endregion

        #region Draw/Compare HasIssue
        void OnDrawHasIssue(Model model, GUIListViewDrawItemArgs args)
        {
            DrawToggle(args, model.PlatformHasIssue);
        }

        int OnCompareHasIssue(Model x, Model y)
        {
            var xx = x.PlatformHasIssue ? 1 : 0;
            var yy = y.PlatformHasIssue ? 1 : 0;
            return xx - yy;
        }

        string OnExportHasIssue(Model model)
        {
            return model.PlatformHasIssue.ToString();
        }
        #endregion

        #region Draw/Compare AlphaSource
        void OnDrawAlphaSource(Model model, GUIListViewDrawItemArgs args)
        {
            EditorGUI2.Label(args.ItemRect, model.AlphaSourceString, args.Selected);            
        }

        int OnCompareAlphaSource(Model x, Model y)
        {
            return string.Compare(x.AlphaSourceString, y.AlphaSourceString);
        }

        string OnExportAlphaSource(Model model)
        {
            return model.AlphaSourceString;
        }
        #endregion

        #region Draw/Compare AlphaIsTransparency
        void OnDrawAlphaIsTransparency(Model model, GUIListViewDrawItemArgs args)
        {
            DrawToggle(args, model.AlphaIsTransparency);
        }

        int OnCompareAlphaIsTransparency(Model x, Model y)
        {
            return x.AlphaIsTransparency.CompareTo(y.AlphaIsTransparency);
        }

        string OnExportAlphaIsTransparency(Model model)
        {
            return model.AlphaIsTransparency.ToString();
        }
        #endregion

        #region Draw/Compare IsPowerOfTwo
        void OnDrawIsPowerOfTwo(Model model, GUIListViewDrawItemArgs args)
        {
            DrawToggle(args, model.PlatformIsPowerOfTwo);
        }

        int OnCompareIsPowerOfTwo(Model x, Model y)
        {
            var xvalue = x.PlatformIsPowerOfTwo ? 1 : 0;
            var yvalue = y.PlatformIsPowerOfTwo ? 1 : 0;
            return xvalue - yvalue;
        }

        string OnExportIsPowerOfTwo(Model model)
        {
            return model.PlatformIsPowerOfTwo.ToString();
        }
        #endregion

        #region Draw/Compare IsSquare
        void OnDrawIsSquare(Model model, GUIListViewDrawItemArgs args)
        {
            DrawToggle(args, model.PlatformIsSquare);
        }

        int OnCompareIsSquare(Model x, Model y)
        {
            var xvalue = x.PlatformIsSquare ? 1 : 0;
            var yvalue = y.PlatformIsSquare ? 1 : 0;
            return xvalue - yvalue;
        }

        string OnExportIsSquare(Model model)
        {
            return model.PlatformIsSquare.ToString();
        }
        #endregion

        #region Draw/Compare ReadWrite Enabled
        void OnDrawReadWriteEnabled(Model model, GUIListViewDrawItemArgs args)
        {
            DrawToggle(args, model.IsReadable);
        }

        int OnCompareReadWriteEnabled(Model x, Model y)
        {
            var xvalue = x.IsReadable ? 1 : 0;
            var yvalue = y.IsReadable ? 1 : 0;
            return xvalue - yvalue;
        }

        string OnExportReadWriteEnabled(Model model)
        {
            return model.IsReadable.ToString();
        }
        #endregion

        #region Draw/Compare SpriteImportMode
        void OnDrawSpriteImportMode(Model model, GUIListViewDrawItemArgs args)
        {
            EditorGUI2.Label(args.ItemRect, model.SpriteImportMode != SpriteImportMode.None ? model.SpriteImportModeString : "", args.Selected);
        }

        int OnCompareSpriteImportMode(Model x, Model y)
        {
            return string.Compare(x.SpriteImportModeString, y.SpriteImportModeString, StringComparison.OrdinalIgnoreCase);
        }

        string OnExportSpriteImportMode(Model model)
        {
            return model.SpriteImportModeString;
        }
        #endregion

        #region Draw/Compare SpritePackingTag
        void OnDrawSpritePackingTag(Model model, GUIListViewDrawItemArgs args)
        {
            EditorGUI2.Label(args.ItemRect, model.SpriteImportMode != SpriteImportMode.None ? model.SpritePackingTag : "", args.Selected);
        }

        int OnCompareSpritePackingTag(Model x, Model y)
        {
            return string.Compare(x.SpritePackingTag, y.SpritePackingTag, StringComparison.OrdinalIgnoreCase);
        }

        string OnExportSpritePackingTag(Model model)
        {
            return model.SpritePackingTag;
        }
        #endregion

        #region Draw/Compare SpritePixelPerUnit
        void OnDrawSpritePixelPerUnit(Model model, GUIListViewDrawItemArgs args)
        {
            EditorGUI2.Label(args.ItemRect, model.SpriteImportMode != SpriteImportMode.None ? model.SpritePixelPerUnitString : "", args.Selected);
        }

        int OnCompareSpritePixelPerUnit(Model x, Model y)
        {
            return string.Compare(x.SpritePixelPerUnitString, y.SpritePixelPerUnitString, StringComparison.OrdinalIgnoreCase);
        }

        string OnExportSpritePixelPerUnit(Model model)
        {
            return model.SpritePixelPerUnitString;
        }
        #endregion

        #region Draw/Compare Overridden
        void OnDrawOverride(Model model, GUIListViewDrawItemArgs args)
        {
            var value = model.GetImporterOverridden(_platform);
            DrawToggle(args, value);
        }

        int OnCompareOverride(Model x, Model y)
        {
            var xx = x.GetImporterOverridden(_platform);
            var yy = y.GetImporterOverridden(_platform);
            return xx.CompareTo(yy);
        }

        string OnExportOverride(Model model)
        {
            var value = model.GetImporterOverridden(_platform);
            return value.ToString();
        }
        #endregion

        #region AssetFileWatcher
        /// <summary>
        /// Occurs when an asset has been moved in the project.
        /// </summary>
        void AssetFileWatcher_Moved(string[] oldPaths, string[] newPaths)
        {
            int processed = 0;
            long loadedsize = 0;
            for (var n = 0; n < oldPaths.Length; ++n)
            {
                if (!IsSupportedFile(oldPaths[n]))
                    continue; // not the type of asset we're interested in
                processed++;

                var model = FindModel(oldPaths[n]);
                if (null != model)
                {
                    loadedsize += InitModel(ref model, newPaths[n]);
                    CheckUnloadUnused(ref loadedsize, 128 * 1024 * 1024);
                }
            }

            if (processed > 0)
            {
                RefreshModels();
                Sort();
                DoTextureChanged();

                // write updated cache to disk
                if (!_cache.IsEmpty)
                    _cache.Write();
            }
        }

        /// <summary>
        /// Occurs when an asset has been deleted from the project.
        /// </summary>
        void AssetFileWatcher_Deleted(string[] paths)
        {
            int processed = 0;
            foreach (var path in paths)
            {
                if (!IsSupportedFile(path))
                    continue; // not the type of asset we're interested in
                processed++;

                var model = FindModel(path);
                if (null != model)
                {
                    _allitems.Remove(model);
                    _items.Remove(model);
                }
            }

            if (processed > 0)
            {
                RefreshModels();
                DoChanged();
                DoTextureChanged();

                // write updated cache to disk
                if (!_cache.IsEmpty)
                    _cache.Write();
            }
        }

        /// <summary>
        /// Occurs when an asset has been imported into the project.
        /// </summary>
        void AssetFileWatcher_Imported(string[] paths)
        {
            int processed = 0;
            var addeditem = false;
            long loadedsize = 0;
            foreach (var path in paths)
            {
                if (!IsSupportedFile(path))
                    continue; // not the type of asset we're interested in
                processed++;

                // try to find the model
                var model = FindModel(path);
                if (null != model)
                {
                    loadedsize += InitModel(ref model, path);
                    continue;
                }

                // this is a new asset, add it to our list
                loadedsize += InitModel(ref model, path);
                _allitems.Add(model);

                // if the asset is visible to the current filter, add it to the filtered list as well
                if (IsIncludedInFilter(model))
                    _items.Add(model);

                addeditem = true;
                CheckUnloadUnused(ref loadedsize, 128 * 1024 * 1024);
            }

            if (processed > 0)
            {
                RefreshModels();

                if (addeditem)
                    Sort();

                DoChanged();
                DoTextureChanged();

                // write updated cache to disk
                if (!_cache.IsEmpty)
                    _cache.Write();
            }
        }
        #endregion

        #region GetMemoryUsage
        /// <summary>
        /// Gets memory usages of all textures currently added to the listbox.
        /// </summary>
        /// <param name="runtimeUsage">The output runtime usage</param>
        /// <param name="storageUsage">The output storage usage</param>
        public void GetMemoryUsage(out TextureMemoryUsageInfo cpuUsage, out TextureMemoryUsageInfo gpuUsage,
            out TextureMemoryUsageInfo runtimeUsage, out TextureMemoryUsageInfo storageUsage)
        {
            GetMemoryUsage(out cpuUsage, delegate(Model model) { return model.PlatformCpuSize; });
            GetMemoryUsage(out gpuUsage, delegate(Model model) { return model.PlatformGpuSize; });
            GetMemoryUsage(out runtimeUsage, delegate(Model model) { return model.PlatformRuntimeSize; });
            GetMemoryUsage(out storageUsage, delegate(Model model) { return model.PlatformStorageSize; });
        }

        void GetMemoryUsage(out TextureMemoryUsageInfo usageInfo, Func<Model, int> getSize)
        {
            usageInfo = new TextureMemoryUsageInfo();

            // lookup tables to sum memory usage by texture type (Key=TextureType)
            var lookup = new Dictionary<int, TextureMemoryUsageData>();

            // collect the runtime and storage memory usage 
            for (int n=0, nend = _items.Count; n<nend; ++n)
            {
                var model = _items[n];
                if (model == null)
                    continue;

                var size = getSize(model);
                usageInfo.TotalSize += size;

                TextureMemoryUsageData info;

                // check if usage for TextureType exists in lookup table already. if not, add it
                var typeHash = Listbox.TypeFilter.ComputeHashCode(model.TextureType, model.TextureShape);
                if (!lookup.TryGetValue(typeHash, out info))
                    lookup.Add(typeHash, info = new TextureMemoryUsageData());

                info.TextureType = model.TextureType;
                info.TextureShape = model.TextureShape;
                info.Size += size;
            }

            // add memory usage
            usageInfo.UsagePerType.AddRange(lookup.Values);

            // calc the percentage
            for (var n = 0; n < usageInfo.UsagePerType.Count; ++n)
            {
                var usage = usageInfo.UsagePerType[n];
                usage.Percentage = usage.Size / (float)usageInfo.TotalSize;
            }

            // sort runtime usage by size
            usageInfo.UsagePerType.Sort(delegate(TextureMemoryUsageData a, TextureMemoryUsageData b)
            {
                return b.Size.CompareTo(a.Size);
            });
        }

        #endregion
    }
}
