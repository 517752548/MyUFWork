USE `tr_s1`;
update t_db_version set version='1.0.0.18.2',updateTime=now();