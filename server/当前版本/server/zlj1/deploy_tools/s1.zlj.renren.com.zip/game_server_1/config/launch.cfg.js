config.setProperty("jar.file", "lib/server_lib.encrypt");
config.setProperty("jar.main", "com.imop.lj.gameserver.GameServer");
